import asyncio, os
from playwright.async_api import async_playwright
from PIL import Image
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':390,'height':844},color_scheme='light')
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto('file://'+os.path.abspath('index.html')+'#ep1'); await pg.wait_for_timeout(1000)
        await pg.add_style_tag(content='.dokk{display:none!important}')
        ims=[]
        for i in range(4,12):
            el=await pg.query_selector(f'#e1r{i} .artw'); await el.scroll_into_view_if_needed()
            if i==8:
                await el.screenshot(path='shots/t8a.png'); ims.append('shots/t8a.png')
                await pg.click(f'#e1r{i} .flipp'); await pg.wait_for_timeout(200)
                await el.screenshot(path='shots/t8b.png'); ims.append('shots/t8b.png')
            else:
                await el.screenshot(path=f'shots/t{i}.png'); ims.append(f'shots/t{i}.png')
        print('feil',errs)
        await b.close()
    im=[Image.open(f) for f in ims]; w,h=im[0].size
    s=Image.new('RGB',(w*3,h*3),'white')
    for k,x in enumerate(im): s.paste(x,((k%3)*w,(k//3)*h))
    s.save('shots/tsheet.png')
asyncio.run(main())
