import asyncio, os
from playwright.async_api import async_playwright
from PIL import Image
U='file://'+os.path.abspath('index.html')
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':390,'height':844},color_scheme='dark')
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(U+'?sprak=en'); await pg.wait_for_timeout(900)
        rest=set(); ov=[]
        for n in range(0,12):
            await pg.goto(U+'?sprak=en'+('#ep%d'%n if n else '')); await pg.wait_for_timeout(350)
            if n: await pg.evaluate("document.querySelectorAll('#ep%d .belonning').forEach(b=>b.hidden=false); document.querySelectorAll('#ep%d details').forEach(d=>d.open=true)"%(n,n))
            t=await pg.evaluate("""(()=>{const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);const o=[];let x;while(x=w.nextNode()){const p=x.parentElement;if(!p||!p.getClientRects().length)continue;if(p.closest('script,style'))continue;const s=x.textContent.trim();if(/[æøåÆØÅ]/.test(s))o.push(s.slice(0,60));}return o})()""")
            rest.update(t)
            ov.append(await pg.evaluate("document.documentElement.scrollWidth>document.documentElement.clientWidth"))
        print('norske bokstaver synlig i engelsk:',sorted(rest))
        print('sideveis rulling:',any(ov),'feil:',errs)
        shots=[('#ep2','#e2r11'),('#ep6','#e6r3'),('#ep9','#e9r11'),('#ep10','#e10r4'),('#ep11','#e11r8'),('#ep4','#e4r12')]
        for i,(h,sel) in enumerate(shots):
            await pg.goto(U+'?sprak=en'+h); await pg.wait_for_timeout(400)
            await pg.evaluate("document.querySelector('%s').scrollIntoView()"%sel); await pg.wait_for_timeout(250)
            await pg.screenshot(path='shots/m%d.png'%i)
        await b.close()
    s=Image.new('RGB',(390*6,844))
    for k in range(6): s.paste(Image.open('shots/m%d.png'%k),(k*390,0))
    s.save('shots/msheet.png')
asyncio.run(main())
