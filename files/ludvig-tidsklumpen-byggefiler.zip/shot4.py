import asyncio
from playwright.async_api import async_playwright
from PIL import Image
async def main():
    errs=[]
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={'width':400,'height':800})
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/tk/index.html'); await pg.wait_for_timeout(250)
        await pg.screenshot(path='shots/m1.png')
        await pg.click('.dokk a[data-til="reiser"]'); await pg.wait_for_timeout(300); await pg.screenshot(path='shots/m2.png')
        r={}
        r['her_reiser']=await pg.evaluate("document.querySelector('.dokk a.her').dataset.til")
        await pg.click('.dokk a[data-til="voksne"]'); await pg.wait_for_timeout(300); await pg.screenshot(path='shots/m2.png')
        r['her_voksne']=await pg.evaluate("document.querySelector('.dokk a.her').dataset.til")
        await pg.click('.dokk a[data-til="hjem"]'); await pg.wait_for_timeout(300)
        r['topp']=await pg.evaluate("window.scrollY"); r['her_hjem']=await pg.evaluate("document.querySelector('.dokk a.her').dataset.til")
        await pg.evaluate("location.hash='#ep4'"); await pg.wait_for_timeout(700)
        await pg.evaluate("window.scrollTo(0, document.documentElement.scrollHeight*0.45)"); await pg.wait_for_timeout(300)
        await pg.screenshot(path='shots/m3.png')
        r['teip']=await pg.evaluate("document.getElementById('teipmaal').style.width"); r['her_ep']=await pg.evaluate("document.querySelector('.dokk a.her').dataset.til")
        await pg.click('.dokk a[data-til="hylla"]'); await pg.wait_for_timeout(300)
        r['hylla_synlig']=await pg.evaluate("!document.getElementById('hjem').hidden && document.getElementById('hylla').getBoundingClientRect().top<200")
        r['feil']=errs
        for k,v in r.items(): print(k,':',v)
        await b.close()
    ims=[Image.open(f'shots/m{i}.png') for i in (1,2,3)]
    s=Image.new('RGB',(1200,800)); [s.paste(im,(k*400,0)) for k,im in enumerate(ims)]; s.save('shots/ms.png')
asyncio.run(main())
