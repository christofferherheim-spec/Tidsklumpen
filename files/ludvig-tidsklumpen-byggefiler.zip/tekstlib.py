# -*- coding: utf-8 -*-
"""Tekst til episode 2 og utover, på norsk og engelsk i samme linje, så de aldri kommer i utakt.
Hver rute: (kilde, [linjer]). kilde = nummeret på den gamle ruta som tegningen hentes fra, eller ("AV", bakgrunn) for avreiseruta.
Hver linje: (hvem, norsk, engelsk). Ludvigs plan: ("PLAN", (tittel, [trinn], Knuts notat), (samme på engelsk))."""
BJ = ("N", "Ludvig tar på Kanels bjelle før de drar. Det gjør han hver gang.", "Ludvig touches Kanel's bell before they leave. He does that every time.")
FIKS = ("L", "Skal bare fikse noe i garasjen!", "Just fixing something in the garage!")
HYLLA = ("L", "Hylla.", "The shelf.")
INGENTING = ("L", "Nei. Og INGENTING!", "No. And NOTHING!")
NEI = ("L", "Nei.", "No.")
IKKE = ("L", "Ikke ennå.", "Not yet.")


def hjem(p, k, cap=None):
    r = [("P",) + p, FIKS, BJ, ("K",) + k, HYLLA]
    return (1, ([("N",) + cap] if cap else []) + r)


def hopp(n, driv, cap=None):
    r = [("N", f"Drivstoff i dag: {driv[0]}. Ludvig stiller inn.", f"Fuel today: {driv[1]}. Ludvig sets the dial."),
         ("L", "Tirsdag fjortende oktober, 16.40.", "Tuesday the fourteenth of October, twenty to five."),
         ("K", f"Måling nummer {n}. Notert.", f"Jump {n}. Logged.")]
    return (2, r + ([("N",) + cap] if cap else []))
