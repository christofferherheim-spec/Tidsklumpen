# -*- coding: utf-8 -*-
import random
from lib import sym, fig, back, INK

S = f'stroke="{INK}" stroke-width="2.4" stroke-linejoin="round"'
S2 = f'stroke="{INK}" stroke-width="2" stroke-linejoin="round"'


def bregne(x, y, s=1.0, c="#4A8F6B"):
    o = ""
    for a in (-70, -40, -12, 14, 42, 70):
        o += f'<path d="M0 0 C{6*s} {-22*s} {4*s} {-44*s} 0 {-58*s} C{-4*s} {-44*s} {-6*s} {-22*s} 0 0 Z" fill="{c}" stroke="{INK}" stroke-width="1.4" transform="translate({x} {y}) rotate({a})"/>'
    return o


# ================= GJESTER =================
fig("aya", skin="#D9A877", skin_sh="#BE8B5C", hair="lang", hc="#3B2A2A", top="#9A6B45", top_sh="#7A5233", kjole=True,
    legs="#7A5233", legs_dk="#5E3F28", shoes="#5E3F28", belt="#F1E2C0",
    extra=f'<path d="M40 80 C52 88 70 88 82 80" fill="none" stroke="#F1E2C0" stroke-width="6" stroke-linecap="round" stroke-dasharray="3 5"/>')
fig("ravn", hair="kort", hc="#D9B56A", top="#5D7C93", top_sh="#44607A", kjole=True, legs="#8E6B45", legs_dk="#6E5340",
    shoes="#5E3F28", belt="#6E5340")
fig("secunda", skin="#E0B088", skin_sh="#C4916A", hair="knute", hc="#3B2A2A", top="#C86A4A", top_sh="#A2503A", kjole=True,
    legs="#E0B088", legs_dk="#C4916A", shoes="#8E6B45", belt="#E8B549")
fig("far", skin="#E0B088", skin_sh="#C4916A", hair="kort", hc="#3B2A2A", top="#F1E2C0", top_sh="#D9C08A", kjole=True,
    legs="#E0B088", legs_dk="#C4916A", shoes="#8E6B45", skjegg="#3B2A2A", mouth="flat", belt="#8E6B45")
fig("nefer", skin="#B9794F", skin_sh="#9A5F3B", hair="lang", hc="#1F1820", top="#FBF4E2", top_sh="#D9CFB4", kjole=True,
    legs="#B9794F", legs_dk="#9A5F3B", shoes=None, belt="#2F7F86")
fig("solveig", hair="lue", hc="#C0453D", hc2="#F7EEDC", top="#3E5F87", top_sh="#2C466B", kjole=True, legs="#6E6A7A",
    legs_dk="#55515F", shoes="#8E6B45",
    extra=f'<path d="M50 80 L44 92 L54 90 Z" fill="#2C466B" {S2}/><path d="M46 86 l0 7" stroke="#D9D6DE" stroke-width="2.2" stroke-linecap="round"/>')
fig("werner", hair="skygge", hc="#2C466B", hc2="#1F3350", top="#7C8468", top_sh="#5F6650", legs="#F2C49A",
    legs_dk="#DCA379", shoes="#33303E", sokker=("#D9D6DE", "#D9D6DE"),
    extra=f'<path d="M38 118 L84 118 L86 138 L64 138 L61 126 L58 138 L36 138 Z" fill="#5F6650" {S2}/><path d="M44 82 L78 118" stroke="#8E6B45" stroke-width="5"/><rect x="70" y="106" width="22" height="18" rx="3" fill="#8E6B45" {S2}/>')
fig("yari", skin="#B9794F", skin_sh="#9A5F3B", hair="lang", hc="#1F1820", top="#E0B56A", top_sh="#C4913A", kjole=True,
    legs="#B9794F", legs_dk="#9A5F3B", shoes=None,
    extra='<path d="M46 80 C54 90 66 90 74 80" fill="none" stroke="#FBF4E2" stroke-width="3" stroke-dasharray="2 4" stroke-linecap="round"/>')
fig("themba", skin="#8A5A3C", skin_sh="#6E442B", hair="kroll", hc="#1F1820", top="#4A8F6B", top_sh="#356E51",
    legs="#8A5A3C", legs_dk="#6E442B", shoes="#F7EEDC", sokker=("#F7EEDC", "#F7EEDC"),
    extra=f'<path d="M38 118 L84 118 L86 140 L64 140 L61 128 L58 140 L36 140 Z" fill="#2C466B" {S2}/>')
back("hatt", coat="#8A7558", coat_sh="#6E5C44", hair="#4A4046", hat="#6E5340",
     extra=f'<path d="M84 116 C98 110 106 104 110 96" fill="none" stroke="#F7EEDC" stroke-width="3"/><circle cx="111" cy="94" r="3" fill="#C0453D"/>')
back("spion", coat="#6E6A7A", coat_sh="#55515F", hair="#2A1F33", hat="#33303E",
     extra=f'<rect x="92" y="150" width="26" height="30" rx="3" fill="#8E6B45" {S2}/><path d="M98 150 c0 -10 14 -10 14 0" fill="none" {S2}/>')
back("garman", coat="#FBF4E2", coat_sh="#D9CFB4", hair="#6E5340",
     extra=f'<path d="M32 46 C30 14 90 14 88 46" fill="none" stroke="{INK}" stroke-width="4"/><rect x="24" y="42" width="10" height="20" rx="4" fill="#33303E" {S2}/><rect x="86" y="42" width="10" height="20" rx="4" fill="#33303E" {S2}/><path d="M40 84 L80 84" stroke="#2C466B" stroke-width="5"/>')

sym("pip", 120, 100, f'''
<path d="M70 62 C96 60 112 48 118 30 C104 44 92 46 78 46 Z" fill="#2F7F86" {S}/>
<path d="M112 34 l8 -10 M108 40 l10 -4" stroke="#E8A93A" stroke-width="3" stroke-linecap="round"/>
<path d="M50 74 l-4 20 l-8 2 M66 74 l4 20 l8 2" fill="none" stroke="{INK}" stroke-width="4" stroke-linecap="round"/>
<ellipse cx="58" cy="58" rx="28" ry="20" fill="#3E9AA0" {S}/><path d="M40 52 C52 44 70 46 80 56 C70 70 50 72 40 62 Z" fill="#E8A93A" {S2}/>
<path d="M46 56 l22 4 M48 62 l18 2" stroke="{INK}" stroke-width="1.4"/>
<path d="M36 50 C30 36 26 30 24 24" fill="none" stroke="#3E9AA0" stroke-width="12" stroke-linecap="round"/>
<circle cx="22" cy="20" r="14" fill="#3E9AA0" {S}/><path d="M10 22 L-2 26 L10 30 Z" fill="#E8B549" {S2}/>
<circle cx="18" cy="16" r="5" fill="#FFFDF8" {S2}/><circle cx="17" cy="16" r="2.4" fill="{INK}"/>
<path d="M26 6 l2 -10 M32 8 l6 -8 M20 6 l-2 -9" stroke="#C0453D" stroke-width="3.4" stroke-linecap="round"/>''')

def _trex(teipet):
    G, GD, LYS = "#7C9A62", "#5F7A4C", "#D9CF9A"
    o = f'<path d="M240 4 C204 6 180 22 170 46 L164 120 C178 156 208 176 240 180 Z" fill="{G}" {S}/>'
    o += f'<path d="M240 122 C214 122 196 134 188 152 C204 168 222 176 240 180 Z" fill="{LYS}"/>'
    o += f'<g fill="{GD}" opacity=".7"><circle cx="206" cy="40" r="7"/><circle cx="222" cy="70" r="5"/><circle cx="196" cy="84" r="6"/><circle cx="110" cy="34" r="5"/><circle cx="84" cy="46" r="4"/></g>'
    if teipet:
        o += f'<path d="M162 102 L22 93 C14 104 20 114 34 116 L150 123 C168 121 172 110 162 102 Z" fill="{G}" {S}/>'
        o += f'<g fill="#FFFDF8" {S2}><path d="M26 93 l10 1 l-4 13 Z M146 100 l10 1 l-4 12 Z"/></g>'
        arm = "M204 138 L190 118 L179 123"
        klo = "M179 123 l-8 -3 M179 123 l-3 8"
    else:
        o += f'<path d="M22 92 L160 102 L164 110 L52 144 Z" fill="#7A2630" {S2}/><path d="M84 132 C104 114 140 108 160 110 L150 124 Z" fill="#D9706B"/>'
        o += f'<g fill="#FFFDF8" {S2}>' + "".join(f'<path d="M{60+k*16} {143-(4+k*16)*33/104:.1f} l11 -3.5 l-6 -14 Z"/>' for k in range(6)) + '</g>'
        o += f'<path d="M164 106 L52 142 C38 148 38 162 52 164 L152 150 C172 144 176 122 164 106 Z" fill="{G}" {S}/>'
        o += f'<g fill="#FFFDF8" {S2}>' + "".join(f'<path d="M{26+k*16} {92+(4+k*16)*10/138:.1f} l12 .9 l-6 {22 if k%2==0 else 17} Z"/>' for k in range(8)) + '</g>'
        arm = "M204 138 L186 153 L172 147"
        klo = "M172 147 l-8 -4 M172 147 l-7 5"
    o += f'<path d="M178 34 C160 12 118 10 96 30 C66 32 30 44 12 62 C2 74 6 90 20 92 L160 102 C180 94 190 62 178 34 Z" fill="{G}" {S}/>'
    o += f'<ellipse cx="28" cy="68" rx="4" ry="2.6" fill="{INK}"/><path d="M42 58 c6 -4 12 -4 18 0" fill="none" stroke="{GD}" stroke-width="2.4" stroke-linecap="round"/>'
    o += f'<circle cx="142" cy="50" r="10" fill="#FFFDF8" {S2}/>'
    if teipet:
        o += f'<circle cx="146" cy="55" r="4.5" fill="{INK}"/><path d="M131 50 a11 11 0 0 1 22 0 Z" fill="{G}" {S2}/>'
        o += f'<path d="M168 24 c-5 9 5 13 7 4 Z" fill="#BFE3EA" {S2}/>'
        b = f'fill="#E9D9A8" {S2}'
        o += (f'<path d="M36 62 L46 50 L126 108 L116 121 Z" {b}/><path d="M40 47 L58 42 L64 119 L46 121 Z" {b}/>'
              f'<path d="M72 33 L90 36 L86 125 L68 123 Z" {b}/><path d="M100 25 L118 23 L122 125 L104 127 Z" {b}/>'
              f'<path d="M118 23 C130 12 140 17 147 6 L153 13 C146 26 134 24 123 33 Z" {b}/>')
        o += f'<g stroke="#C9B77E" stroke-width="1.6" fill="none"><path d="M49 60 l8 50 M78 50 l-3 60 M110 40 l4 70"/></g>'
        o += f'<g fill="none" stroke="{INK}" stroke-width="2" stroke-linecap="round"><path d="M170 108 c-5 3 -6 8 -3 12 M162 100 c-4 2 -5 6 -3 9"/></g>'
    else:
        o += f'<circle cx="138" cy="52" r="4.5" fill="{INK}"/><path d="M158 37 L126 46" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>'
    o += f'<path d="{arm}" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/><path d="{arm}" fill="none" stroke="{G}" stroke-width="6.5" stroke-linecap="round" stroke-linejoin="round"/>'
    o += f'<path d="{klo}" stroke="{INK}" stroke-width="3" stroke-linecap="round"/>'
    return o


sym("trex", 240, 190, _trex(False))
sym("trexteip", 240, 190, _trex(True))

sym("tuk", 120, 90, f'''
<path d="M96 44 C112 36 114 22 108 14" fill="none" stroke="{INK}" stroke-width="9" stroke-linecap="round"/><path d="M96 44 C112 36 114 22 108 14" fill="none" stroke="#B9A48A" stroke-width="5" stroke-linecap="round"/>
<path d="M36 62 l-2 22 M52 66 l0 20 M82 66 l2 20 M96 60 l4 24" stroke="{INK}" stroke-width="9" stroke-linecap="round"/><path d="M36 62 l-2 22 M52 66 l0 20 M82 66 l2 20 M96 60 l4 24" stroke="#B9A48A" stroke-width="5" stroke-linecap="round"/>
<ellipse cx="66" cy="52" rx="36" ry="18" fill="#B9A48A" {S}/><path d="M50 40 C64 34 86 36 98 46 C84 44 66 44 50 48 Z" fill="#8C7A64"/>
<circle cx="28" cy="36" r="18" fill="#B9A48A" {S}/><path d="M14 26 L12 6 L26 20 Z M34 20 L44 4 L44 26 Z" fill="#8C7A64" {S2}/>
<path d="M12 40 C2 40 0 48 8 50 C16 52 22 48 22 44 Z" fill="#E9DCC6" {S2}/><circle cx="4" cy="44" r="3" fill="{INK}"/>
<circle cx="22" cy="32" r="3" fill="{INK}"/><circle cx="34" cy="32" r="3" fill="{INK}"/><path d="M12 52 c4 6 10 6 14 2" fill="#C0453D" {S2}/>''')

# ================= REKVISITTER =================
sym("stjerne", 100, 100, '<circle cx="62" cy="62" r="34" fill="#F7D36A" opacity=".35"/><path d="M0 0 L54 48 L70 40 Z" fill="#F7EEDC" opacity=".8"/><circle cx="62" cy="62" r="20" fill="#FFF6D6"/><circle cx="62" cy="62" r="12" fill="#fff"/>')
sym("oyne", 110, 40, f'<ellipse cx="26" cy="20" rx="20" ry="12" fill="#F7D36A" {S}/><ellipse cx="84" cy="20" rx="20" ry="12" fill="#F7D36A" {S}/><ellipse cx="26" cy="20" rx="4" ry="11" fill="{INK}"/><ellipse cx="84" cy="20" rx="4" ry="11" fill="{INK}"/>')
sym("labb", 130, 100, f'<path d="M130 0 C96 4 60 20 36 46 C20 64 12 80 14 92 C40 100 78 96 100 84 C118 60 126 30 130 0 Z" fill="#C9A66B" {S}/><path d="M130 0 C120 30 110 60 100 84 C112 60 124 30 130 0" fill="#A8854F"/><g fill="#F7EEDC" {S2}><path d="M14 92 l-10 6 l14 4 Z M34 96 l-8 8 l14 0 Z M56 97 l-6 9 l14 -2 Z M78 94 l-4 10 l13 -4 Z"/></g>')
sym("baal", 60, 70, f'<path d="M30 4 C44 22 54 34 50 50 C48 62 38 66 30 66 C22 66 12 62 10 50 C8 38 18 30 20 18 C24 24 26 26 28 28 C28 20 28 12 30 4 Z" fill="#E8752C" {S}/><path d="M30 30 C38 40 40 48 38 54 C36 60 32 62 30 62 C26 62 22 58 22 52 C22 44 28 40 30 30 Z" fill="#F7D36A"/><path d="M6 66 L54 62 M8 60 L52 68" stroke="{INK}" stroke-width="5" stroke-linecap="round"/><path d="M6 66 L54 62 M8 60 L52 68" stroke="#8E6B45" stroke-width="2.4" stroke-linecap="round"/>')
sym("sprut", 60, 90, f'<path d="M30 90 C22 60 8 40 4 14 C14 30 20 34 24 40 C24 26 26 12 32 0 C36 16 38 28 38 40 C44 32 50 26 56 16 C52 44 40 62 36 90 Z" fill="#8FC4D4" {S}/><path d="M30 80 C28 60 26 46 28 30" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".8"/>')
sym("hjelm", 60, 46, f'<path d="M6 36 C6 12 20 4 30 4 C40 4 54 12 54 36 Z" fill="#A3A0AE" {S}/><path d="M30 4 L30 36 M6 36 L54 36" stroke="{INK}" stroke-width="2.4"/><path d="M26 36 L26 46 L34 46 L34 36" fill="#A3A0AE" {S2}/><path d="M12 30 C12 18 18 12 24 10" fill="none" stroke="#fff" stroke-width="2.4" opacity=".6" stroke-linecap="round"/>')
random.seed(79)
sym("pimp", 360, 220, "".join(f'<path d="M{x} {y} l{4+r} {-2} l{3} {4+r} l{-5-r} {3} Z" fill="{random.choice(["#8C8896","#A3A0AE","#6E6A7A"])}" stroke="{INK}" stroke-width="1.2"/><path d="M{x+2} {y-6} l-6 -22" stroke="#6E6A7A" stroke-width="1.2" opacity=".5"/>' for x, y, r in [(random.randint(5, 350), random.randint(5, 200), random.randint(0, 4)) for _ in range(46)]))
sym("pute", 70, 44, f'<path d="M8 10 C24 4 46 4 62 10 C68 20 68 28 62 38 C46 42 24 42 8 38 C2 28 2 20 8 10 Z" fill="#F1E2C0" {S}/><path d="M8 10 l-6 -6 M62 10 l6 -6 M8 38 l-6 4 M62 38 l6 4" stroke="{INK}" stroke-width="2.4" stroke-linecap="round"/><path d="M4 22 C24 26 46 26 66 22" fill="none" stroke="#C0453D" stroke-width="3"/>')
sym("slede", 190, 110, f'''
<path d="M30 12 L162 12 L162 78 L30 78 Z" fill="#E9D9A8" {S}/><path d="M124 12 L162 12 L162 78 L124 78 Z" fill="#D2BE84"/><path d="M40 24 l30 0 M50 40 l44 0 M38 60 l26 0" stroke="#C7B078" stroke-width="2"/>
<path d="M8 96 C4 84 14 78 26 78 L176 78 L184 96 Z" fill="#8E6B45" {S}/><path d="M12 96 L184 96" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>
<path d="M30 12 C60 30 130 30 162 12 M30 44 L162 44" fill="none" stroke="#6E5340" stroke-width="3"/>''')
sym("krukke", 44, 56, f'<path d="M14 8 L30 8 L28 18 C40 24 42 44 32 52 L12 52 C2 44 4 24 16 18 Z" fill="#C0806A" {S}/><path d="M28 18 C40 24 42 44 32 52 L24 52 C34 44 32 26 24 18 Z" fill="#A96B58"/><path d="M10 30 L34 30" stroke="#F1E2C0" stroke-width="3"/>')
sym("vann", 130, 40, f'<path d="M4 34 C10 20 24 22 32 28 C40 12 60 14 66 26 C76 10 98 14 102 28 C112 20 124 24 126 34 Z" fill="#8FC4D4" {S}/><path d="M20 30 c6 -6 12 -6 16 0 M56 26 c6 -6 14 -6 18 0" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".8"/>')
for i, col, col2, hand in (("ermeG", "#7C8468", "#5F6650", "#33303E"), ("ermeK", "#B5A06A", "#93804F", "#E3B48E")):
    sym(i, 150, 60, f'<path d="M150 4 L60 14 L58 46 L150 56 Z" fill="{col}" {S}/><path d="M150 40 L58 36 L58 46 L150 56 Z" fill="{col2}"/><path d="M60 14 L50 16 L50 44 L58 46 Z" fill="{col2}" {S2}/><path d="M50 18 C30 14 14 18 6 26 C2 32 8 36 16 34 L30 32 C22 38 20 44 28 46 C38 46 46 42 50 42 Z" fill="{hand}" {S}/>')
sym("stovler", 90, 70, f'<path d="M8 0 L34 0 L34 44 C46 46 52 54 50 64 L6 64 Z" fill="#33303E" {S}/><path d="M48 0 L74 0 L74 44 C86 46 92 54 90 64 L46 64 Z" fill="#33303E" {S}/><path d="M6 64 L50 64 M46 64 L90 64" stroke="{INK}" stroke-width="5"/><path d="M14 6 L14 40 M54 6 L54 40" stroke="#6E6A7A" stroke-width="3" stroke-linecap="round"/>')
sym("pram", 130, 120, f'''
<path d="M104 24 L126 8" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>
<path d="M14 40 L108 40 C108 70 90 84 62 84 C34 84 14 70 14 40 Z" fill="#4F6B4E" {S}/><path d="M76 40 L108 40 C108 70 90 84 62 84 C84 76 86 56 76 40 Z" fill="#3B523A"/>
<path d="M14 40 C14 10 40 2 62 6 L62 40 Z" fill="#5E7F5D" {S}/><path d="M24 40 C26 22 40 14 54 14 M36 40 C38 28 46 22 56 22" fill="none" stroke="#3B523A" stroke-width="2"/>
<path d="M60 30 C74 24 96 26 106 40 L60 40 Z" fill="#F1E2C0" {S2}/>
<circle cx="36" cy="100" r="16" fill="none" {S}/><circle cx="88" cy="100" r="16" fill="none" {S}/><circle cx="36" cy="100" r="3" fill="{INK}"/><circle cx="88" cy="100" r="3" fill="{INK}"/><path d="M36 84 L36 100 M88 84 L88 100" stroke="{INK}" stroke-width="2.4"/>''')
sym("radio", 70, 52, f'<rect x="4" y="8" width="62" height="40" rx="6" fill="#8E6B45" {S}/><rect x="10" y="14" width="30" height="28" rx="3" fill="#D9C08A" {S2}/><path d="M14 20 l22 0 M14 26 l22 0 M14 32 l22 0 M14 38 l22 0" stroke="#8E6B45" stroke-width="2"/><circle cx="54" cy="22" r="6" fill="#F1E2C0" {S2}/><circle cx="54" cy="38" r="4" fill="#33303E"/><path d="M50 8 L40 0" stroke="{INK}" stroke-width="2"/>')
sym("sykler", 150, 100, f'''
<g fill="none" stroke="{INK}" stroke-width="3.4"><circle cx="34" cy="68" r="26"/><circle cx="112" cy="68" r="26"/><path d="M34 68 L60 36 L98 36 L112 68 L68 68 Z"/><path d="M60 36 L54 68"/><path d="M98 36 L104 24 L116 24"/><path d="M60 36 L48 28 L36 28"/></g>
<path d="M22 10 L128 22" stroke="{INK}" stroke-width="9" stroke-linecap="round"/><path d="M22 10 L128 22" stroke="#7C8468" stroke-width="5" stroke-linecap="round"/><path d="M12 2 L30 8 L26 20 L8 14 Z" fill="#5F6650" {S2}/>''')
sym("kano", 200, 50, f'<path d="M2 10 C30 16 170 16 198 10 C186 36 160 46 100 46 C40 46 14 36 2 10 Z" fill="#8E6B45" {S}/><path d="M16 22 C60 30 140 30 184 22" fill="none" stroke="#6E5340" stroke-width="3"/><path d="M150 14 C170 16 186 14 198 10 C190 30 176 40 150 44 Z" fill="#6E5340" opacity=".6"/>')
sym("koye", 170, 60, f'<path d="M6 8 C40 64 130 64 164 8" fill="#E9D9A8" {S}/><path d="M22 12 C50 50 120 50 148 12 M40 14 C60 38 110 38 130 14 M14 22 L156 22 M30 36 L140 36" fill="none" stroke="#B98D5E" stroke-width="1.6"/><circle cx="6" cy="8" r="4" fill="#8E6B45" {S2}/><circle cx="164" cy="8" r="4" fill="#8E6B45" {S2}/>')
sym("columbus", 120, 160, f'''
<path d="M70 150 L70 6" stroke="{INK}" stroke-width="5" stroke-linecap="round"/><path d="M70 8 L116 14 L104 28 L116 42 L70 40 Z" fill="#F7EEDC" {S}/><path d="M86 18 l0 14 M79 25 l14 0" stroke="#4A8F6B" stroke-width="4"/>
<path d="M0 0 L40 0 C44 50 48 90 54 122 L10 126 C4 90 2 50 0 0 Z" fill="#C0453D" {S}/><path d="M24 0 L40 0 C44 50 48 90 54 122 L40 123 C34 90 28 50 24 0 Z" fill="#96322C"/>
<path d="M14 118 L40 116 L42 140 C54 142 62 148 60 156 L12 158 Z" fill="#33303E" {S}/>''')
sym("benk", 150, 90, f'''
<path d="M14 50 L14 86 M136 50 L136 86 M24 20 L24 60 M126 20 L126 60" stroke="{INK}" stroke-width="6" stroke-linecap="round"/>
<rect x="8" y="46" width="134" height="12" rx="2" fill="#B98D5E" {S}/><rect x="16" y="10" width="118" height="30" rx="2" fill="#F7EEDC" {S}/>
<text x="75" y="23" text-anchor="middle" font-family="Baloo 2,Comic Relief,sans-serif" font-size="10" font-weight="800" fill="{INK}" textLength="100" lengthAdjust="spacingAndGlyphs">SLEGS BLANKES</text>
<text x="75" y="35" text-anchor="middle" font-family="Baloo 2,Comic Relief,sans-serif" font-size="10" font-weight="800" fill="{INK}" textLength="92" lengthAdjust="spacingAndGlyphs">WHITES ONLY</text>
<path d="M20 14 L128 36" stroke="#4A8F6B" stroke-width="4" opacity=".6" stroke-linecap="round"/>''')
random.seed(1990)
_h = ""
for row, (y, r) in enumerate(((30, 11), (52, 13), (78, 15))):
    x = random.randint(-6, 6)
    while x < 370:
        c = random.choice(["#6E442B", "#8A5A3C", "#5A3826", "#3B2A2A", "#B9794F"])
        t = random.choice(["#C0453D", "#E8B549", "#4A8F6B", "#F7EEDC", "#3E5F87", "#2A1F33"])
        _h += f'<path d="M{x-r*1.3:.0f} {y+r*2.6:.0f} C{x-r*1.3:.0f} {y+r*0.8:.0f} {x+r*1.3:.0f} {y+r*0.8:.0f} {x+r*1.3:.0f} {y+r*2.6:.0f} Z" fill="{t}" stroke="{INK}" stroke-width="1.6"/><circle cx="{x}" cy="{y}" r="{r}" fill="{c}" stroke="{INK}" stroke-width="1.8"/>'
        x += r * 2 + random.randint(4, 12)
sym("mengde", 360, 120, _h + f'<g {S2}><path d="M60 6 l0 40" /><path d="M60 6 l26 4 l0 16 l-26 -4 Z" fill="#4A8F6B"/><path d="M60 6 l26 4 l0 5 l-26 -4 Z" fill="#2A1F33"/><path d="M60 16 l26 4 l0 5 l-26 -4 Z" fill="#E8B549"/><path d="M250 2 l0 40"/><path d="M250 2 l24 5 l0 14 l-24 -5 Z" fill="#E8B549"/></g>')
sym("konsoll", 150, 110, f'''
<path d="M6 40 L144 40 L150 110 L0 110 Z" fill="#8C9AA0" {S}/><path d="M14 6 L136 6 L144 40 L6 40 Z" fill="#6B7A82" {S}/>
<rect x="22" y="12" width="46" height="22" rx="3" fill="#12301F" {S2}/><rect x="80" y="12" width="46" height="22" rx="3" fill="#12301F" {S2}/>
<path d="M27 18 l30 0 M27 24 l22 0 M27 29 l34 0 M85 18 l20 0 M85 24 l34 0" stroke="#6FE08A" stroke-width="2"/>
<g fill="#F1E2C0" {S2}><circle cx="24" cy="58" r="5"/><circle cx="42" cy="58" r="5"/><circle cx="60" cy="58" r="5"/></g><g {S2}><rect x="80" y="52" width="14" height="10" fill="#C0453D"/><rect x="100" y="52" width="14" height="10" fill="#E8B549"/><rect x="120" y="52" width="14" height="10" fill="#4A8F6B"/></g>''')
sym("strimler", 90, 50, "".join(f'<path d="M{10+i*7} {44-(i%3)*4} C{6+i*7} {30} {22+i*6} {22+(i%4)*4} {14+i*6} {6+(i%5)*3}" fill="none" stroke="{INK}" stroke-width="4.4" stroke-linecap="round"/><path d="M{10+i*7} {44-(i%3)*4} C{6+i*7} {30} {22+i*6} {22+(i%4)*4} {14+i*6} {6+(i%5)*3}" fill="none" stroke="#FFFDF8" stroke-width="2.6" stroke-linecap="round"/>' for i in range(11)))
sym("blits", 360, 220, '<rect width="360" height="220" fill="#FFF6D6"/>' + "".join(f'<path d="M180 110 L{180+400*__import__("math").cos(a/12*6.283):.0f} {110+400*__import__("math").sin(a/12*6.283):.0f} L{180+400*__import__("math").cos((a+.5)/12*6.283):.0f} {110+400*__import__("math").sin((a+.5)/12*6.283):.0f} Z" fill="#F7D36A"/>' for a in range(12)) + '<circle cx="180" cy="110" r="60" fill="#fff"/>')
sym("teip", 50, 50, f'<circle cx="25" cy="25" r="21" fill="#E9D9A8" {S}/><circle cx="25" cy="25" r="9" fill="#F6EBD4" {S2}/><path d="M44 30 L50 44 L38 40" fill="#E9D9A8" {S2}/>')
sym("matboks", 60, 40, f'<rect x="4" y="10" width="52" height="26" rx="5" fill="#3E9AA0" {S}/><rect x="4" y="10" width="52" height="9" rx="4" fill="#5DB7B0" {S2}/><rect x="24" y="14" width="12" height="6" rx="2" fill="#F7EEDC" {S2}/>')

# ================= BAKGRUNNER (ett sted per episode) =================
sym("bg1", 360, 220, f'''
<rect width="360" height="220" fill="#EBDDAE"/><path d="M0 118 C60 96 120 112 180 100 C240 90 300 106 360 94 L360 220 L0 220 Z" fill="#A9BF94"/>
<rect x="24" y="-4" width="36" height="184" fill="#7A5C48" {S}/><path d="M48 -4 L60 -4 L60 180 L48 180 Z" fill="#5E4636"/><rect x="118" y="-4" width="22" height="150" fill="#8E6B45" {S2}/>
<path d="M-10 30 C30 10 80 14 110 34 C70 30 30 36 -10 50 Z M90 14 C140 -6 200 2 230 24 C180 16 130 22 96 34 Z" fill="#4A8F6B" {S2}/>
<path d="M0 176 C90 166 270 170 360 180 L360 220 L0 220 Z" fill="#B98D5E" {S}/>
{bregne(84, 178, 1.0)}{bregne(160, 172, .8, "#5FA37C")}{bregne(14, 190, 1.1, "#3E7C5B")}
<path d="M196 150 L352 136 L360 188 L204 198 Z" fill="#8E6B45" {S}/><path d="M204 176 L358 164 L360 188 L204 198 Z" fill="#6E5340"/><ellipse cx="200" cy="174" rx="12" ry="25" fill="#C89C64" {S}/><ellipse cx="200" cy="174" rx="5" ry="12" fill="none" stroke="#8E6B45" stroke-width="2"/>
<ellipse cx="262" cy="200" rx="26" ry="10" fill="{INK}"/>{bregne(330, 204, .9)}''')
sym("bg2", 360, 220, f'''
<rect width="360" height="220" fill="#C5D3DB"/><path d="M0 70 L60 30 L110 64 L170 20 L230 60 L290 34 L360 70 L360 220 L0 220 Z" fill="#E4ECEF" {S2}/><path d="M170 20 L190 60 L150 70 Z M60 30 L74 62 L40 66 Z" fill="#B7C7D1"/>
<path d="M0 150 C100 138 260 142 360 152 L360 220 L0 220 Z" fill="#F4F6F6" {S}/><path d="M0 196 C120 186 240 190 360 200 L360 220 L0 220 Z" fill="#DCE5EA"/>
<path d="M214 160 C210 96 246 62 292 62 C338 62 364 96 362 160 Z" fill="#8C8896" {S}/><path d="M238 160 C236 112 262 88 294 88 C326 88 346 112 344 160 Z" fill="{INK}"/>
<g fill="#B7C7D1"><ellipse cx="40" cy="180" rx="9" ry="5"/><ellipse cx="70" cy="170" rx="9" ry="5"/><ellipse cx="104" cy="182" rx="9" ry="5"/><ellipse cx="136" cy="172" rx="9" ry="5"/></g>
<g fill="none" stroke="#9FB2BE" stroke-width="2"><path d="M38 176 l-3 -5 M41 175 l0 -6 M44 176 l3 -5"/><path d="M102 178 l-3 -5 M105 177 l0 -6 M108 178 l3 -5"/></g>''')
sym("bg3", 360, 220, f'''
<rect width="360" height="220" fill="#A9B6BE"/><path d="M0 40 C60 30 120 44 200 34 C260 28 320 40 360 32 L360 0 L0 0 Z" fill="#8795A0"/>
<path d="M0 96 C30 86 60 104 90 94 C120 84 150 104 180 94 C210 84 240 104 270 94 C300 84 330 104 360 94 L360 150 L0 150 Z" fill="#4F7A8C" {S}/><path d="M20 112 c12 -8 22 -8 34 0 M250 116 c12 -8 22 -8 34 0 M140 120 c10 -6 18 -6 28 0" fill="none" stroke="#CFE9EE" stroke-width="2.4" stroke-linecap="round"/>
<rect x="170" y="-4" width="14" height="150" fill="#8E6B45" {S}/><path d="M60 -6 L300 -6 L288 70 C230 80 130 80 72 70 Z" fill="#F1E2C0" {S}/><g fill="#C0453D"><path d="M96 -6 L130 -6 L124 76 L92 73 Z"/><path d="M164 -6 L198 -6 L198 78 L164 78 Z"/><path d="M232 -6 L266 -6 L270 73 L238 76 Z"/></g><path d="M60 -6 L300 -6 L288 70 C230 80 130 80 72 70 Z" fill="none" {S}/>
<path d="M0 132 L360 132 L360 152 L0 152 Z" fill="#8E6B45" {S}/><g {S2}><circle cx="40" cy="140" r="15" fill="#C0453D"/><circle cx="110" cy="140" r="15" fill="#E8B549"/><circle cx="250" cy="140" r="15" fill="#5D7C93"/><circle cx="320" cy="140" r="15" fill="#C0453D"/></g><g fill="#D9D6DE" {S2}><circle cx="40" cy="140" r="4"/><circle cx="110" cy="140" r="4"/><circle cx="250" cy="140" r="4"/><circle cx="320" cy="140" r="4"/></g>
<rect y="152" width="360" height="68" fill="#B98D5E" {S}/><path d="M0 172 L360 172 M0 194 L360 194 M70 152 L70 172 M210 152 L210 172 M140 172 L140 194 M290 172 L290 194 M40 194 L40 220 M230 194 L230 220" stroke="#8E6B45" stroke-width="2"/>''')
sym("bg4", 360, 220, f'''
<rect width="360" height="220" fill="#DCCBA8"/><path d="M120 78 L180 22 L206 22 L270 78 Z" fill="#9A8F86" {S}/><path d="M178 24 C150 -6 196 -30 190 -44 L250 -44 C236 -20 232 0 208 24 Z" fill="#55515F"/><path d="M150 -10 C120 -14 100 6 70 0 L70 -30 L200 -30 Z" fill="#6E6A7A"/>
<rect x="-4" y="60" width="110" height="130" fill="#E8C98A" {S}/><rect x="-4" y="140" width="110" height="50" fill="#C0453D" {S2}/><path d="M-8 60 L112 60 L104 44 L-8 44 Z" fill="#C86A4A" {S}/><rect x="30" y="84" width="30" height="36" fill="#55515F" {S2}/>
<rect x="232" y="50" width="132" height="140" fill="#E8C98A" {S}/><path d="M226 50 L364 50 L364 32 L236 32 Z" fill="#C86A4A" {S}/>
<path d="M262 170 C262 112 282 96 306 96 C330 96 350 112 350 170 Z" fill="#B5805F" {S}/><path d="M278 170 C278 128 290 116 306 116 C322 116 334 128 334 170 Z" fill="{INK}"/><path d="M286 168 C292 150 300 146 306 132 C312 146 322 150 326 168 Z" fill="#E8752C"/><path d="M296 168 C300 158 304 156 306 148 C308 156 314 158 316 168 Z" fill="#F7D36A"/>
<rect x="244" y="170" width="120" height="20" fill="#D9C08A" {S}/>
<path d="M0 190 L360 190 L360 220 L0 220 Z" fill="#A3A0AE" {S}/><g fill="#8C8896" {S2}><ellipse cx="130" cy="204" rx="16" ry="8"/><ellipse cx="176" cy="204" rx="16" ry="8"/><ellipse cx="222" cy="204" rx="16" ry="8"/></g>''')
sym("bg5", 360, 220, f'''
<rect width="360" height="220" fill="#EFE0B4"/><circle cx="306" cy="40" r="22" fill="#FFF6D6"/>
<path d="M-10 150 L20 150 L20 126 L48 126 L48 102 L76 102 L76 78 L104 78 L104 54 L132 54 L132 78 L160 78 L160 150 Z" fill="#D9C08A" {S}/><path d="M132 54 L132 78 L160 78 L160 150 L140 150 L140 90 L118 90 L118 60 Z" fill="#C0A66C"/>
<path d="M160 150 L160 112 L250 150 Z" fill="#C89C64" {S2}/>
<path d="M0 150 C80 140 200 146 360 138 L360 220 L0 220 Z" fill="#E0B56A" {S}/><path d="M0 190 C100 178 240 186 360 176 L360 220 L0 220 Z" fill="#D2A257"/>
<g fill="none" stroke="#C4913A" stroke-width="2" stroke-linecap="round"><path d="M30 170 c10 -4 20 -4 30 0 M250 164 c10 -4 20 -4 30 0 M120 204 c10 -4 20 -4 30 0"/></g>''')
sym("bg6", 360, 220, f'''
<rect width="360" height="220" fill="#DDD0B8"/><path d="M0 96 L40 96 L52 70 L130 70 L142 96 L220 96 L232 80 L300 80 L312 96 L360 96 L360 160 L0 160 Z" fill="#C08A68" {S2}/>
<g fill="#4F6B4E" {S2}><path d="M196 150 L208 96 L220 150 Z"/><path d="M226 150 L236 108 L246 150 Z"/></g>
<path d="M0 150 L360 150 L360 220 L0 220 Z" fill="#D2B48A" {S}/>
<rect x="8" y="50" width="150" height="112" fill="#B98D5E" {S}/><path d="M0 50 L166 50 L150 30 L16 30 Z" fill="#6E5340" {S}/><path d="M8 78 L158 78 M8 106 L158 106 M8 134 L158 134" stroke="#8E6B45" stroke-width="2"/>
<rect x="30" y="66" width="104" height="72" fill="#2F4A3C" {S}/><g fill="none" stroke="#F7EEDC" stroke-width="2.2" stroke-linecap="round"><path d="M40 82 l12 0 M46 76 l0 12 M60 82 l8 0 M60 86 l8 0 M76 76 l10 12 M86 76 l-10 12 M96 78 c6 -6 12 0 6 6 l-8 6 l12 0"/><path d="M40 104 c8 -8 12 8 20 0 s12 8 20 0 M92 100 l24 0 M40 122 l30 0 M80 118 c8 0 8 10 0 10 M100 116 l0 12 l10 0"/></g>
<path d="M262 96 L262 160 M348 96 L348 160" stroke="{INK}" stroke-width="6" stroke-linecap="round"/><path d="M262 112 L360 112 M262 128 L360 128 M262 144 L360 144" stroke="{INK}" stroke-width="1.6"/><g stroke="{INK}" stroke-width="1.6"><path d="M280 108 l4 8 M300 108 l4 8 M320 108 l4 8 M340 108 l4 8 M290 124 l4 8 M310 124 l4 8 M330 124 l4 8"/></g>
<path d="M176 132 L262 120" stroke="{INK}" stroke-width="9" stroke-linecap="round"/><path d="M176 132 L262 120" stroke="#F7EEDC" stroke-width="5" stroke-linecap="round"/><path d="M190 130 L204 128 M218 126 L232 124 M246 122 L258 120.5" stroke="#C0453D" stroke-width="5"/><rect x="170" y="124" width="10" height="38" fill="#6E6A7A" {S2}/>''')
sym("bg7", 360, 220, f'''
<rect width="360" height="220" fill="#D9D0BC"/><rect y="110" width="360" height="110" fill="#7F9488"/><path d="M0 110 L360 110" stroke="{INK}" stroke-width="2.4"/>
<rect x="20" y="22" width="64" height="70" fill="{INK}" {S}/><path d="M20 22 L84 92 M84 22 L20 92" stroke="#55515F" stroke-width="3"/><rect x="14" y="16" width="76" height="82" fill="none" stroke="#8E6B45" stroke-width="5"/>
<rect x="262" y="34" width="74" height="154" fill="#8E6B45" {S}/><rect x="272" y="46" width="54" height="56" fill="#7A5C48" {S2}/><rect x="272" y="112" width="54" height="64" fill="#7A5C48" {S2}/><circle cx="276" cy="108" r="4" fill="#C99B4E" {S2}/><rect x="286" y="20" width="26" height="10" rx="2" fill="#C99B4E" {S2}/>
<path d="M0 220 L0 188 L360 188 L360 220 Z" fill="#B5A58C" {S}/>
<path d="M96 188 L96 166 L130 166 L130 144 L164 144 L164 122 L198 122 L198 100 L232 100 L232 188 Z" fill="#A08D72" {S}/><path d="M96 166 L130 166 M130 144 L164 144 M164 122 L198 122" stroke="{INK}" stroke-width="2.4"/>
<path d="M92 150 L232 62" stroke="{INK}" stroke-width="7" stroke-linecap="round"/><path d="M92 150 L232 62" stroke="#6E5340" stroke-width="3.6" stroke-linecap="round"/><path d="M112 166 L112 138 M146 144 L146 116 M180 122 L180 94 M214 100 L214 73" stroke="{INK}" stroke-width="2.4"/>''')
sym("bg8", 360, 220, f'''
<rect width="360" height="220" fill="#A5A4AE"/><path d="M0 30 C60 10 140 40 220 16 C280 0 330 24 360 14 L360 0 L0 0 Z" fill="#7E7A8B"/><path d="M240 60 C230 30 262 20 256 -4 L300 -4 C296 20 276 34 280 60 Z" fill="#6E6A7A" opacity=".8"/>
<path d="M-4 190 L-4 40 L30 40 L36 20 L70 34 L84 22 L96 60 L130 52 L130 190 Z" fill="#8C8172" {S}/><g fill="#55515F" {S2}><rect x="12" y="62" width="28" height="36"/><rect x="62" y="62" width="28" height="36"/><rect x="12" y="120" width="28" height="36"/></g>
<rect x="60" y="116" width="36" height="46" fill="#F1E2C0" {S2}/><path d="M60 116 L96 116 L96 136 L82 144 L74 132 L60 140 Z" fill="#D9C08A" {S2}/><rect x="70" y="128" width="12" height="4" fill="{INK}"/><path d="M96 136 L82 144 L74 132 L60 140 L60 162 L96 162 Z" fill="#8C8172"/>
<path d="M200 190 L200 70 L230 54 L262 76 L290 60 L330 80 L364 64 L364 190 Z" fill="#9A8F86" {S}/><g fill="#55515F" {S2}><rect x="216" y="92" width="26" height="34"/><rect x="262" y="92" width="26" height="34"/></g>
<path d="M300 190 L300 136 C300 122 348 122 348 136 L348 190 Z" fill="#6E5340" {S}/><rect x="308" y="140" width="32" height="50" fill="#4A3B33" {S2}/><circle cx="334" cy="168" r="3" fill="#C99B4E"/>
<path d="M0 190 L360 190 L360 220 L0 220 Z" fill="#8C8896" {S}/><path d="M120 190 C140 168 176 164 206 190 Z" fill="#9A8F86" {S}/><g fill="#B5A58C" {S2}><path d="M140 186 l12 -10 l14 8 l-4 8 Z M172 180 l14 2 l2 10 l-14 0 Z"/></g>''')
sym("bg9", 360, 220, f'''
<rect width="360" height="220" fill="#F5DDA8"/><circle cx="250" cy="74" r="30" fill="#FFF6D6"/><circle cx="250" cy="74" r="20" fill="#fff"/>
<path d="M0 78 L360 78 L360 220 L0 220 Z" fill="#5DB7B0" {S}/><path d="M0 78 L360 78 L360 96 L0 96 Z" fill="#3E9AA0"/>
<g {S2}><path d="M286 78 l0 -26 l16 22 Z" fill="#F7EEDC"/><path d="M312 78 l0 -34 l20 30 Z" fill="#F7EEDC"/><path d="M340 78 l0 -24 l14 20 Z" fill="#F7EEDC"/><path d="M280 78 l28 0 l-4 6 l-20 0 Z M306 78 l32 0 l-4 7 l-24 0 Z M336 78 l22 0 l-3 5 l-16 0 Z" fill="#6E5340"/></g>
<path d="M150 104 c8 -6 14 -6 22 0 M196 100 c8 -6 14 -6 22 0 M244 106 c8 -6 14 -6 22 0 M300 102 c8 -6 14 -6 22 0" fill="none" stroke="#F7EEDC" stroke-width="3" stroke-linecap="round"/>
<path d="M-10 220 L-10 120 C30 112 70 124 96 150 C110 170 100 200 110 220 Z" fill="#F1E2C0" {S}/>
<path d="M40 130 C36 96 44 64 58 40" fill="none" stroke="{INK}" stroke-width="10" stroke-linecap="round"/><path d="M40 130 C36 96 44 64 58 40" fill="none" stroke="#8E6B45" stroke-width="6" stroke-linecap="round"/>
<g fill="#4A8F6B" {S2}><path d="M58 40 C30 30 12 34 0 46 C20 40 40 42 58 40 Z"/><path d="M58 40 C56 16 40 6 24 4 C40 14 50 26 58 40 Z"/><path d="M58 40 C76 20 96 18 110 24 C92 26 74 32 58 40 Z"/><path d="M58 40 C84 40 100 50 106 64 C92 52 76 46 58 40 Z"/></g>
<ellipse cx="210" cy="186" rx="96" ry="18" fill="#F1E2C0" {S}/><path d="M130 190 C170 200 250 200 290 190" fill="none" stroke="#D9C08A" stroke-width="3"/>''')
sym("bg10", 360, 220, f'''
<rect width="360" height="220" fill="#CFE0E6"/><path d="M0 60 C60 30 150 26 220 40 C270 30 330 40 360 56 L360 100 L0 100 Z" fill="#B9C9BC"/>
<rect x="40" y="52" width="290" height="110" fill="#E3BC6A" {S}/><path d="M34 52 L336 52 L336 40 L34 40 Z" fill="#C99B4E" {S}/>
<rect x="158" y="-6" width="54" height="60" fill="#E3BC6A" {S}/><circle cx="185" cy="18" r="14" fill="#FFFDF8" {S}/><path d="M185 18 L185 8 M185 18 L193 22" stroke="{INK}" stroke-width="2.4" stroke-linecap="round"/>
<g fill="#7A6A52" {S2}>{"".join(f'<rect x="{x}" y="66" width="18" height="30" rx="8"/>' for x in (58, 92, 126, 226, 260, 294))}</g>
<rect x="150" y="96" width="70" height="8" fill="#F7EEDC" {S}/><g stroke="{INK}" stroke-width="2">{"".join(f'<path d="M{x} 96 L{x} 84"/>' for x in range(154, 220, 9))}</g><path d="M150 84 L220 84" stroke="{INK}" stroke-width="3"/><rect x="166" y="60" width="38" height="36" rx="16" fill="#7A6A52" {S2}/>
<path d="M0 162 L360 162 L360 220 L0 220 Z" fill="#C9BBA0" {S}/>''')
sym("bg11", 360, 220, f'''
<rect width="360" height="220" fill="#2B3440"/><rect x="60" y="14" width="240" height="84" fill="#10161D" {S}/><path d="M60 98 L300 98 L300 70 C250 58 200 76 150 66 C110 60 80 70 60 66 Z" fill="#8C8896"/><g fill="#6E6A7A"><ellipse cx="110" cy="84" rx="12" ry="4"/><ellipse cx="200" cy="88" rx="18" ry="5"/><ellipse cx="262" cy="80" rx="9" ry="3"/></g>
<g fill="#F7EEDC"><circle cx="90" cy="30" r="1.4"/><circle cx="140" cy="24" r="1.4"/><circle cx="250" cy="34" r="1.4"/><circle cx="280" cy="22" r="1.4"/><circle cx="200" cy="28" r="1.4"/></g>
<path d="M176 40 l10 0 l4 8 l-18 0 Z M174 48 l-4 8 M190 48 l4 8 M180 48 l0 6 M184 48 l0 6" fill="#E8B549" stroke="#E8B549" stroke-width="1.6"/>
<g {S2}>{"".join(f'<rect x="{x}" y="120" width="52" height="30" fill="#55626C"/><rect x="{x+6}" y="125" width="18" height="12" fill="#12301F"/><rect x="{x+28}" y="125" width="18" height="12" fill="#12301F"/>' for x in (8, 68, 128, 188, 248, 308))}</g>
<g fill="#6FE08A">{"".join(f'<rect x="{x+9}" y="129" width="10" height="2"/><rect x="{x+31}" y="131" width="12" height="2"/>' for x in (8, 68, 128, 188, 248, 308))}</g>
<path d="M0 150 L360 150 L360 220 L0 220 Z" fill="#3A4652" {S}/><path d="M0 184 L360 184" stroke="#2B3440" stroke-width="3"/>''')
