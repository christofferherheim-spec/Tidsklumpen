import asyncio
from playwright.async_api import async_playwright
from PIL import Image
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={'width':430,'height':900})
        await pg.goto('file:///home/claude/tk/index.html'); await pg.wait_for_timeout(200)
        await pg.screenshot(path='shots/h1.png')
        el=await pg.query_selector('#hylla'); await el.scroll_into_view_if_needed()
        await pg.evaluate("document.getElementById('hylla').scrollIntoView()"); await pg.screenshot(path='shots/h2.png')
        await pg.evaluate("location.hash='#ep5'"); await pg.wait_for_timeout(150)
        await pg.screenshot(path='shots/h3.png')
        await pg.evaluate("document.querySelector('#e5r6').scrollIntoView()"); await pg.screenshot(path='shots/h4.png')
        await b.close()
    ims=[Image.open(f'shots/h{i}.png') for i in (1,2,3,4)]
    sh=Image.new('RGB',(430*4,900),'white')
    for k,im in enumerate(ims): sh.paste(im,(k*430,0))
    sh.resize((1376,720)).save('shots/hsheet.png')
asyncio.run(main())
