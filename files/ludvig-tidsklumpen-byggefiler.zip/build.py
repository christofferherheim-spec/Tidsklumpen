# -*- coding: utf-8 -*-
import base64, io, json, random, re, sys
from PIL import Image
from dsl import *
from lib import SYM
import eps3
from eps3 import EPS
from quiz import QUIZ, QUIZ_EN
import tekst_a, tekst_b, tekst_c

# Ny tekst til episode 2 og utover: norsk og engelsk i samme linje. Tegningene hentes fra den gamle ruta.
NY = {**tekst_a.NY, **tekst_b.NY, **tekst_c.NY}
for _n, _d in NY.items():
    _e = EPS[_n - 1]
    _gml, _nye, _en = _e["ruter"], [], []
    for _rute in _d["ruter"]:
        _kilde, _linjer = _rute[0], _rute[1]
        _nb = [("PLAN", l[1][0], l[1][1], l[1][2]) if l[0] == "PLAN" else (l[0], l[1]) for l in _linjer]
        _en.append([l[2] if l[0] == "PLAN" else l[2] for l in _linjer])
        if isinstance(_kilde, tuple):
            _nye.append(R("", [B(_kilde[1]), X("#FFF6D6", .4), V(150, 150, 104, rot=-12), T("BLITS!", 236, 70, 40)], _nb))
        else:
            _o = _gml[_kilde - 1]
            _nye.append(dict(tag=_rute[2] if len(_rute) > 2 else _o["tag"], a=_o["a"], t=_nb, a2=_o["a2"]))
    _e["ruter"] = _nye
    _e.update(oppdrag=_d["oppdrag"][0], gags=_d["gags"], husk=[h[0] for h in _d["husk"]], nerd=[x[0] for x in _d["nerd"]])
    _e["en"] = dict(tittel=_d["tittel_en"], oppdrag=_d["oppdrag"][1], ting=_d["ting_en"], legg=_d["legg_en"],
                    husk=[h[1] for h in _d["husk"]], nerd=[x[1] for x in _d["nerd"]], ruter=_en)
    QUIZ[_n] = [(q[0], q[1], q[2], q[3]) for q in _d["quiz"]]
    QUIZ_EN[_n] = [(q[4], q[5], q[6]) for q in _d["quiz"]]

BELL = "Ludvig tar på Kanels bjelle før de drar. Det gjør han hver gang."
WHO = {"L": ("Ludvig", "lud"), "K": ("Knut", "knut"), "P": ("Pappa, fra døra", "pappa"), "P~": ("Pappa, stille", "pappa stille"),
       "K!": ("Knut, til deg", "knut blunk")}


def svg(layers, cls="art", label="Tegning"):
    return f'<svg class="{cls}" viewBox="0 0 360 220" role="img" aria-label="{esc(label)}">{"".join(layers)}</svg>'


WHO_EN = {"Pappa, fra døra": "Dad, from the door", "Pappa, stille": "Dad, quietly", "Knut, til deg": "Knut, to you", "Far": "Father",
          "Formannen": "The foreman", "Onkelen": "The uncle", "Hatten": "The hat", "Vakta": "The guard", "Stemmen": "The voice", "Sjefen": "The boss"}
TAG_EN = {"Problemet": "The problem", "Det blir verre": "It gets worse", "Enda verre": "Even worse", "Løst!": "Solved!"}
# Tydelige navn på hendelsene: (norsk, engelsk, «bommet med» på engelsk, engelsk tittel)
HVA = {1: ("Dinosaurene, for 66 millioner år siden", "The dinosaurs, 66 million years ago", "66 million years"),
       2: ("Istiden, for 16 000 år siden", "The Ice Age, 16,000 years ago", "16,000 years"),
       3: ("Vikingtiden, år 793", "The Viking Age, year 793", "1,233 years"),
       4: ("Vulkanen i Pompeii, år 79", "The volcano at Pompeii, year 79", "1,947 years"),
       5: ("Pyramidene bygges, for 4500 år siden", "Building the pyramids, 4,500 years ago", "about 4,500 years"),
       6: ("Atombomben blir oppfunnet, 1945", "The atomic bomb is invented, 1945", "81 years"),
       7: ("Krigen i Norge, 1942", "The war in Norway, 1942", "84 years (right date)"),
       8: ("Krigen slutter i Berlin, 1945", "The war ends in Berlin, 1945", "81 years"),
       9: ("Columbus kommer til Amerika, 1492", "Columbus reaches America, 1492", "534 years"),
       10: ("Nelson Mandela blir fri, 1990", "Nelson Mandela walks free, 1990", "36 years"),
       11: ("Månelandingen, 1969", "The Moon landing, 1969", "57 years")}
for _e in EPS:
    _e["sted"] = _e["naar"]
    _e["naar"], _e["naar_en"], _e["bom_en"] = HVA[_e["n"]]


def tx(nb, en=None):
    """Tekst på norsk og engelsk. Uten engelsk vises den norske på begge språk."""
    if en is None or en == nb:
        return esc(nb)
    return f'<span class="nb">{esc(nb)}</span><span class="en" lang="en">{esc(en)}</span>'


def EN(e, k, d=None):
    return (e.get("en") or {}).get(k, d)


def items(t, te=None):
    o = []
    for i, it in enumerate(t):
        k = it[0]
        x = te[i] if te else None
        if k == "N":
            o.append(f'<p class="cap">{tx(it[1], x)}</p>')
        elif k == "PLAN":
            xt, xs, xn = x if x else (None, [None] * len(it[2]), None)
            o.append(f'<div class="plan"><b>{tx(it[1], xt)}</b><ol>{"".join(f"<li>{tx(s, xs[j])}</li>" for j, s in enumerate(it[2]))}</ol>'
                     f'<span class="knutnote">Knut: {tx(it[3], xn)}</span></div>')
        else:
            navn, cls = WHO.get(k, (k, "gjest"))
            o.append(f'<p class="b {cls}"><span class="hvem">{tx(navn, WHO_EN.get(navn))}</span>{tx(it[1], x)}</p>')
    return "".join(o)


def panel(e, i, r):
    tag = f'<span class="tag{" ok" if r["tag"] == "Løst!" else ""}">{tx(r["tag"], TAG_EN.get(r["tag"]))}</span>' if r["tag"] else ""
    lab = f'Episode {e["n"]}, rute {i}'
    if r["a2"]:
        a = (f'<div class="artw"><button class="flipp" type="button" aria-label="Flipp mellom to tegninger">'
             f'<span class="flipphint"><span>{tx("Flipp-o-rama! Trykk fort, mange ganger.", "Flip it! Tap fast, lots of times.")}</span><span class="flippknapp">{tx("Flipp!", "Flip!")}</span></span>'
             f'{svg(r["a"], "art f1", lab)}{svg(r["a2"], "art f2", lab + ", flippet")}</button></div>')
    else:
        a = f'<div class="artw">{svg(r["a"], label=lab)}</div>'
    return f'<section class="rute" id="e{e["n"]}r{i}"><span class="nr">{i}</span>{tag}{a}<div class="txt">{items(r["t"], EN(e, "ruter", [None] * 99)[i - 1])}</div></section>'


def episode(e, nxt):
    n = e["n"]
    ruter = "".join(panel(e, i, r) for i, r in enumerate(e["ruter"], 1))
    neste = (f'<a class="knapp nesteep" data-n="{nxt["n"]}" href="#ep{nxt["n"]}">'
             + tx(f'Neste: Episode {nxt["n"]}. {nxt["tittel"]}', f'Next: Episode {nxt["n"]}. {EN(nxt, "tittel", nxt["tittel"])}') + '</a>' if nxt
             else f'<p class="merkommer">{tx("Du har lest alle episodene som finnes. Flere kommer.", "You have read every episode there is. More are coming.")}</p>')
    qe = QUIZ_EN.get(n)
    spm = "".join(
        f'<div class="spm" data-rute="{rute}"><p class="q">{i}. {tx(q, qe[i - 1][0] if qe else None)}</p><div class="alt">'
        + "".join(f'<button type="button"{" data-r=\"1\"" if k == 0 else ""}>{tx(a, qe[i - 1][1][k] if qe else None)}</button>' for k, a in enumerate(alt))
        + '</div><p class="knutsier" aria-live="polite"></p></div>'
        for i, (q, alt, rute, ord_) in enumerate(QUIZ[n], 1))
    husk_en, nerd_en = EN(e, "husk", [None] * 3), EN(e, "nerd", [None] * 10)
    nerd = (f'<details class="nerd"><summary>{tx("Ti fakta til, for nerder som Knut", "Ten more facts, for nerds like Knut")}</summary><ol>'
            + "".join(f"<li>{tx(h, nerd_en[j])}</li>" for j, h in enumerate(e["nerd"])) + '</ol></details>' if e.get("nerd") else "")
    etter = ""
    if n == 1 and nxt:
        etter = (f'<div class="blimed etter"><h3>{tx("Vil du bli med videre?", "Want to come along?")}</h3>'
                 f'<p>{tx("Følg Ludvig og Knut tilbake til istiden og finn gjenstand 2 av 52. Helt gratis og uten reklame.", "Follow Ludvig and Knut back to the Ice Age and find object 2 of 52. Completely free, with no adverts.")}</p>'
                 f'<div class="skjema"><label for="epost2" class="sr">{tx("E-posten til en voksen", "A grown-up’s e-mail")}</label>'
                 '<input type="email" id="epost2" name="epost" autocomplete="email" inputmode="email" placeholder="E-posten til en voksen">'
                 f'<button class="knapp" type="button" id="meldpaa2">{tx("Send meg reise 2", "Send me journey 2")}</button></div>'
                 '<p class="pameldt" id="pameldt2" aria-live="polite"></p>'
                 f'<p class="smaatt">{tx("Skriv inn e-posten til en voksen. Reise 2 kommer med en gang, og så en ny hver fredag klokka 16.", "Type in a grown-up’s e-mail. Journey 2 arrives at once, and then a new one every Friday at 4 pm.")}</p>'
                 f'<p class="smaatt">{tx("Ny mobil eller nettbrett? Trykk på lenka i e-posten, så er reisene dine åpne der også. Hylla må du fylle på nytt.", "New phone or tablet? Press the link in the e-mail and your journeys are open there too. You will have to fill the shelf again.")}</p></div>')
    ikke = "" if e.get("en") else '<p class="ikkeen en" lang="en">This journey is only in Norwegian so far.</p>'
    return f'''<article class="ep" id="ep{n}" hidden><div class="wrap">
<a class="tilbake" href="#reiser">{tx("Alle reiser", "All journeys")}</a>
<header class="ephode teip"><p class="epnr">Episode {n}</p><h2>{tx(e["tittel"], EN(e, "tittel"))}</h2><p class="naar">{tx(e["naar"], e["naar_en"])}</p>
<p class="linje"><b>{tx("Bommet med:", "Missed by:")}</b> {tx(e["bom"], e["bom_en"])}</p><p class="linje"><b>{tx("Oppdraget:", "The mission:")}</b> {tx(e["oppdrag"], EN(e, "oppdrag"))}</p></header>
{ikke}
{ruter}
<section class="slutt teip">
<div class="quiz" data-n="{n}"><h3>{tx("Knut har tre spørsmål", "Knut has three questions")}</h3><p class="quizinfo">{tx("Svar riktig på alle tre. Da får du med deg tingen til hylla.", "Get all three right. Then you get the thing for the shelf.")}</p>{spm}</div>
<div class="belonning" data-n="{n}" hidden><p class="bestatt">{tx("Tre av tre. «Notert», sier Knut.", "Three out of three. “Logged,” says Knut.")}</p><h3>{tx("Knuts tre ting å huske", "Knut’s three things to remember")}</h3><ol class="husk">{"".join(f"<li>{tx(h, husk_en[j])}</li>" for j, h in enumerate(e["husk"]))}</ol>{nerd}
<div class="samle" data-n="{n}"><svg class="tingikon" viewBox="0 0 48 48" aria-hidden="true"><use href="#o{n}"/></svg>
<div><p class="tingnavn">{tx(f"Gjenstand {n} av 52:", f"Object {n} of 52:")} {tx(e["ting"], EN(e, "ting"))}</p>
<button class="knapp legg" type="button" data-n="{n}">{tx(e["legg"], EN(e, "legg", "Put it on the shelf"))}</button>
<p class="lagt" hidden>{tx("Den ligger på hylla.", "It is on the shelf.")}</p></div></div></div>
{etter}<nav class="videre">{neste}<a class="knapp lys" href="#hylla">{tx("Se hylla", "See the shelf")}</a></nav></section>
</div></article>'''


# ---------------- sjekk mot oppskriften ----------------
def check(e):
    R_ = e["ruter"]
    n = e["n"]
    res = []
    add = lambda navn, ok, info="": res.append((navn, bool(ok), info))
    add("10–12 ruter", 10 <= len(R_) <= 12, str(len(R_)))
    bob = [sum(1 for it in r["t"] if it[0] not in ("N", "PLAN")) for r in R_]
    add("Maks fire bobler per rute", max(bob) <= 4, f"maks {max(bob)}")

    def chars(r):
        c = 0
        for it in r["t"]:
            c += sum(len(s) for s in it[2]) + len(it[1]) + len(it[3]) if it[0] == "PLAN" else len(it[1])
        return c
    snitt = sum(chars(r) for r in R_) / len(R_)
    add("Snitt maks 350 tegn per rute", snitt <= 350, f"{snitt:.0f}")
    tags = [r["tag"] for r in R_]
    add("Faren senest i rute 3", "Problemet" in tags[:3], "")
    order = [tags.index(t) if t in tags else -1 for t in ("Problemet", "Det blir verre", "Enda verre", "Løst!")]
    add("Ett problem i tre trinn, så løst", -1 not in order and order == sorted(order), str([o + 1 for o in order]))
    flips = [i for i, r in enumerate(R_) if r["a2"]]
    add("Én Flipp-o-rama, mellom «enda verre» og «løst»", len(flips) == 1 and order[2] < flips[0] < order[3], str([f + 1 for f in flips]))
    plans = [i for i, r in enumerate(R_) if any(it[0] == "PLAN" for it in r["t"])]
    add("Ludvigs plan (liste) feiler før løsningen", len(plans) == 1 and plans[0] < order[3], str([p + 1 for p in plans]))
    alltext = " ".join(" ".join([it[1]] + (it[2] + [it[3]] if it[0] == "PLAN" else [])) for r in R_ for it in r["t"])
    add("Bjelleritualet, samme ordlyd, i rute 1", any(it[1] == BELL for it in R_[0]["t"]))
    add("Måling nummer N i rute 2", f"Måling nummer {n}." in " ".join(it[1] for it in R_[1]["t"]))
    if n > 1:
        add("«Hylla.» i rute 1", any(it == ("L", "Hylla.") for it in R_[0]["t"]))
    add("Knut ser på leseren én gang", sum(1 for r in R_ for it in r["t"] if it[0] == "K!") == 1)
    add("Gjenstand N av 52", f"Gjenstand {n} av 52" in alltext)
    add("«Brennes til slutt» / «Ikke ennå»", ("brennes til slutt" in alltext or "brenne 52" in alltext) and "Ikke ennå" in alltext)
    last = R_[-1]["t"]
    add("Hjem: pappa spør, svaret er nei, én stille replikk", any(it[0] == "P" for it in last) and any(it[0] == "L" and it[1].startswith("Nei") for it in last) and last[-1][0] == "P~")
    add("Hjem tar maks 1 + 1 rute", R_[0]["a"][0] == B("bgG") and R_[-1]["a"][0] == B("bgG") and all("bgG" not in "".join(r["a"]) for r in R_[1:-1]))
    used = set(re.findall(r'href="#(bg\w+)"', "".join("".join(r["a"]) + "".join(r["a2"] or []) for r in R_))) - {"bgG"}
    add("Ett sted", used <= e["steder"], ", ".join(sorted(used)))
    miss = [g for g in e["gags"] if g not in alltext]
    add("Minst tre gags (finnes i teksten)", len(e["gags"]) >= 3 and not miss, f"mangler {miss}" if miss else str(len(e["gags"])))
    add("Sjanse-gag eller «ikke se den i øynene»", "Sjansen" in alltext or "i øynene" in alltext)
    add("Tre ting å huske", len(e["husk"]) == 3)
    if e.get("nerd"):
        add("Ti fakta for nerder, maks 170 tegn hver", len(e["nerd"]) == 10 and max(len(x) for x in e["nerd"]) <= 170, str(max(len(x) for x in e["nerd"])))
    if e.get("en"):
        en = e["en"]
        add("Engelsk: samme antall ruter og tekster som på norsk", [len(x) for x in en["ruter"]] == [len(r["t"]) for r in R_])
        add("Engelsk: tre ting å huske og ti fakta", len(en["husk"]) == 3 and len(en.get("nerd", [])) == len(e.get("nerd", [])))

        def rutetekst_en(i):
            return " ".join(x if isinstance(x, str) else " ".join([x[0]] + x[1] + [x[2]]) for x in en["ruter"][i - 1])
        qe = QUIZ_EN.get(n, [])
        feil_en = [q[0] for k, q in enumerate(qe) if len(q[1]) != 3 or q[2].lower() not in rutetekst_en(QUIZ[n][k][2]).lower()]
        add("Engelsk: tre spørsmål, og svaret står i samme rute", len(qe) == 3 and not feil_en, str(feil_en) if feil_en else "")
    qz = QUIZ.get(n, [])
    add("Tre spørsmål med tre svar hver", len(qz) == 3 and all(len(q[1]) == 3 and len(set(q[1])) == 3 for q in qz))

    def rutetekst(i):
        return " ".join(" ".join([it[1]] + (it[2] + [it[3]] if it[0] == "PLAN" else [])) for it in R_[i - 1]["t"])
    mangler = [q[0] for q in qz if not (1 <= q[2] <= len(R_)) or q[3].lower() not in rutetekst(q[2]).lower()]
    add("Svaret på hvert spørsmål står i ruta det pekes til", not mangler, str(mangler) if mangler else "")
    knut_long = [it[1] for r in R_ for it in r["t"] if it[0] in ("K", "K!") and len(it[1]) > 150]
    add("Knut forklarer kort", not knut_long, str(len(knut_long)))
    return res, snitt


report = {}
fail = 0
for e in EPS:
    res, snitt = check(e)
    report[e["n"]] = dict(tittel=e["tittel"], ruter=len(e["ruter"]), snitt=round(snitt), sjekk=[(a, b, c) for a, b, c in res])
    for navn, ok, info in res:
        if not ok:
            fail += 1
            print(f"  FEIL ep{e['n']}: {navn} ({info})")
    print(f"ep{e['n']:>2} {e['tittel']:<18} ruter={len(e['ruter'])} snitt={snitt:.0f} tegn  {sum(1 for r in res if r[1])}/{len(res)} ok")
json.dump(report, open("rapport.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("FEIL TOTALT:", fail)

# ---------------- forsiden ----------------
random.seed(7)
im = Image.new("RGBA", (96, 96))
im.putdata([(42, 31, 51, random.randint(0, 46)) for _ in range(96 * 96)])
buf = io.BytesIO()
im.save(buf, "PNG", optimize=True)
GRAIN = base64.b64encode(buf.getvalue()).decode()

SJO = '<path d="M0 196 C60 191 120 201 180 196 C240 191 300 201 360 196 L360 220 L0 220 Z" fill="#5DB7B0" opacity=".55"/>'


def scene(n):
    """Landingsbildet for hver episode: brukes i hoppemaskinen og i lukene."""
    CUR["ep"] = max(n, 1)
    return {
        0: [B("bgG"), V(112, 204, 100), L(214, 204, 112), K(280, 204, 48)],
        1: [B("bg1"), P("stjerne", 150, 62, 30), P("trex", 322, 128, 112), P("pip", 262, 206, 42), V(70, 204, 70), L(140, 200, 98, "o"), K(196, 200, 38)],
        2: [B("bg2"), V(60, 206, 66), L(130, 202, 98, "o"), K(180, 204, 38), P("aya", 262, 204, 96), P("tuk", 322, 208, 46)],
        3: [B("bg3"), V(92, 212, 80), L(206, 212, 100, "f"), K(258, 214, 40), P("ravn", 316, 212, 94)],
        4: [B("bg4"), V(84, 216, 70), L(160, 214, 100, "o"), K(210, 216, 40), P("secunda", 250, 214, 92), P("pimp", 180, 220, 220)],
        5: [B("bg5"), P("slede", 316, 206, 70), V(60, 208, 66), L(124, 206, 98, "o"), K(170, 208, 38), P("nefer", 240, 208, 96), P("krukke", 240, 120, 32)],
        6: [B("bg6"), P("hatt", 112, 212, 120), V(214, 212, 60), L(272, 210, 94, "o"), K(322, 212, 36)],
        7: [B("bg7"), P("solveig", 52, 214, 100), V(196, 216, 50), K(248, 216, 38), L(306, 214, 100, "o", flip=True)],
        8: [B("bg8"), P("sykler", 150, 200, 60), V(40, 216, 54), K(214, 218, 34), L(256, 214, 96, "o"), P("werner", 324, 216, 84)],
        9: [B("bg9"), V(214, 192, 78), L(140, 198, 96, "o"), K(280, 192, 38), SJO],
        10: [B("bg10"), P("mengde", 180, 196, 84), V(60, 216, 60), L(128, 216, 96, "o"), K(178, 218, 38), P("themba", 250, 216, 92)],
        11: [B("bg11"), V(56, 214, 56), L(112, 212, 94, "o"), K(176, 208, 34), P("garman", 290, 216, 116)],
    }[n]


scener = "".join(svg(scene(n), "art sc" + (" on" if n == 0 else ""), "Garasjen" if n == 0 else f'Landing: {EPS[n-1]["naar"]}') for n in range(0, len(EPS) + 1))
UTSNITT = {1: 112, 2: 108, 3: 140, 4: 96, 5: 84, 6: 66, 7: 4, 8: 150, 9: 92, 10: 64, 11: 96}
luker = ""
for e in EPS:
    n = e["n"]
    luker += (f'<a class="luke" href="#ep{n}" data-n="{n}"><span class="glass"><svg viewBox="{UTSNITT[n]} 18 200 200" aria-hidden="true">{"".join(scene(n))}</svg></span>'
              f'<span class="nr">{n}</span><b>{tx(e["tittel"], EN(e, "tittel"))}</b><span class="naar">{tx(e["naar"], e["naar_en"])}</span><span class="status"></span></a>')
luker += ('<span class="luke snart"><span class="glass"><svg viewBox="0 0 200 200" aria-hidden="true"><rect width="200" height="200" fill="#8C9AA0"/>'
          '<text x="100" y="128" text-anchor="middle" font-family="Baloo 2,Comic Relief,sans-serif" font-weight="800" font-size="90" fill="#F6EBD4">?</text></svg></span>'
          f'<b>{tx("Neste reise", "Next journey")}</b><span class="naar">{tx("Ingen vet hvor de lander", "Nobody knows where they will land")}</span></span>')

FH = 'font-family="Caveat,Comic Relief,cursive" font-weight="700"'
FK = 'font-family="Baloo 2,Comic Relief,sans-serif" font-weight="700"'


def merke(x, y, anker, lud, knut, pil):
    """Merkelapp på tegningen: Ludvig med blyant, Knut med rød penn. lud og knut er (norsk, engelsk)."""
    ut = ""
    for spr, l, kn in (("nb", lud[0], knut[0]), ("en", lud[1], knut[1])):
        ut += f'<text class="lu {spr}" x="{x}" y="{y}" text-anchor="{anker}" {FH} font-size="25">{esc(l)}</text>'
        for i, linje in enumerate(kn):
            ut += f'<text class="kn {spr}" x="{x}" y="{y + 19 + i * 16}" text-anchor="{anker}" {FK} font-size="14.5">{esc(linje)}</text>'
    return ut + f'<path d="{pil}" class="pil" marker-end="url(#spiss)"/>'


tegning = f"""<svg viewBox="0 0 360 326" role="img" aria-label="Tegning av Tidsklumpen: en handlevogn med en tørketrommel i, teip, styre og Kanels bjelle. Ludvig har skrevet på navn. Knut har rettet dem.">
<defs><marker id="spiss" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M1 1 L8 5 L1 9" fill="none" stroke="#2A1F33" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></marker></defs>
<use href="#vogn" x="84" y="104" width="192" height="132"/>
{merke(10, 34, "start", ("Tidsmotor!", "Time engine!"), (["Tørketrommel.", "Går på gamle ting."], ["Tumble dryer.", "Runs on old things."]), "M62 74 C70 104 104 132 146 146")}
{merke(350, 34, "end", ("Styring", "Steering"), (["Styrer ikke."], ["Does not steer."]), "M312 90 C306 100 290 108 272 114")}
{merke(10, 292, "start", ("Teip. Holder ALT!", "Tape. Holds ALL!"), (["Holder ingenting."], ["Holds nothing."]), "M36 266 C34 232 66 196 108 182")}
{merke(350, 252, "end", ("Kanels bjelle", "Kanel’s bell"), (["Den eneste delen", "som er viktig."], ["The only part", "that matters."]), "M322 228 C322 192 298 158 271 144")}
</svg>"""


def kort(sid, vb, navn, hva, tekst, extra=""):
    return (f'<section class="kort"><svg viewBox="{vb}" aria-hidden="true"><use href="#{sid}"/></svg><div><h3>{navn}</h3><p class="hva">{tx(*hva)}</p><p>{tx(*tekst)}</p>{extra}</div></section>')


gjeng = (
    kort("luds0", "0 -6 120 191", "Ludvig", ("11 år", "11 years old"),
         ("Verdens dårligste oppfinner og verdens mest utholdende. Tror at alt kan fikses med teip. Det kan det ikke.",
          "The world’s worst inventor, and the one who never gives up. Thinks tape can fix anything. It cannot."))
    + kort("knut", "0 0 160 120", "Knut", ("Rotte, 400 gram", "Rat, 400 grams"),
           ("Har lest bøker. Har nesten alltid rett, og sier det hver gang.", "Has read books. Is nearly always right, and says so every time."),
           f'<button class="knapp liten" type="button" id="sporknut">{tx("Spør Knut om noe", "Ask Knut something")}</button><p class="svar" id="knutsvar" aria-live="polite"></p>')
    + kort("kanel", "0 0 140 80", "Kanel", ("Oransje katt med bjelle", "Orange cat with a bell"),
           ("Gikk ut garasjeporten og ble borte. Det er henne alt sammen handler om.",
            "Walked out through the garage door and disappeared. She is what all of this is about."))
    + f'<section class="kort"><svg viewBox="270 20 90 150" aria-hidden="true"><use href="#bgG" width="360" height="220"/><text x="318" y="34" font-family="Baloo 2,Comic Relief,sans-serif" font-weight="800" font-size="9" fill="#C0453D" text-anchor="middle">LUDVIG!</text></svg><div><h3>{tx("Pappa", "Dad")}</h3><p class="hva">{tx("En stemme fra døra", "A voice from the door")}</p><p>{tx("Du ser ham aldri. Du bare hører ham. Han spør alltid om noe Ludvig ikke har gjort.", "You never see him. You only hear him. He always asks about something Ludvig has not done.")}</p></div></section>'
)
plasser = ""
for i in range(1, 53):
    if i <= len(EPS):
        e = EPS[i - 1]
        plasser += f'<a class="plass apen" href="#ep{i}" data-n="{i}" aria-label="Episode {i}: {esc(e["ting"])}"><svg viewBox="0 0 48 48" aria-hidden="true"><use href="#o{i}"/></svg><span>{i}</span></a>'
    else:
        plasser += f'<span class="plass tom"><span>{i}</span></span>'


def li(nb, en):
    return f"<li>{tx(nb, en)}</li>"


def trinn(h, p):
    return f"<li><h3>{tx(*h)}</h3><p>{tx(*p)}</p></li>"


def rad(dt, dd):
    return f"<div><dt>{tx(*dt)}</dt><dd>{tx(*dd)}</dd></div>"


FORSIDE = f"""<main id="hjem" class="s2"><div class="wrap">
<header class="topp">
<h1><span class="nb">Ludvig og Tids&shy;klumpen</span><span class="en" lang="en">Ludvig and the Time Lump</span></h1>
<p class="lovnad">{tx("Garasjeporten sto åpen. Katten Kanel forsvant. Ludvig har bygd en tidsmaskin for å reise tilbake og lukke porten.", "The garage door was left open. Kanel the cat disappeared. Ludvig has built a time machine to go back and shut the door.")}</p>
<a class="knapp stor startnaa" href="#ep1">{tx("Les første reise nå", "Read the first journey now")}</a>
<p class="startinfo">{tx("Helt gratis. Ingen påmelding.", "Completely free. No sign-up.")}</p>
<div class="rute maskin">
<div class="artw scenen">{scener}<div class="blink" id="blink"></div><p class="stempel" id="stempel" hidden>BOM!</p></div>
<div class="styring">
<button class="hoppknapp" type="button" id="hopp">{tx("HOPP!", "JUMP!")}</button>
<div class="sier"><span class="hvem">Knut</span><p class="logg" id="logg" aria-live="polite">{tx("Den bommer. Hver gang. Trykk, så ser du hvor vi havner.", "It misses. Every time. Press it and see where we land.")}</p></div>
<div class="dymoer"><p class="dymo maal"><span>{tx("Mål", "Target")}</span> {tx("dagen Kanel forsvant", "the day Kanel disappeared")}</p><p class="dymo traff" id="traff"><span>{tx("Traff", "Hit")}</span> {tx("ingen steder", "nowhere yet")}</p></div>
<a class="knapp" id="les" href="#ep1" hidden>Les episode 1</a>
</div></div>

<div class="blimed teip" id="blimed">
<h3>{tx("Få en ny reise hver fredag", "Get a new journey every Friday")}</h3>
<div class="skjema" id="skjema"><label for="epost" class="sr">{tx("E-posten til en voksen", "A grown-up’s e-mail")}</label>
<input type="email" id="epost" name="epost" autocomplete="email" inputmode="email" placeholder="E-posten til en voksen">
<input type="text" id="nettside" name="nettside" class="hon" tabindex="-1" autocomplete="off" aria-hidden="true">
<button class="knapp" type="button" id="meldpaa">{tx("Meld meg på", "Sign me up")}</button></div>
<p class="pameldt" id="pameldt" aria-live="polite"></p>
<p id="blimedtekst">{tx("Første reise kan alle lese med en gang. Vil du ha resten, skriv inn e-posten til en voksen. Da kommer reise 2 med en gang, og så en ny hver fredag klokka 16. Gratis og uten reklame.", "Anyone can read the first journey straight away. If you want the rest, type in a grown-up’s e-mail. Journey 2 arrives at once, and then a new one every Friday at 4 pm. Free, with no adverts.")}</p>
<p class="smaatt">{tx("Adressen brukes bare til å sende reisene. Det står en avmeldingslenke i hver e-post.", "The address is only used to send the journeys. Every e-mail has an unsubscribe link.")}</p>
<p class="smaatt">{tx("Ny mobil eller nettbrett? Trykk på lenka i e-posten, så er reisene dine åpne der også. Hylla må du fylle på nytt.", "New phone or tablet? Press the link in the e-mail and your journeys are open there too. You will have to fill the shelf again.")}</p>
</div>
</header>

<h2 id="plan">{tx("Knuts plan", "Knut’s plan")}</h2>
<div class="plan">
<ol>
{li("Maskinen går på gamle ting.", "The machine runs on old things.")}
{li("Den trenger 52. Én ting fra hver av 52 hendelser i historien.", "It needs 52. One thing from each of 52 events in history.")}
{li("Hver gang vi bommer, lander vi i en hendelse. Der henter vi én ting.", "Every time we miss, we land in an event. There we pick up one thing.")}
{li("Med 52 ting treffer den. Da lukker Ludvig porten.", "With 52 things it hits its target. Then Ludvig shuts the door.")}
</ol>
<p class="lett">{tx("Lett!", "Easy!")} <span>{tx("Nei.", "No.")}</span></p>
</div>

<h2 id="slik">{tx("Din jobb", "Your job")}</h2>
<ol class="trinn">
{trinn(("Les fredagens reise", "Read Friday’s journey"), ("Du får en ny på e-post hver fredag klokka 16. Den tar et kvarter.", "You get a new one by e-mail every Friday at 4 pm. It takes fifteen minutes."))}
{trinn(("Svar på tre spørsmål fra Knut", "Answer three questions from Knut"), ("Svarer du feil, må du vente i åtte sekunder. Han tar tiden.", "Get one wrong and you wait eight seconds. He is timing you."))}
{trinn(("Legg tingen på hylla", "Put the thing on the shelf"), ("Du får én ting fra hver reise. Når hylla har 52, treffer maskinen.", "You get one thing from each journey. When the shelf has 52, the machine hits its target."))}
</ol>

<h2 id="greia">{tx("Tidsklumpen, forklart", "The Time Lump, explained")}</h2>
<p class="omhylla">{tx("Tegnet av Ludvig med blyant. Rettet av Knut med rød penn.", "Drawn by Ludvig in pencil. Corrected by Knut in red pen.")}</p>
<figure class="tegning teip">{tegning}</figure>

<h2 id="reiser">{tx("Velg en reise", "Pick a journey")}</h2>
<p class="omhylla">{tx("Hver luke er en reise til noe som har skjedd.", "Each porthole is a journey to something that really happened.")}</p>
<a class="knapp stor" id="start" href="#ep1">Start med episode 1</a>
<div class="luker">{luker}</div>

<h2 id="hylla">{tx("Hylla", "The shelf")}</h2>
<p class="omhylla">{tx("52 plasser. Les en reise, og legg tingen på hylla.", "52 places. Read a journey and put the thing on the shelf.")} <b><span id="antall">0</span> {tx("av 52", "of 52")}</b> {tx("ting ligger der nå.", "things are there now.")}</p>
<div class="hylle">{plasser}</div>

<h2 id="gjengen">{tx("Møt gjengen", "Meet the gang")}</h2>
<div class="gjeng">{gjeng}</div>

<h2 id="voksne">{tx("For de voksne", "For the grown-ups")}</h2>
<p class="omhylla">{tx("Tegneserie for barn fra 9 til 12 år. De leser om ting som har skjedd, og ler mens de gjør det.", "A comic for children aged 9 to 12. They read about things that really happened, and laugh while they do.")}</p>
<section class="vare">
<h3>{tx("Varedeklarasjon", "What is inside")}</h3>
<p class="per">{tx("Innhold per reise", "Per journey")}</p>
<dl>
{rad(("Lesetid", "Reading time"), ("ca. 15 minutter", "about 15 minutes"))}
{rad(("Ekte hendelser fra historien", "Real events from history"), ("1", "1"))}
{rad(("Spørsmål fra Knut", "Questions from Knut"), ("3", "3"))}
{rad(("Planer som går galt", "Plans that go wrong"), ("minst 3", "at least 3"))}
{rad(("Reklame", "Adverts"), ("0", "0"))}
</dl>
<p class="spor siste">{tx("Kan inneholde spor av læring.", "May contain traces of learning.")}</p>
</section>
<a class="knapp stor" href="#ep1">{tx("Les første reise", "Read the first journey")}</a>

<footer><button class="lenke" type="button" id="tom">{tx("Tøm hylla og start på nytt", "Empty the shelf and start again")}</button></footer>
</div></main>"""

symbols = "".join(f'<symbol id="{i}" viewBox="0 0 {w} {h}">{b}</symbol>' for i, (w, h, b) in SYM.items())
episodes = "".join(episode(e, EPS[i + 1] if i + 1 < len(EPS) else None) for i, e in enumerate(EPS))
ERA = json.dumps([dict(n=e["n"], naar=e["naar"], naar_en=e["naar_en"], bom=e["bom"], bom_en=e["bom_en"], tittel=e["tittel"], tittel_en=EN(e, "tittel", e["tittel"])) for e in EPS], ensure_ascii=False)

CSS = open("stil.css", encoding="utf-8").read().replace("@@GRAIN@@", GRAIN)
JS = open("app.js", encoding="utf-8").read().replace("@@ERA@@", ERA).replace("@@ANTALL@@", str(len(EPS)))

HTML = f"""<!DOCTYPE html>
<html lang="nb">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Ludvig og Tidsklumpen</title>
<meta name="description" content="En gutt, en rotte og en handlevogn som reiser i tid og bommer hver eneste gang. Tegneserie for barn som lærer historie uten å merke det.">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ctext y='.9em' font-size='90'%3E%E2%8F%B3%3C/text%3E%3C/svg%3E">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;700;800&family=Caveat:wght@600;700&display=swap" rel="stylesheet">
<style>{CSS}</style>
</head>
<body>
<svg width="0" height="0" style="position:absolute" aria-hidden="true">{symbols}</svg>
<div id="blits" aria-hidden="true"></div>
<button class="sprakknapp" type="button" id="sprak" hidden>English</button>

{FORSIDE}

{episodes}

<nav class="dokk" aria-label="Meny"><div>
<a href="#hjem" data-til="hjem"><svg viewBox="0 0 180 124" aria-hidden="true"><use href="#vogn"/></svg><span>{tx("Maskinen", "Machine")}</span></a>
<a href="#reiser" data-til="reiser"><svg viewBox="0 0 48 36" aria-hidden="true"><circle cx="24" cy="18" r="15" fill="#D8D3DC" stroke="#2A1F33" stroke-width="2.6"/><circle cx="24" cy="18" r="9.5" fill="#5DB7B0" stroke="#2A1F33" stroke-width="2.2"/><path d="M18 15 C20 11 25 10 29 12" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round"/></svg><span>{tx("Reiser", "Journeys")}</span></a>
<a href="#hylla" data-til="hylla"><svg viewBox="0 0 48 36" aria-hidden="true"><rect x="4" y="26" width="40" height="6" fill="#8E6B45" stroke="#2A1F33" stroke-width="2.4"/><rect x="9" y="10" width="9" height="16" fill="#7FA88C" stroke="#2A1F33" stroke-width="2.2"/><circle cx="26" cy="19" r="7" fill="#C99B4E" stroke="#2A1F33" stroke-width="2.2"/><path d="M35 26 l4 -15 l4 15 Z" fill="#F2C94C" stroke="#2A1F33" stroke-width="2.2" stroke-linejoin="round"/></svg><span>{tx("Hylla", "Shelf")} <b id="dokkantall">0</b></span></a>
<a href="#voksne" data-til="voksne"><svg viewBox="0 0 48 36" aria-hidden="true"><path d="M10 12 L32 12 L30 31 L12 31 Z" fill="#FFFDF8" stroke="#2A1F33" stroke-width="2.4" stroke-linejoin="round"/><path d="M32 16 C41 15 41 26 31 25" fill="none" stroke="#2A1F33" stroke-width="2.4"/><path d="M17 8 c-2 -3 2 -4 0 -7 M24 8 c-2 -3 2 -4 0 -7" fill="none" stroke="#2A1F33" stroke-width="2" stroke-linecap="round"/></svg><span>{tx("Voksne", "Grown-ups")}</span></a>
</div></nav>
<div class="teipmaal" aria-hidden="true"><span id="teipmaal"></span></div>
<script>{JS}</script>
</body>
</html>"""
open("index.html", "w", encoding="utf-8").write(HTML)
# Nettstedmappa som lastes opp til GitHub: siden + episodelista som e-postene bruker
import os
if os.path.isdir("nettsted"):
    open("nettsted/index.html", "w", encoding="utf-8").write(HTML)
    json.dump([dict({k: e[k] for k in ("n", "tittel", "naar", "bom", "oppdrag", "ting")}, en=dict(tittel=EN(e, "tittel", e["tittel"]), naar=e["naar_en"], bom=e["bom_en"], oppdrag=EN(e, "oppdrag", e["oppdrag"]))) for e in EPS],
              open("nettsted/api/_lib/episoder.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("index.html", len(HTML.encode("utf-8")) // 1024, "kB")
sys.exit(1 if fail else 0)
