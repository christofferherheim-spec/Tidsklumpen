// Lokal testserver: serverer nettsted/ og kjører de ekte funksjonene i nettsted/api mot en liksom-database og liksom-Resend.
const http = require('http'), fs = require('fs'), path = require('path'), urlm = require('url');
process.env.KV_REST_API_URL = 'http://db.test'; process.env.KV_REST_API_TOKEN = 'x';
process.env.RESEND_API_KEY = 're_test'; process.env.CRON_SECRET = 'hemmelig'; process.env.SEND_PAUSE_MS = '0'; process.env.OVERSIKT_NOKKEL = 'testnokkel-123456';
const S = new Map(); const sendt = []; let resendFeil = false; let klokke = 0;
const ekteNow = Date.now.bind(Date); Date.now = () => ekteNow() + klokke;
function kjor(c) {
  const [op, k, ...a] = c;
  switch (op) {
    case 'INCR': S.set(k, String((+S.get(k) || 0) + 1)); return +S.get(k);
    case 'EXPIRE': return 1;
    case 'GET': return S.has(k) ? S.get(k) : null;
    case 'SET': S.set(k, String(a[0])); return 'OK';
    case 'DEL': return S.delete(k) ? 1 : 0;
    case 'HSET': { const h = S.get(k) || {}; for (let i = 0; i < a.length; i += 2) h[a[i]] = String(a[i + 1]); S.set(k, h); return 1; }
    case 'HGETALL': { const h = S.get(k) || {}; const f = []; for (const x in h) f.push(x, h[x]); return f; }
    case 'SADD': { const s = S.get(k) || new Set(); s.add(a[0]); S.set(k, s); return 1; }
    case 'SREM': { const s = S.get(k); return s && s.delete(a[0]) ? 1 : 0; }
    case 'SMEMBERS': return [...(S.get(k) || [])];
  }
  throw new Error('ukjent kommando ' + op);
}
global.fetch = async (u, o) => {
  if (String(u).startsWith('http://db.test')) { const cmds = JSON.parse(o.body); return { ok: true, json: async () => cmds.map((c) => ({ result: kjor(c) })) }; }
  if (String(u).startsWith('https://api.resend.com/emails')) {
    if (resendFeil) return { ok: false, status: 500, text: async () => 'nede' };
    sendt.push(JSON.parse(o.body)); return { ok: true, json: async () => ({ id: 'x' }) };
  }
  throw new Error('uventet kall ' + u);
};
const H = {}; for (const f of ['meld-paa', 'status', 'meld-av', 'fredag', 'oversikt']) H[f] = require('./nettsted/api/' + f + '.js');
http.createServer((req, res) => {
  const u = urlm.parse(req.url, true); let body = '';
  req.on('data', (d) => body += d); req.on('end', async () => {
    if (u.pathname === '/__test') { // styring fra testen
      if (u.query.sendt) return res.end(JSON.stringify(sendt));
      if (u.query.resendfeil) { resendFeil = u.query.resendfeil === '1'; return res.end('ok'); }
      if (u.query.dager) { klokke += (+u.query.dager) * 86400000; return res.end('ok'); }
      if (u.query.db) return res.end(JSON.stringify([...S].map(([k, v]) => [k, v instanceof Set ? [...v] : v])));
    }
    const m = u.pathname.match(/^\/api\/([a-z-]+)$/);
    if (m && H[m[1]]) {
      req.query = u.query;
      const ct = req.headers['content-type'] || '';
      req.body = ct.includes('json') ? (() => { try { return JSON.parse(body); } catch (e) { return body; } })() : body;
      res.status = (c) => { res.statusCode = c; return res; };
      res.json = (o) => { res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(o)); };
      res.send = (s) => res.end(s);
      return H[m[1]](req, res);
    }
    if (u.pathname === '/' || u.pathname === '/index.html') { res.setHeader('Content-Type', 'text/html; charset=utf-8'); return res.end(fs.readFileSync(path.join(__dirname, 'nettsted/index.html'))); }
    res.statusCode = 404; res.end('nei');
  });
}).listen(8765, () => console.log('klar'));
