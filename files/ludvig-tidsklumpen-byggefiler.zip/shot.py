import asyncio, sys, os
from playwright.async_api import async_playwright
from PIL import Image
async def main():
    os.makedirs('shots', exist_ok=True)
    errs=[]
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={'width':430,'height':900}, device_scale_factor=1)
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.on('console', lambda m: errs.append(m.text) if m.type=='error' else None)
        await pg.goto('file:///home/claude/tk/index.html')
        await pg.wait_for_timeout(300)
        await pg.screenshot(path='shots/hub.png', full_page=True)
        eps=[int(a) for a in sys.argv[1:]] or list(range(1,12))
        for n in eps:
            await pg.evaluate(f"location.hash='#ep{n}'"); await pg.wait_for_timeout(150)
            arts=await pg.query_selector_all(f'#ep{n} .rute')
            ims=[]
            for i,a in enumerate(arts):
                fl=await a.query_selector('.flipp')
                aw=await a.query_selector('.artw')
                await aw.screenshot(path=f'shots/t.png'); ims.append(Image.open('shots/t.png').copy())
                if fl:
                    await fl.click(); await aw.screenshot(path='shots/t.png'); ims.append(Image.open('shots/t.png').copy())
            w=max(i.width for i in ims); h=max(i.height for i in ims)
            cols=4; rows=(len(ims)+cols-1)//cols
            sh=Image.new('RGB',(cols*w,rows*h),'white')
            for k,im in enumerate(ims): sh.paste(im,((k%cols)*w,(k//cols)*h))
            sh=sh.resize((sh.width*2//3, sh.height*2//3))
            sh.save(f'shots/ep{n}.png')
        await b.close()
    print('JS-feil:', errs)
asyncio.run(main())
