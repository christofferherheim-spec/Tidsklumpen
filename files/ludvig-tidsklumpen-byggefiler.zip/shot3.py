import asyncio
from playwright.async_api import async_playwright
from PIL import Image
async def main():
    errs=[]
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={'width':400,'height':860})
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/tk/index.html'); await pg.wait_for_timeout(250)
        await pg.screenshot(path='shots/n1.png')
        await pg.click('#hopp'); await pg.wait_for_timeout(900); await pg.screenshot(path='shots/n2.png')
        for _ in range(6): 
            await pg.click('#hopp'); await pg.wait_for_timeout(200)
        await pg.wait_for_timeout(800)
        r={}
        r['traff']=await pg.inner_text('#traff'); r['stempel']=await pg.inner_text('#stempel'); r['les']=await pg.inner_text('#les')
        for k,sel in enumerate(['#greia','.greie:nth-of-type(3)','#reiser','.luke:nth-of-type(5)'],3):
            await pg.evaluate(f"document.querySelector('{sel}').scrollIntoView()"); await pg.evaluate("window.scrollBy(0,-10)"); await pg.screenshot(path=f'shots/n{k}.png')
        r['overflow']=await pg.evaluate("document.documentElement.scrollWidth>window.innerWidth")
        await pg.click('.luke[data-n="3"]'); await pg.wait_for_timeout(700)
        r['hash']=await pg.evaluate('location.hash'); r['ep3']=await pg.evaluate("!document.getElementById('ep3').hidden")
        await pg.click('#ep3 .legg'); await pg.click('#ep3 .tilbake'); await pg.wait_for_timeout(700)
        r['luke3']=await pg.inner_text('.luke[data-n="3"] .status'); r['start']=await pg.inner_text('#start')
        r['feil']=errs
        for k,v in r.items(): print(k,':',v)
        await b.close()
    ims=[Image.open(f'shots/n{i}.png') for i in range(1,7)]
    s=Image.new('RGB',(400*6,860)); [s.paste(im,(k*400,0)) for k,im in enumerate(ims)]
    s.crop((0,0,1200,860)).save('shots/na.png'); s.crop((1200,0,2400,860)).save('shots/nb.png')
asyncio.run(main())
