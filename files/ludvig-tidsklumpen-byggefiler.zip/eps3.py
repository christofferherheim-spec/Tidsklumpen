# -*- coding: utf-8 -*-
from dsl import *
from eps2 import EPS, ep, GLO

# ============================== EPISODE 9 ==============================
CUR["ep"] = 9
HAV = lambda y, op=.7: f'<path d="M0 {y} C60 {y-5} 120 {y+5} 180 {y} C240 {y-5} 300 {y+5} 360 {y} L360 220 L0 220 Z" fill="#5DB7B0" opacity="{op}"/>'
BLAD = ('<g fill="#3E7C5B" stroke="#2A1F33" stroke-width="2" stroke-linejoin="round"><path d="M-10 -10 C40 10 70 40 76 84 C40 70 10 50 -10 30 Z"/><path d="M60 -10 C100 0 130 20 140 54 C104 46 76 30 60 10 Z"/>'
        '<path d="M370 -10 C320 6 300 30 296 66 C330 54 356 36 370 18 Z"/><path d="M-10 230 C20 190 50 180 86 186 C60 206 30 222 -10 230 Z"/></g>')


def yari_kano(x, y, flip=False, extra=""):
    return P("yari", x, y - 8, 84, flip) + extra + P("kano", x, y + 12, 34)


ep(n=9, tittel="Hengekøya", naar="Guanahani, 12. oktober 1492", bom="534 år",
   oppdrag="Få Tidsklumpen av sandbanken før tidevannet tar den, og før de fremmede i robåtene finner den.",
   ting="Yaris hengekøye", legg="Legg hengekøya på hylla", steder={"bg9"},
   gags=["Du eier pinnen", "litt en konkurranse", "Du teipet en palme"],
   husk=["Columbus fant ikke USA. Han fant ei strand på Bahamas. Han satte aldri en fot i det som i dag er USA.",
         "Det bodde folk der fra før. Man finner ikke et sted der noen bor. Kano, hengekøye og orkan er ord fra språket deres.",
         "Han trodde han var i Asia. Hele livet."],
   ruter=[
       hjem(9, "Ludvig! Biblioteksboka! Den har vært for sen siden august!", "Åtte ting på hylla. Mynten ville gitt oss et renere hopp."),
       hopp(9, "en rusten sykkelkjede"),
       R("Problemet", [B("bg9"), V(214, 192, 78), L(140, 198, 96, "o"), K(280, 192, 38), HAV(196, .55)], [
           ("N", "Vogna står på en sandbanke midt i en turkis lagune. Vann til hjulene."),
           ("L", "Vi har truffet SOMMER!"),
           ("K", "Oktober 1492. 534 år feil."),
           ("L", "Vannet sto på hjulene i stad. Nå står det på kurven."),
           ("K", "Det heter tidevann. Det kommer to ganger om dagen, og det bryr seg ikke om deg.")]),
       R("", [B("bg9"), '<path d="M44 108 C90 130 130 118 176 140" fill="none" stroke="#2A1F33" stroke-width="8" stroke-linecap="round"/><path d="M44 108 C90 130 130 118 176 140" fill="none" stroke="#E9D9A8" stroke-width="5.5" stroke-linecap="round"/>',
              V(224, 184, 78, rot=7), L(118, 204, 96), K(292, 190, 38), HAV(184, .6), T("SMELL!", 110, 80, 30)], [
           ("PLAN", "Ludvigs plan: Fortøy maskinen", ["Teip vogna til palmen.", "Tretti meter teip.", "Teip holder alt."],
            "Ikke når den er våt. Ikke når den er lang. Ikke i dag."),
           ("N", "Vannet løfter vogna. Teipen strekker seg, synger, og slipper med et smell."),
           ("K", "Fire sekunder. Det er rekord.")]),
       R("Det blir verre", [B("bg9"), V(300, 128, 46, rot=-12), yari_kano(116, 150), L(226, 212, 96, "o"), HAV(176, .6)], [
           ("N", "En kano glir ut av mangroven. Ei jente ser på gutten som står til livet i vann og roper til en handlevogn."),
           ("Yari", "Er den din? Den flyter feil vei."),
           ("N", "Vogna driver mot åpningen i revet. Og bak revet: tre seil, og robåter på vei inn."),
           ("Yari", "Fremmede tar det de finner. Alle vet det.")]),
       R("", [B("bg9"), P("yari", 66, 170, 84), P("kano", 130, 186, 44), P("koye", 150, 162, 34), K(150, 152, 30), L(280, 212, 96), HAV(190, .5)], [
           ("N", "I kanoen ligger en hengekøye. Knut klatrer oppi."),
           ("K!", "Hengekøya er oppfunnet her. I Europa har ingen sett en. Jeg blir her."),
           ("Yari", "Hva er en rotte som snakker?"),
           ("L", "Lang historie."),
           ("K", "Kort historie. Han bygde en tørketrommel, og jeg var i garasjen.")]),
       R("Enda verre", [B("bg9"), V(292, 134, 60, rot=38), '<circle cx="338" cy="92" r="8" fill="#4A4657" stroke="#2A1F33" stroke-width="2.4"/><path d="M326 104 l-6 8 M344 108 l4 8" stroke="#2A1F33" stroke-width="2" stroke-linecap="round"/>',
                        P("yari", 80, 168, 84), L(140, 168, 84, "o"), P("kano", 110, 184, 40), K(46, 166, 28), HAV(190, .5),
                        T("KRASJ!", 270, 60, 34)], [
           ("N", "Vogna treffer revet. Venstre framhjul spretter av og synker. Robåten er femti meter unna."),
           ("L", "Ikke se dem i øynene."),
           ("K", "Jeg ser dem i øynene."),
           ("Yari", "De ser ikke dere. De ser land.")]),
       R("", [B("bg9"), V(292, 134, 60, rot=38), yari_kano(100, 160), P("koye", 196, 170, 26), HAV(186, .5)], [
           ("N", "Yari drar Knut ut av hengekøya. Hun knyter den ene enden i kanoen og den andre rundt styret på vogna."),
           ("Yari", "Strømmen går innover langs revet når sola står opp. Alle vet det."),
           ("L", "Jeg visste ikke det."),
           ("Yari", "Du teipet en palme.")],
         a2=[B("bg9"), yari_kano(60, 160, True), '<path d="M150 170 L214 150" stroke="#2A1F33" stroke-width="9" stroke-linecap="round"/><path d="M150 170 L214 150" stroke="#E9D9A8" stroke-width="6" stroke-linecap="round" stroke-dasharray="4 3"/>',
             V(246, 166, 64, flip=True), HAV(186, .5), T("HAL I VEI!", 190, 70, 36)]),
       R("Løst!", [B("bg9"), P("columbus", 300, 188, 116), P("yari", 60, 204, 88), L(128, 206, 94), K(182, 206, 36),
                   '<path d="M214 204 L220 158" stroke="#6E5340" stroke-width="5" stroke-linecap="round"/>', BLAD], [
           ("N", "Inn i mangroven, ute av syne, i samme sekund som robåten treffer stranda. Gjennom bladene ser de en støvel, en rød kappe og et flagg som stikkes ned i sanden."),
           ("L", "Kan man eie en strand ved å stikke en pinne i den?"),
           ("Yari", "Prøv."),
           ("N", "Ludvig stikker en pinne i sanden."),
           ("K", "Gratulerer. Du eier pinnen.")]),
       R("", [B("bg9"), P("columbus", 292, 188, 130), P("yari", 60, 204, 88), L(128, 206, 94), K(182, 206, 36), BLAD,
              T("¡LAS INDIAS!", 240, 36, 20, -4, "#96322C")], [
           ("N", "Mannen med kappa roper «¡Las Indias!»."),
           ("K", "Han tror han er i India. Vi bommet med 534 år. Han bommet med et helt hav."),
           ("L", "Vi vinner!"),
           ("K", "Det er ikke en konkurranse."),
           ("L", "Det er litt en konkurranse.")]),
       R("", [B("bg9"), P("yari", 96, 204, 92), L(206, 206, 98), K(262, 206, 38), V(318, 200, 56), GLO(150, 80), P("o9", 150, 108, 60)], [
           ("N", "Yari løsner hengekøya fra vogna. Den er våt og salt."),
           ("Yari", "Ta den. Den har allerede reddet maskinen din én gang."),
           ("L", "Hva vil du ha igjen?"),
           ("Yari", "Ingenting. Dere har ikke noe jeg trenger."),
           ("K", "Det var det ærligste noen har sagt til oss. Gjenstand 9 av 52.")]),
       R("", [B("bgG"), V(110, 204, 90, rot=-5), L(206, 202, 104), P("koye", 262, 146, 34), K(262, 136, 30)], [
           ("N", "Vogna skrenser inn i garasjen på tre hjul."),
           ("P", "Biblioteksboka?"),
           ("L", "Nei."),
           ("N", "Ludvig henger hengekøya under hylla. Knut legger seg i den. «Du vet at den skal brennes til slutt», sier Ludvig. «Ikke ennå», sier Knut."),
           ("P~", "Vi hadde en sånn på hytta. Kanel sov i den.")]),
   ])

# ============================== EPISODE 10 ==============================
CUR["ep"] = 10
NATT = X("#1F2A44", .5) + '<rect x="150" y="60" width="70" height="44" fill="#F7D36A" opacity=".75"/>'
MANN = '<circle cx="185" cy="72" r="5" fill="#B8B4BE" stroke="#2A1F33" stroke-width="1.4"/><path d="M178 96 L179 82 C181 77 189 77 191 82 L192 96 Z" fill="#33303E" stroke="#2A1F33" stroke-width="1.4"/>'
ep(n=10, tittel="Er det ham?", naar="Kappstaden, 11. februar 1990", bom="36 år",
   oppdrag="Hjelp Themba å få se mannen hele torget venter på, uten at noen blir most.",
   ting="Bestefars passbok", legg="Legg passboka på hylla", steder={"bg10"},
   gags=["Ham? Ham? …Henne?", "…TAKK!", "ett glass, og han er førti meter unna", "Det er ikke skoens skyld"],
   husk=["Apartheid var en lov. Den delte alt etter hudfarge: benker, strender, skoler, hvor du fikk bo og hvem som fikk stemme.",
         "Nelson Mandela satt i fengsel i 27 år fordi han kjempet mot den. Det var forbudt å vise bilder av ham.",
         "Fire år senere fikk alle stemme. Mandela ble president."],
   ruter=[
       hjem(10, "Ludvig! Pantflaskene! De har stått i gangen siden juni!", "Ni ting på hylla. Hengekøya ville brent fint.",
            extra_cap="Knut klatrer ut av hengekøya med loggboka.", art_extra=(P("koye", 262, 120, 28),)),
       hopp(10, "et gammelt kassettbånd", cap2="Vogna trekker til venstre, som den har gjort siden revet."),
       R("Problemet", [B("bg10"), P("mengde", 180, 196, 84), V(60, 216, 60), L(128, 216, 96, "o"), K(178, 218, 38)], [
           ("N", "Et stort torg i stekende sol. Et gult rådhus med klokketårn. Folk strømmer inn med flagg i svart, grønt og gull."),
           ("L", "Vi har truffet en KONSERT!"),
           ("K", "Kappstaden, 11. februar 1990. 36 år feil."),
           ("L", "Det var plass her i stad."),
           ("K", "Det kommer flere med hvert tog.")]),
       R("", [B("bg10"), P("mengde", 180, 178, 66), P("benk", 86, 214, 76), P("themba", 196, 216, 96), L(266, 216, 100), K(318, 218, 38)], [
           ("N", "Ved kanten står en tom benk med et gammelt skilt: WHITES ONLY. Bare for hvite. Ved siden av står en gutt med en plastpose tett inntil seg."),
           ("L", "Kom, det er plass!"),
           ("Themba", "Ikke for meg."),
           ("L", "Den er jo tom."),
           ("Themba", "Det er derfor den er tom.")]),
       R("", [B("bg10"), P("mengde", 180, 184, 76), L(130, 216, 104), K(130, 122, 34), P("themba", 236, 216, 96)], [
           ("N", "Themba forteller at Nelson Mandela slipper ut i dag, etter 27 år i fengsel. Så kommer han hit. Knut klatrer opp i håret til Ludvig for å holde utkikk."),
           ("K", "Rapport. Rygg. Hatt. Rygg. En mann i et tre."),
           ("L", "Ham? Ham? …Henne?"),
           ("Themba", "Nei. Nei. Nei. Jeg vet ikke hvordan han ser ut. Ingen vet det."),
           ("K!", "Det var forbudt å vise bilder av ham. I 27 år.")]),
       R("Det blir verre", [B("bg10"), P("mengde", 180, 196, 100), '<path d="M40 110 L40 214 M320 110 L320 214" stroke="#2A1F33" stroke-width="6" stroke-linecap="round"/><path d="M40 150 C120 164 240 164 320 150" fill="none" stroke="#2A1F33" stroke-width="8"/><path d="M40 150 C120 164 240 164 320 150" fill="none" stroke="#E9D9A8" stroke-width="5.5"/>',
                            L(140, 218, 96), P("themba", 216, 218, 90), K(270, 218, 36)], [
           ("N", "Timene går. Torget blir trangere og trangere. De presses mot gjerdet."),
           ("PLAN", "Ludvigs plan: Lag plass", ["Teip et sperrebånd mellom to lyktestolper.", "Folk respekterer sperrebånd.", "Egen plass!"],
            "Det er hundre tusen mennesker. Du har én rull."),
           ("N", "Teipen ryker."),
           ("K", "Du sperret av fire meter. Det var fint mens det varte."),
           ("L", "Ikke se dem i øynene."),
           ("K", "Det er hundre tusen øyne, Ludvig.")]),
       R("Enda verre", [B("bg10"), P("mengde", 180, 190, 96), V(266, 216, 60, rot=86), L(140, 222, 92, "o", rot=-62), P("mengde", 150, 262, 120),
                        T("HAN KOMMER!", 180, 44, 28)], [
           ("N", "Et bilhorn. Noen roper at han kommer. Hele torget lener seg samtidig. Vogna velter. Det sprukne brilleglasset spretter ut og knases under en hæl."),
           ("L", "KNUT!"),
           ("K", "Her. Under en sko. Det er ikke skoens skyld.")]),
       R("", [B("bg10"), P("mengde", 180, 190, 96), P("themba", 150, 224, 84), L(206, 224, 84, "o"), P("mengde", 200, 268, 120)], [
           ("N", "Themba griper Ludvig i genseren."),
           ("Themba", "Ikke dytt imot! Gå på skrå, én skulder først. Jeg har vært i store begravelser i Langa."),
           ("N", "De glir sidelengs gjennom folkehavet. Helt ut til kanten. Opp på benken.")],
         a2=[B("bg10"), P("mengde", 180, 196, 100), P("benk", 236, 216, 70), P("themba", 208, 170, 92), L(270, 170, 94), K(270, 82, 30),
             T("OPP!", 100, 70, 46)]),
       R("Løst!", [B("bg10"), NATT, MANN, P("mengde", 180, 206, 96), L(300, 250, 96), K(300, 162, 30)], [
           ("N", "Det har blitt kveld. Lyset tennes på balkongen. En liten mann med grått hår, langt unna."),
           ("K", "Grått hår. Dress. Han leter i lommene. Han har glemt brillene."),
           ("L", "Han kan låne mine!"),
           ("K", "De har ett glass, og han er førti meter unna.")]),
       R("", [B("bg10"), NATT, MANN, '<path d="M190 80 L196 66" stroke="#33303E" stroke-width="4" stroke-linecap="round"/><circle cx="197" cy="64" r="3" fill="#B8B4BE" stroke="#2A1F33" stroke-width="1"/>',
              P("mengde", 180, 206, 96), T("AMANDLA!", 180, 150, 40, -4, "#E8B549")], [
           ("N", "Mannen løfter knyttneven. Hele torget roper: AMANDLA!"),
           ("L", "…TAKK!"),
           ("Themba", "Awethu. Det betyr at makta er vår."),
           ("L", "Er det ham?"),
           ("Themba", "Ja.")]),
       R("", [B("bg10"), X("#1F2A44", .4), P("benk", 80, 214, 70), P("themba", 180, 216, 96), L(262, 216, 100), K(314, 218, 38), GLO(220, 84, 34), P("o10", 220, 112, 56)], [
           ("N", "Themba åpner plastposen. En liten, slitt bok full av stempler."),
           ("Themba", "Bestefars passbok. Han måtte vise den til politiet for å få være i byen. Fordi han var svart."),
           ("K", "Loven het apartheid. Den delte alt etter hudfarge. Benker også."),
           ("Themba", "Maskinen deres brenner gamle ting. La denne få noen hjem."),
           ("K", "Gjenstand 10 av 52.")]),
       R("", [B("bgG"), V(110, 204, 90, rot=-5), L(206, 202, 104), K(266, 202, 42), P("koye", 262, 120, 28)], [
           ("N", "Vogna skrenser inn i garasjen, til venstre som vanlig."),
           ("P", "Pantflaskene?"),
           ("L", "Nei."),
           ("N", "Ludvig legger passboka på hylla. «Du vet at den skal brennes til slutt», sier Knut. «Ja», sier Ludvig. «Ikke ennå. Men den skal det.»"),
           ("P~", "Jeg hang opp en lapp til på butikken i dag. Med bilde. Så folk vet hvordan hun ser ut.")]),
   ])

# ============================== EPISODE 11 ==============================
CUR["ep"] = 11
ALARM = '<rect x="60" y="14" width="240" height="84" fill="#C0453D" opacity=".55"/>' + T("1202", 180, 72, 44, 0, "#FFF6D6")
ep(n=11, tittel="Jukselappen", naar="Houston, 20. juli 1969", bom="57 år",
   oppdrag="Hjelp Jack å finne lappen sin før datamaskinen stopper månelandingen.",
   ting="Lappen «1202 = GO»", legg="Legg lappen på hylla", steder={"bg11"},
   gags=["Vi har truffet KINO", "Det går opp i null", "Noter datoen", "rottesikkel"],
   husk=["20. juli 1969 landet de første menneskene på månen: Neil Armstrong og Buzz Aldrin.",
         "Datamaskinen om bord var mye svakere enn en mobiltelefon. Den slo alarm fem ganger på vei ned.",
         "Jack Garman var 24 år. Han hadde skrevet alle alarmkodene på en lapp. Derfor kunne han svare på noen sekunder."],
   ruter=[
       hjem(11, "Ludvig! Posten! Postkassa er så full at den har begynt å spy!", "Ti ting på hylla. Passboka …",
            art_extra=(P("koye", 262, 120, 28),)),
       hopp(11, "en fjernkontroll uten batterilokk"),
       R("Problemet", [B("bg11"), V(56, 214, 56), L(112, 212, 94, "o"), P("strimler", 176, 218, 26), K(176, 208, 34), P("garman", 290, 216, 116)], [
           ("N", "Et mørkt rom fullt av menn i hvite skjorter. Alle stirrer på skjermer. Ingen ser en handlevogn."),
           ("K", "Houston, 20. juli 1969. 57 år feil. Om tolv minutter lander de første menneskene på månen."),
           ("L", "Vi har truffet KINO!"),
           ("N", "Under et bord finner Knut en bunke papir. Han river den i strimler og lager seg et rede. Ved bordet roter en ung mann i skuffene."),
           ("Jack", "Lappen min! Hvor er lappen med alarmkodene?")]),
       R("", [B("bg11"), P("konsoll", 290, 216, 96), P("garman", 206, 216, 116), L(80, 212, 96, "f"), P("strimler", 136, 218, 30), K(136, 206, 36)], [
           ("N", "Mannen heter Jack. Han er 24 år og kan datamaskinen i månefartøyet bedre enn noen. Alle alarmkodene sto på en lapp han hadde skrevet for hånd."),
           ("Jack", "Hvis datamaskinen piper, må jeg si GO eller STOPP på noen sekunder."),
           ("L", "Knut. Hva er redet ditt laget av?"),
           ("K", "…Papir. Med tall på.")]),
       R("Det blir verre", [B("bg11"), ALARM, P("konsoll", 300, 216, 90), P("garman", 220, 216, 116), L(90, 212, 96, "o"), K(146, 214, 36), T("PIIIP!", 70, 124, 24, -8, "#F7D36A")], [
           ("N", "Fra høyttaleren, 384 000 kilometer unna: «Program-alarm. 1202.» Det blir helt stille i rommet."),
           ("Jack", "1202 … 1202 … den sto på lappen!"),
           ("Sjefen", "Jack! GO eller STOPP? Vi har tjue sekunder!"),
           ("K!", "Alarmen kom på ordentlig. Akkurat sånn. Bare uten rotte.")]),
       R("", [B("bg11"), ALARM, L(150, 212, 100), '<circle cx="200" cy="170" r="22" fill="#FFFDF8" stroke="#2A1F33" stroke-width="2.4"/><path d="M182 162 L218 178 M186 180 L214 160 M200 148 L200 192" stroke="#E9D9A8" stroke-width="6" stroke-linecap="round"/>',
              K(256, 214, 38), P("strimler", 300, 218, 30), P("teip", 100, 216, 22)], [
           ("PLAN", "Ludvigs plan: Fiks lappen", ["Finn alle strimlene.", "Teip dem sammen.", "Les hva 1202 betyr.", "Redd månen."],
            "Det er 400 strimler. Du har 20 sekunder."),
           ("N", "Ludvig teiper som en gal. Det blir en ball."),
           ("K", "Du har laget en papirklump. Den sier ingenting om 1202.")]),
       R("Enda verre", [B("bg11"), ALARM, P("garman", 240, 216, 116), '<path d="M206 150 C196 120 204 100 222 96 M274 150 C284 120 276 100 258 96" fill="none" stroke="#2A1F33" stroke-width="13" stroke-linecap="round"/><path d="M206 150 C196 120 204 100 222 96 M274 150 C284 120 276 100 258 96" fill="none" stroke="#FBF4E2" stroke-width="9" stroke-linecap="round"/>',
                        L(96, 212, 96, "o"), K(150, 214, 36), T("10 … 9 … 8 …", 110, 128, 18, 0, "#F7D36A")], [
           ("N", "Ti sekunder. Jack har hendene i håret. Hvis ingen svarer, må landingen avbrytes. Tre mann har fløyet i fire dager for dette."),
           ("L", "Ikke se alarmen i øynene."),
           ("K", "Ludvig. Løft meg opp. Det sitter noe på foten min.")]),
       R("", [B("bg11"), ALARM, P("garman", 250, 216, 116), L(120, 212, 100, "o"), K(120, 116, 34), P("strimler", 60, 218, 26)], [
           ("N", "Én strimmel sitter klistret til bakpoten til Knut. Våt av rottesikkel. Ludvig river den løs og holder den opp. Det står: 1202 = GO."),
           ("Jack", "GO! Den har bare for mye å gjøre! Den klarer det! Vi er GO på den alarmen!")],
         a2=[B("bg11"), P("garman", 250, 216, 116), L(120, 212, 100, "o"), GLO(104, 78, 30), P("o11", 104, 104, 52), K(180, 214, 36), T("GO!", 250, 70, 60, -6, "#4A8F6B")]),
       R("Løst!", [B("bg11"), '<path d="M170 60 l20 0 l8 16 l-36 0 Z M168 76 l-6 12 M198 76 l6 12" fill="#E8B549" stroke="#E8B549" stroke-width="2.4"/>', P("garman", 262, 216, 116),
                   L(110, 212, 100, "o"), K(176, 214, 38), T("JAAA!", 110, 120, 30, -8, "#F7D36A")], [
           ("N", "«Vi er GO», sier sjefen. Noen minutter senere, fra månen: «Ørnen har landet.» Hele rommet hyler. Menn i hvite skjorter klemmer hverandre."),
           ("L", "Vi reddet månelandingen!"),
           ("K", "Vi ødela den nesten. Så reddet vi den. Det går opp i null."),
           ("L", "Null er bra!")]),
       R("", [B("bg11"), P("konsoll", 250, 216, 110), P("o11", 250, 150, 30), P("teip", 316, 216, 24), P("garman", 150, 216, 116), L(52, 212, 96), GLO(96, 60, 26), P("o11", 96, 82, 44)], [
           ("N", "Ludvig teiper strimmelen fast på bordet til Jack. Teipen holder. Ludvig stirrer på den."),
           ("L", "Den holdt."),
           ("K", "Noter datoen."),
           ("Jack", "Ta lappen med dere. Jeg kan den utenat nå. Jeg glemmer aldri 1202."),
           ("N", "Teiprullen blir stående igjen i Houston. Den har endelig gjort jobben sin. «Gjenstand 11 av 52», sier Knut.")]),
       R("", [B("bgG"), V(110, 204, 90, rot=-5), L(206, 202, 104), K(266, 202, 42), P("koye", 262, 120, 28)], [
           ("P", "Posten?"),
           ("L", "Nei."),
           ("N", "Gjennom garasjevinduet ser Ludvig månen. «Du vet at lappen skal brennes til slutt», sier Knut. «Ikke ennå», sier Ludvig."),
           ("P~", "Kanel satt alltid i vinduet når det var fullmåne. Jeg tror hun ser på den nå også.")]),
   ])
