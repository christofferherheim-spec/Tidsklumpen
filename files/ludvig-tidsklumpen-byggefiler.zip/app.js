(function () {
  var KEY = 'tidsklumpen-hylla-v1', ANTALL = @@ANTALL@@, ERA = @@ERA@@;
  var har = {};
  try { JSON.parse(localStorage.getItem(KEY) || '[]').forEach(function (n) { har[n] = true; }); } catch (e) {}
  function lagre() { try { localStorage.setItem(KEY, JSON.stringify(Object.keys(har).map(Number))); } catch (e) {} }
  /* Fredagsreisene: på tidsklumpen.no låses en ny episode opp per fredag. I forhåndsvisning og lokalt er alt åpent. */
  var LIVE = /(^|\.)tidsklumpen\.no$|\.vercel\.app$|^localhost$/.test(location.hostname);
  var NK = 'tidsklumpen-nokkel-v1', OK = 'tidsklumpen-opp-v1', nokkel = '', opp = 0;
  try { nokkel = localStorage.getItem(NK) || ''; opp = +localStorage.getItem(OK) || 0; } catch (e) {}
  try {
    var qt = new URLSearchParams(location.search).get('t');
    if (qt && /^[a-f0-9]{32}$/.test(qt)) {
      nokkel = qt; if (opp < 1) opp = 1;
      try { localStorage.setItem(NK, nokkel); localStorage.setItem(OK, opp); } catch (e) {}
      history.replaceState(null, '', location.pathname + location.hash);
    }
  } catch (e) {}
  function apen(n) { return !LIVE || n === 1 || !!har[n] || n <= opp; } /* reise 1 er åpen for alle */
  function $(s, r) { return (r || document).querySelector(s); }
  /* Språk: norsk eller engelsk. Knappen vises i forhåndsvisning, og på tidsklumpen.no bare med ?sprak=en i adressen. */
  var SK = 'tidsklumpen-sprak-v1', sprak = 'nb';
  try { sprak = localStorage.getItem(SK) === 'en' ? 'en' : 'nb'; } catch (e) {}
  var sq = /[?&]sprak=(en|nb)/.exec(location.search);
  if (sq) { sprak = sq[1]; try { localStorage.setItem(SK, sprak); } catch (e) {} }
  var SPRAK_SYNLIG = true;
  var S = {
    nb: { paHylla: '✓ På hylla', kommerFredag: 'Kommer fredag', laast: 'Låst', nesteReise: 'Neste reise',
      alle: 'Alle {0} tingene ligger på hylla. Se hylla', nesteFredag: 'Neste reise kommer fredag klokka 16', meldDeg: 'Meld deg på og få neste reise',
      start: 'Start med episode {0}', fortsett: 'Fortsett med episode {0}',
      medAlle: 'Du er med, og alle reisene som er ferdige er låst opp. Nye kommer på e-post når de er klare.',
      med: 'Du er med. {0} av {1} reiser er låst opp. Neste kommer på e-post fredag klokka 16.',
      ikkeKommet: 'Den reisen har ikke kommet ennå. Den kommer på e-post en fredag.', erLaast: 'Den reisen er låst. Meld deg på, så kommer reise 2 med en gang.',
      feil: '«Feil. Svaret står i rute {0}. Les den en gang til.» Du kan prøve igjen om {1} sekunder. ', gaTil: 'Gå til rute {0}',
      provIgjen: '«Prøv igjen. Svaret står fortsatt i rute {0}.» ', traff: 'Traff', maaling: 'Måling nummer {0}. Notert.',
      les: 'Les episode {0}: {1}', kommerEnFredag: 'Episode {0} kommer en fredag', meldForLese: 'Meld deg på for å lese',
      tom: 'Tøm hylla og start på nytt', sikker: 'Sikker? Trykk én gang til for å tømme hylla',
      ikkeEpost: 'Det ser ikke ut som en e-postadresse. Knut har sjekket to ganger.',
      forhaands: 'Påmeldingen virker når siden ligger på tidsklumpen.no. Her i forhåndsvisningen er alle reisene åpne.', sender: 'Sender ...',
      sjekk: 'Sjekk e-posten. Reise 2 ligger der nå. Trykk på knappen i e-posten, så åpner reisen seg her.',
      galt: 'Noe gikk galt. Prøv igjen om litt.', kontakt: 'Fikk ikke kontakt. Sjekk nettet og prøv igjen.', ph: 'E-posten til en voksen', bytt: 'English' },
    en: { paHylla: '✓ On the shelf', kommerFredag: 'Coming Friday', laast: 'Locked', nesteReise: 'Next journey',
      alle: 'All {0} things are on the shelf. See the shelf', nesteFredag: 'The next journey comes on Friday at 4 pm', meldDeg: 'Sign up and get the next journey',
      start: 'Start with episode {0}', fortsett: 'Continue with episode {0}',
      medAlle: 'You are in, and every finished journey is unlocked. New ones arrive by e-mail when they are ready.',
      med: 'You are in. {0} of {1} journeys are unlocked. The next one arrives by e-mail on Friday at 4 pm.',
      ikkeKommet: 'That journey has not arrived yet. It comes by e-mail on a Friday.', erLaast: 'That journey is locked. Sign up and journey 2 arrives straight away.',
      feil: '“Wrong. The answer is in panel {0}. Read it again.” You can try again in {1} seconds. ', gaTil: 'Go to panel {0}',
      provIgjen: '“Try again. The answer is still in panel {0}.” ', traff: 'Hit', maaling: 'Jump {0}. Logged.',
      les: 'Read episode {0}: {1}', kommerEnFredag: 'Episode {0} comes on a Friday', meldForLese: 'Sign up to read',
      tom: 'Empty the shelf and start again', sikker: 'Sure? Press once more to empty the shelf',
      ikkeEpost: 'That does not look like an e-mail address. Knut checked twice.',
      forhaands: 'Sign-up works when the page is on tidsklumpen.no. Here in the preview every journey is open.', sender: 'Sending ...',
      sjekk: 'Check your e-mail. Journey 2 is there now. Press the button in the e-mail and the journey opens here.',
      galt: 'Something went wrong. Try again in a moment.', kontakt: 'No connection. Check the internet and try again.', ph: 'A grown-up’s e-mail', bytt: 'Norsk' }
  };
  function t(k) { var s = S[sprak][k]; for (var i = 1; i < arguments.length; i++) { s = s.replace('{' + (i - 1) + '}', arguments[i]); } return s; }
  function sitat(s) { return sprak === 'en' ? '“' + s + '”' : '«' + s + '»'; }
  function settSprak() {
    document.documentElement.setAttribute('data-sprak', sprak); document.documentElement.lang = sprak === 'en' ? 'en' : 'nb';
    var kn = document.getElementById('sprak'); if (kn) { kn.textContent = t('bytt'); kn.hidden = !SPRAK_SYNLIG; }
    document.documentElement.classList.toggle('harsprak', SPRAK_SYNLIG);
    ['epost', 'epost2'].forEach(function (id) { var ep = document.getElementById(id); if (ep) ep.placeholder = t('ph'); });
  }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }

  function tegn() {
    var n = Object.keys(har).length, neste = 0;
    for (var i = 1; i <= ANTALL; i++) { if (!har[i]) { neste = i; break; } }
    $('#antall').textContent = n; $('#dokkantall').textContent = n;
    $$('.plass.apen').forEach(function (p) {
      var k = +p.dataset.n;
      p.classList.toggle('har', !!har[k]);
      p.classList.toggle('neste', k === neste);
    });
    $$('.luke[data-n]').forEach(function (a) {
      var k = +a.dataset.n;
      a.classList.toggle('har', !!har[k]);
      a.classList.toggle('neste', k === neste);
      a.classList.toggle('laast', !apen(k));
      $('.status', a).textContent = har[k] ? t('paHylla') : (!apen(k) ? (nokkel && k === opp + 1 ? t('kommerFredag') : t('laast')) : (k === neste ? t('nesteReise') : ''));
    });
    $$('.samle').forEach(function (s) {
      var k = +s.dataset.n;
      $('.legg', s).hidden = !!har[k];
      $('.lagt', s).hidden = !har[k];
    });
    $$('.quiz').forEach(function (q) {
      var k = +q.dataset.n, ferdig = !!har[k] || $$('.spm.ok', q).length === 3;
      q.hidden = !!har[k];
      $('.belonning[data-n="' + k + '"]').hidden = !ferdig;
    });
    var st = $('#start');
    if (neste === 0) { st.textContent = t('alle', ANTALL); st.setAttribute('href', '#hylla'); }
    else if (!apen(neste)) { st.textContent = nokkel ? t('nesteFredag') : t('meldDeg'); st.setAttribute('href', '#blimed'); }
    else { st.textContent = t(n === 0 ? 'start' : 'fortsett', neste); st.setAttribute('href', '#ep' + neste); }
    $$('.nesteep').forEach(function (l) {
      var k = +l.dataset.n;
      if (!l.dataset.html) l.dataset.html = l.innerHTML;
      if (apen(k)) { l.innerHTML = l.dataset.html; } else { l.textContent = t('nesteFredag'); }
      l.hidden = !apen(k) && !nokkel && !!$('.etter', l.closest('article'));
      l.setAttribute('href', apen(k) ? '#ep' + k : '#reiser');
    });
    var med = LIVE && !!nokkel;
    $('#skjema').hidden = med;
    $$('.etter').forEach(function (b) { b.hidden = med; });
    if (med) {
      $('#blimedtekst').textContent = opp >= ANTALL
        ? t('medAlle')
        : t('med', opp, ANTALL);
    }
  }

  var forrige = null;
  function vis() {
    var h = location.hash.replace('#', ''), ep = /^ep\d+$/.test(h) ? document.getElementById(h) : null;
    if (ep && !apen(+h.slice(2))) {
      $('#pameldt').textContent = nokkel ? t('ikkeKommet') : t('erLaast');
      location.hash = '#blimed'; return;
    }
    $('#hjem').hidden = !!ep;
    $$('article.ep').forEach(function (a) { a.hidden = a !== ep; });
    tegn();
    if (ep && forrige !== h) { var bl = $('#blits'); bl.classList.remove('gaa'); void bl.getBoundingClientRect(); bl.classList.add('gaa'); }
    forrige = h;
    var el = (!ep && h && h !== 'hjem') ? document.getElementById(h) : null;
    if (el && $('#hjem').contains(el)) { el.scrollIntoView(); } else { window.scrollTo(0, 0); }
    rull();
  }
  var MENY = ['hjem', 'reiser', 'hylla', 'voksne'], venter = false;
  function rull() {
    var iEp = $('#hjem').hidden, her = 'hjem', maal = $('#teipmaal');
    if (iEp) {
      her = 'reiser';
      var hoyde = document.documentElement.scrollHeight - window.innerHeight;
      maal.style.width = (hoyde > 0 ? Math.min(100, Math.max(2, window.scrollY / hoyde * 100)) : 0) + '%';
    } else {
      MENY.forEach(function (id) { var e = document.getElementById(id); if (id !== 'hjem' && e && e.getBoundingClientRect().top < window.innerHeight * 0.45) { her = id; } });
    }
    maal.classList.toggle('av', !iEp);
    $$('.dokk a').forEach(function (a) { var p = a.dataset.til === her; a.classList.toggle('her', p); if (p) { a.setAttribute('aria-current', 'true'); } else { a.removeAttribute('aria-current'); } });
  }
  window.addEventListener('scroll', function () { if (!venter) { venter = true; requestAnimationFrame(function () { venter = false; rull(); }); } }, { passive: true });
  $$('.dokk a').forEach(function (a) { a.addEventListener('click', function (ev) { if (location.hash === a.getAttribute('href')) { ev.preventDefault(); vis(); } }); });
  window.addEventListener('hashchange', vis);

  document.addEventListener('click', function (ev) {
    var f = ev.target.closest('.flipp');
    if (f) { f.classList.toggle('pa'); return; }
    var ga = ev.target.closest('.garute');
    if (ga) { var ru = $$('.rute', ga.closest('article'))[+ga.dataset.rute - 1]; if (ru) ru.scrollIntoView({ behavior: 'smooth', block: 'start' }); return; }
    var sv = ev.target.closest('.alt button');
    if (sv) { svar(sv); return; }
    var l = ev.target.closest('.legg');
    if (l) {
      har[+l.dataset.n] = true; lagre(); tegn();
      var ik = $('.tingikon', l.closest('.samle'));
      ik.classList.remove('dropp'); void ik.getBoundingClientRect(); ik.classList.add('dropp');
    }
  });

  /* Knuts tre spørsmål: tingen kommer ikke på hylla før alle tre er riktige. Feil svar gir ventetid og et hint om ruta. */
  var ROS = ['Riktig. Notert.', 'Stemmer. Jeg er nesten imponert.', 'Riktig. Du har faktisk lest.', 'Korrekt. Det skjer sjelden her i vogna.'];
  var ROS_EN = ['Correct. Logged.', 'Right. I am almost impressed.', 'Correct. You actually read it.', 'Correct. That rarely happens in this cart.'];
  var rosNr = 0;
  function stokk(boks) { var b = [].slice.call(boks.children); for (var i = b.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = b[i]; b[i] = b[j]; b[j] = t; } b.forEach(function (x) { boks.appendChild(x); }); }
  $$('.alt').forEach(stokk);
  function svar(kn) {
    var spm = kn.closest('.spm'), sier = $('.knutsier', spm), rute = spm.dataset.rute;
    if (spm.classList.contains('ok') || spm.classList.contains('vent')) return;
    if (kn.dataset.r === '1') {
      spm.classList.add('ok'); kn.classList.add('riktig');
      $$('.alt button', spm).forEach(function (b) { b.disabled = true; });
      sier.textContent = sitat((sprak === 'en' ? ROS_EN : ROS)[rosNr++ % ROS.length]);
      var quiz = spm.closest('.quiz');
      if ($$('.spm.ok', quiz).length === 3) {
        tegn();
        var bel = $('.belonning[data-n="' + quiz.dataset.n + '"]');
        setTimeout(function () { bel.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 350);
      }
      return;
    }
    var feil = (+spm.dataset.feil || 0) + 1, igjen = 8 * feil;
    spm.dataset.feil = feil; spm.classList.add('vent'); kn.classList.add('feil');
    $$('.alt button', spm).forEach(function (b) { b.disabled = true; });
    function skriv() {
      sier.innerHTML = t('feil', rute, igjen) + '<button class="garute" type="button" data-rute="' + rute + '">' + t('gaTil', rute) + '</button>';
    }
    skriv();
    var tm = setInterval(function () {
      igjen--;
      if (igjen > 0) { skriv(); return; }
      clearInterval(tm); spm.classList.remove('vent');
      $$('.alt button', spm).forEach(function (b) { b.disabled = b.classList.contains('feil'); });
      sier.innerHTML = t('provIgjen', rute) + '<button class="garute" type="button" data-rute="' + rute + '">' + t('gaTil', rute) + '</button>';
    }, 1000);
  }

  var KNUT = ['Jeg er 400 gram, men jeg dytter.', 'Notert.', 'Teip er ikke en plan, Ludvig.', 'Sjansen for at det går bra: fire prosent.',
    'Jeg hater at det er en god idé.', 'Det begynner å bli en liste.', 'Jeg har lest slutten.', 'Hylla? Vi kunne brent noe fra hylla.'];
  function runde(liste) { var i = 0; return function () { var s = liste[i % liste.length]; i++; return s; }; }
  var KNUT_EN = ['I weigh 400 grams, but I push.', 'Logged.', 'Tape is not a plan, Ludvig.', 'Chance of this going well: four percent.',
    'I hate that it is a good idea.', 'It is starting to be a list.', 'I have read the ending.', 'The shelf? We could burn something from the shelf.'];
  var nk = runde(KNUT), nkE = runde(KNUT_EN);
  function rist(kn) { var s = $('svg', kn.closest('.kort')); s.classList.remove('risting'); void s.getBoundingClientRect(); s.classList.add('risting'); }
  $('#sporknut').addEventListener('click', function () { $('#knutsvar').textContent = sitat(sprak === 'en' ? nkE() : nk()); rist(this); });
  var hoppNr = 0;
  $('#hopp').addEventListener('click', function () {
    var e = ERA[hoppNr % ERA.length]; hoppNr++; document.body.classList.add('trykket');
    var bl = $('#blink'), st = $('#stempel');
    bl.classList.remove('gaa'); void bl.getBoundingClientRect(); bl.classList.add('gaa');
    setTimeout(function () {
      $$('.sc').forEach(function (s, i) { s.classList.toggle('on', i === e.n); });
      $('#traff').innerHTML = '<span>' + t('traff') + '</span> ';
      $('#traff').appendChild(document.createTextNode(sprak === 'en' ? e.naar_en : e.naar));
      st.textContent = sprak === 'en' ? 'MISSED! By ' + e.bom_en : 'BOM! ' + e.bom.charAt(0).toUpperCase() + e.bom.slice(1) + (/feil$/.test(e.bom) ? '' : ' feil');
      st.hidden = false; st.classList.remove('inn'); void st.getBoundingClientRect(); st.classList.add('inn');
      $('#logg').textContent = t('maaling', e.n);
      var les = $('#les'); les.hidden = false;
      if (apen(e.n)) { les.textContent = t('les', e.n, sprak === 'en' ? e.tittel_en : e.tittel); les.setAttribute('href', '#ep' + e.n); }
      else { les.textContent = nokkel ? t('kommerEnFredag', e.n) : t('meldForLese'); les.setAttribute('href', '#blimed'); }
    }, 110);
  });
  $('#tom').addEventListener('click', function () {
    if (this.dataset.sikker) { har = {}; lagre(); tegn(); this.textContent = t('tom'); delete this.dataset.sikker; }
    else { this.dataset.sikker = '1'; this.textContent = t('sikker'); }
  });
  function meldPaa(felt, kn, ut) {
    function melding(t) { ut.textContent = t; }
    var adr = felt.value.trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/.test(adr)) { melding(t('ikkeEpost')); return; }
    if (!LIVE) { melding(t('forhaands')); return; }
    kn.disabled = true; melding(t('sender'));
    fetch('/api/meld-paa', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ epost: adr, nettside: $('#nettside').value, sprak: sprak }) })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (d) { return { ok: r.ok, d: d }; }); })
      .then(function (x) {
        if (x.ok) { melding(t('sjekk')); felt.value = ''; }
        else { melding(sprak === 'en' ? t('galt') : (x.d.feil || t('galt'))); }
      })
      .catch(function () { melding(t('kontakt')); })
      .then(function () { kn.disabled = false; });
  }
  [['#epost', '#meldpaa', '#pameldt'], ['#epost2', '#meldpaa2', '#pameldt2']].forEach(function (s) {
    var felt = $(s[0]), kn = $(s[1]), ut = $(s[2]);
    if (!felt) return;
    kn.addEventListener('click', function () { meldPaa(felt, kn, ut); });
    felt.addEventListener('keydown', function (ev) { if (ev.key === 'Enter') { ev.preventDefault(); meldPaa(felt, kn, ut); } });
  });
  function hentStatus() {
    if (!LIVE || !nokkel) return;
    fetch('/api/status?t=' + encodeURIComponent(nokkel))
      .then(function (r) { if (r.status === 404) { nokkel = ''; try { localStorage.removeItem(NK); } catch (e) {} tegn(); return null; } return r.ok ? r.json() : null; })
      .then(function (d) {
        if (!d || !d.opp) return;
        opp = d.opp; try { localStorage.setItem(OK, opp); } catch (e) {}
        vis();
      })
      .catch(function () {});
  }
  var sk = document.getElementById('sprak');
  if (sk) sk.addEventListener('click', function () {
    sprak = sprak === 'en' ? 'nb' : 'en'; try { localStorage.setItem(SK, sprak); } catch (e) {}
    settSprak(); $('#pameldt').textContent = ''; $('#knutsvar').textContent = ''; tegn();
  });
  settSprak();
  vis();
  hentStatus();
})();
