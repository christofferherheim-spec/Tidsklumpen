import asyncio, os
from playwright.async_api import async_playwright
from PIL import Image
U='file://'+os.path.abspath('index.html')
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':390,'height':844},color_scheme='dark')
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(U); await pg.wait_for_timeout(900); await pg.screenshot(path='shots/f1.png')
        await pg.evaluate("document.querySelector('#blimed').scrollIntoView({block:'center'})"); await pg.wait_for_timeout(200); await pg.screenshot(path='shots/f2.png')
        await pg.goto(U+'#ep1'); await pg.wait_for_timeout(500)
        await pg.evaluate("document.querySelector('#ep1 .etter').scrollIntoView({block:'center'})"); await pg.wait_for_timeout(200); await pg.screenshot(path='shots/f3.png')
        await pg.fill('#epost2','voksen@eksempel.no'); await pg.click('#meldpaa2'); await pg.wait_for_timeout(200)
        print('melding etter ep1:', await pg.inner_text('#pameldt2'), '| feil:', errs)
        await b.close()
    s=Image.new('RGB',(390*3,844))
    for k in range(3): s.paste(Image.open('shots/f%d.png'%(k+1)),(k*390,0))
    s.save('shots/fsheet.png')
asyncio.run(main())
