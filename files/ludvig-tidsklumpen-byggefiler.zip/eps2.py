# -*- coding: utf-8 -*-
from dsl import *
from eps1 import EPS, ep

GLO = lambda x, y, r=38: f'<circle cx="{x}" cy="{y}" r="{r}" fill="#FFF6D6" opacity=".85"/>'

# ============================== EPISODE 5 ==============================
CUR["ep"] = 5
FJELL = ('<path d="M214 204 L228 84 L290 60 L364 76 L364 204 Z" fill="#C89C64" stroke="#2A1F33" stroke-width="2.4" stroke-linejoin="round"/>'
         '<path d="M290 60 L364 76 L364 204 L330 204 L320 90 Z" fill="#B0854F"/>'
         '<path d="M256 204 L256 136 C256 116 316 116 316 136 L316 204 Z" fill="#2A1F33"/>')
TAU = '<path d="M-10 150 L210 168 M-10 176 L210 178" stroke="#6E5340" stroke-width="4" stroke-linecap="round"/>'
ep(n=5, tittel="Vann på sanden", naar="Egypt, 2500 f.Kr.", bom="omtrent 4500 år",
   oppdrag="Hjelp vannbæreren Nefer å få steinen vekk, så arbeidslaget kommer seg ut.",
   ting="Kobbermeisel", legg="Legg meiselen på hylla", steder={"bg5"},
   gags=["Den er firkantet", "Steiner har ikke øyne", "Ingen spør OSS"],
   husk=["Pyramidene ble bygd av arbeidere som fikk lønn i brød og øl. Ikke av slaver.",
         "Våt sand er glattere enn tørr. Da trengs bare halvparten så mange til å dra en slede.",
         "Arbeidslagene ga seg selv navn og skrev dem på steinene. Ett het «Khufus venner»."],
   ruter=[
       hjem(5, "Ludvig! Gymbagen! Den har ligget i gangen siden fredag. Den LEVER snart!", "Fire ting på hylla. Brødet er steinhardt. Det brenner som kull."),
       hopp(5, "en gammel dørklinke"),
       R("Problemet", [B("bg5"), FJELL, P("slede", 286, 206, 92), V(60, 208, 66), L(124, 206, 98, "o"), K(170, 208, 38), T("TINK. TINK.", 290, 50, 18, 0, "#6E5340")], [
           ("N", "Sand. Sol. Og en bygning som er altfor stor og bare halvferdig."),
           ("L", "Vi har truffet STRANDA!"),
           ("K", "Egypt. Omtrent 4500 år feil. Det der er en pyramide. Halvveis."),
           ("N", "En steinblokk på en slede har sklidd ned fra rampa og stengt inngangen til en sjakt. Bak steinen banker det. Tink. Tink. Tink.")]),
       R("", [B("bg5"), FJELL, P("slede", 286, 206, 92), P("nefer", 176, 208, 100), P("krukke", 176, 116, 34), L(96, 208, 100), K(40, 210, 40)], [
           ("N", "Ei jente med en vannkrukke på hodet står og lytter."),
           ("Nefer", "Det er laget til onkelen min. Seks mann. De banker med meislene så vi skal vite at de lever."),
           ("L", "Vi flytter steinen!"),
           ("Nefer", "Den veier som fire okser."),
           ("K", "To og et halvt tonn. Jeg veier 400 gram. Men jeg er med.")]),
       R("Det blir verre", [B("bg5"), FJELL, TAU, P("slede", 290, 212, 92), P("nefer", 150, 208, 98), P("krukke", 150, 118, 34), L(84, 208, 98, "o"), K(34, 210, 38),
                            T("Tink …", 300, 54, 15, 0, "#6E5340")], [
           ("N", "Tjue arbeidere drar i tauene. Sleden graver seg bare dypere ned i den tørre sanden. Bankingen blir svakere."),
           ("Nefer", "De går tom for luft."),
           ("L", "Ikke se steinen i øynene."),
           ("K", "Steiner har ikke øyne, Ludvig.")]),
       R("", [B("bg5"), FJELL, P("slede", 290, 212, 92), V(170, 210, 76, flip=True), '<path d="M196 150 L250 150 M196 164 L250 170" stroke="#E9D9A8" stroke-width="7" stroke-linecap="round"/>',
              L(96, 208, 100), K(40, 210, 40), '<circle cx="150" cy="96" r="9" fill="#FFFDF8" stroke="#2A1F33" stroke-width="2.4"/><path d="M150 96 l0 -6 M150 96 l4 3" stroke="#C0453D" stroke-width="2"/>',
              T("SPROING!", 150, 66, 24)], [
           ("PLAN", "Ludvigs plan: Flytt steinen", ["Teip Tidsklumpen til steinen.", "Dytt.", "Steinen ruller som en ball."],
            "Den er firkantet."),
           ("N", "Teipen ryker. Kjøkkenuret på vogna spretter av og forsvinner i sanden."),
           ("L", "Uret!"),
           ("K", "Sjansen for å finne det igjen: én til 40 milliarder. Jeg har telt sandkornene.")]),
       R("Enda verre", [B("bg5"), FJELL, TAU, P("slede", 306, 216, 92), X("#C4913A", .2), P("nefer", 160, 208, 98), P("krukke", 160, 118, 34), L(90, 208, 98, "o"), K(40, 210, 38),
                        T("SMEKK!", 110, 130, 26)], [
           ("N", "Et tau ryker. Steinen siger en halv meter til, helt inntil åpningen. Nå er det stille der inne."),
           ("Formannen", "Alle mann! DRA!"),
           ("N", "Ingenting skjer."),
           ("L", "Sjansen for at de klarer det?"),
           ("K", "Den synker fortere enn sleden.")]),
       R("", [B("bg5"), FJELL, TAU, P("slede", 306, 216, 92), P("nefer", 196, 208, 100), P("krukke", 222, 150, 34, rot=70), P("vann", 232, 212, 20)], [
           ("N", "Nefer løfter krukka av hodet og heller vannet ut på sanden rett foran sleden."),
           ("Nefer", "Våt sand er hard sand! Vannbærerne gjør det hver dag. Ingen spør OSS!")],
         a2=[B("bg5"), FJELL, P("vann", 240, 214, 24), '<path d="M130 212 L290 212" stroke="#B98D5E" stroke-width="5" stroke-linecap="round" opacity=".6"/>',
             P("slede", 104, 212, 92), P("nefer", 230, 208, 100), P("krukke", 200, 208, 30), T("SVISJ!", 130, 70, 44)]),
       R("Løst!", [B("bg5"), FJELL, P("slede", 76, 212, 80), P("far", 290, 210, 112), P("nefer", 214, 208, 96), L(150, 208, 96), K(110, 210, 36)], [
           ("N", "Sleden glir som på is. Seks støvete menn kravler ut i sola. Den eldste holder en kobbermeisel."),
           ("L", "Hvorfor virket det?"),
           ("K", "Tørr sand hoper seg opp foran sleden. Våt sand holder seg flat."),
           ("K!", "Forskere regnet ut det der i 2014. Nefer brukte fire sekunder.")]),
       R("", [B("bg5"), FJELL, P("far", 290, 210, 112), P("nefer", 220, 208, 96), L(110, 208, 98), K(52, 210, 40), GLO(166, 86), P("o5", 166, 116, 60)], [
           ("Onkelen", "Den banket for oss. Nå er den din."),
           ("Nefer", "De er ikke slaver, forresten. De får brød og øl i lønn."),
           ("L", "ØL?"),
           ("K", "Nei. Gjenstand 5 av 52. Den skal brennes til slutt."),
           ("N", "«Ikke ennå», sier Ludvig.")]),
       hjemme("Gymbagen? Og hvorfor er det sand på HELE gulvet?", "Nei. Og INGENTING!",
              "Jeg satte ut en skål med mat på trappa i kveld. I tilfelle."),
   ])

# ============================== EPISODE 6 ==============================
CUR["ep"] = 6
ep(n=6, tittel="Krittet", naar="Los Alamos, USA, 1945", bom="81 år",
   oppdrag="Hjelp mannen med hatten å stoppe spionen før han slipper ut porten med verdens farligste regnestykke.",
   ting="Krittet fra tavla", legg="Legg krittet på hylla", steder={"bg6"},
   gags=["SPEIDERLEIR", "Støv vinner", "Alle her har tall"],
   husk=["I Los Alamos bygde forskere den første atombomben i all hemmelighet. Byen sto ikke på noe kart.",
         "Bomben gjorde slutt på andre verdenskrig, men den tok livet av veldig mange mennesker. Flere av forskerne brukte resten av livet på å advare mot den.",
         "Det fantes ekte spioner i Los Alamos. De ble ikke oppdaget før flere år etterpå."],
   ruter=[
       hjem(6, "Ludvig! Løvet i oppkjørselen! Det raker seg ikke selv!", "Fem ting på hylla. Meiselen er av kobber. Den smelter pent."),
       hopp(6, "en sprukken termos"),
       R("Problemet", [B("bg6"), P("spion", 96, 176, 92), V(214, 212, 60), L(272, 210, 94, "o"), K(322, 212, 36)], [
           ("N", "En støvete by av trehus på toppen av et fjell. Piggtråd hele veien rundt."),
           ("L", "Vi har truffet en SPEIDERLEIR!"),
           ("K", "Los Alamos, 1945. 81 år feil. Verdens hemmeligste by."),
           ("N", "Gjennom en åpen dør ser de en tavle full av tall. En mann i grå frakk skriver av hele tavla i ei lita bok. Fort. Mens han ser seg over skulderen.")]),
       R("", [B("bg6"), P("hatt", 112, 212, 124), L(210, 210, 98), K(262, 212, 38), V(318, 212, 56)], [
           ("N", "En tynn mann med flat hatt og pipe kommer rundt hjørnet. Han ser på tavla. Så på handlevogna."),
           ("Hatten", "Noen har vært her. Krittet er flyttet."),
           ("L", "En mann i grå frakk! Han skrev av alt!"),
           ("Hatten", "Da har vi en spion. Og han har regnestykket til verdens farligste bombe."),
           ("K", "Det forklarer piggtråden.")]),
       R("Det blir verre", [B("bg6"), P("spion", 226, 196, 66), L(76, 210, 98), K(128, 212, 38), P("hatt", 20, 216, 124)], [
           ("N", "Mannen i grå frakk går rolig mot porten. Ingen stopper ham. Alle her går i frakk."),
           ("L", "Ikke se ham i øynene."),
           ("K", "Vi ser ham i ryggen, Ludvig."),
           ("K!", "Mannen med hatten heter Oppenheimer. Han er sjefen for hele byen. Ludvig tror han er vaktmester.")]),
       R("", [B("bg6"), P("spion", 236, 200, 76), L(150, 190, 84, "o", rot=96),
              '<path d="M112 150 C130 130 170 130 190 150 M112 164 C134 180 170 180 190 162 M124 140 L180 174" fill="none" stroke="#E9D9A8" stroke-width="7" stroke-linecap="round"/>',
              P("teip", 90, 204, 22), K(40, 212, 38), T("RULL!", 150, 96, 28)], [
           ("PLAN", "Ludvigs plan: Fang spionen", ["Teip et snubletau over veien.", "Spionen snubler.", "Jeg roper «HA!».", "Medalje."],
            "Teip mot støv. Støv vinner."),
           ("N", "Teipen fester seg ikke i støvet. Den fester seg i Ludvig. Han ruller forbi spionen som en rundball."),
           ("N", "Spionen løfter høflig på hatten.")]),
       R("Enda verre", [B("bg6"), P("spion", 236, 200, 80), P("ermeK", 318, 168, 34), L(92, 210, 96, "o"), K(146, 212, 38),
                        '<path d="M70 170 C84 160 100 160 114 170 M70 184 C86 194 100 194 114 184" fill="none" stroke="#E9D9A8" stroke-width="6" stroke-linecap="round"/>'], [
           ("N", "Spionen viser et kort til vakta. Vakta nikker og vinker ham videre."),
           ("K", "Han har papirene i orden. Selvfølgelig har han det."),
           ("L", "STOPP HAM! HAN HAR TALLENE!"),
           ("Vakta", "Alle her har tall, gutt.")]),
       R("", [B("bg6"), P("spion", 262, 202, 84), P("ermeK", 326, 172, 30), P("hatt", 130, 212, 124)], [
           ("N", "Mannen med hatten kommer gående. Helt rolig. Han peker med pipa på boka i spionens lomme."),
           ("Hatten", "Les én linje høyt. Hvilken som helst. Og si hva den betyr."),
           ("N", "Spionen åpner munnen. Og lukker den. Han kan skrive av tall. Men han aner ikke hva de betyr.")],
         a2=[B("bg6"), P("spion", 250, 202, 84), P("ermeK", 300, 150, 44), P("hatt", 150, 212, 124),
             T("ÆÆH …", 250, 92, 26, 4, "#55515F"), T("TATT!", 110, 60, 44)]),
       R("Løst!", [B("bg6"), P("hatt", 86, 212, 124), K(206, 212, 78), '<path d="M250 150 L286 142 L292 176 L256 182 Z" fill="#FFFDF8" stroke="#2A1F33" stroke-width="2.2"/><path d="M260 156 l20 -4 M262 164 l20 -4 M264 172 l14 -3" stroke="#3E5F87" stroke-width="2"/>',
                   L(318, 210, 92)], [
           ("N", "Vakta tar boka. Porten blir stengt."),
           ("Hatten", "Den som har regnet det ut selv, glemmer det aldri. Uansett hvor gjerne han vil."),
           ("N", "Knut har også skrevet av tavla. I loggboka. Han ser lenge på siden. Så river han den ut og brenner den."),
           ("K", "Noen ting skal ikke en rotte kunne.")]),
       R("", [B("bg6"), P("hatt", 100, 212, 124), L(226, 210, 98), K(282, 212, 38), GLO(166, 84), P("o6", 166, 112, 56)], [
           ("N", "Mannen med hatten gir Ludvig krittstumpen fra tavla."),
           ("Hatten", "Ta det. Tegn noe hyggelig med det."),
           ("L", "En katt."),
           ("K", "Gjenstand 6 av 52. Du vet at det skal brennes til slutt."),
           ("L", "Ikke ennå.")]),
       hjemme("Løvet? Og hvorfor er du pakket inn i teip?", "Nei. Og INGENTING!",
              "Den ligner. Ørene er litt for store. Men den ligner.", cap2="Ludvig tegner en katt med krittet på garasjegulvet.",
              art_extra=('<g fill="none" stroke="#FFFDF8" stroke-width="2.6" stroke-linecap="round"><ellipse cx="318" cy="204" rx="16" ry="8"/><circle cx="300" cy="196" r="7"/><path d="M294 191 l-1 -8 l6 4 M303 189 l4 -7 l2 8 M334 202 c8 -2 10 -8 6 -12"/></g>',)),
   ])

# ============================== EPISODE 7 ==============================
CUR["ep"] = 7
KASSE = '<rect x="118" y="172" width="76" height="40" fill="#8E6B45" stroke="#2A1F33" stroke-width="2.4"/><path d="M118 186 L194 186 M140 172 L140 212 M172 172 L172 212" stroke="#6E5340" stroke-width="2"/>'
ep(n=7, tittel="Nei", naar="Oslo, 14. oktober 1942", bom="riktig dato, 84 år feil",
   oppdrag="Hjelp Solveig å gjemme radioen før soldatene finner den.",
   ting="Binders fra en jakkekrage", legg="Legg bindersen på hylla", steder={"bg7"},
   gags=["Jeg liker henne", "Det er omtrent alt de gjør", "Vil du ha ham?"],
   husk=["I 1941 måtte alle i Norge levere inn radioen sin. De som gjemte en, hørte nyheter fra London i hemmelighet.",
         "En binders i kragen betydde «vi holder sammen». Det ble forbudt. Rød topplue også.",
         "Motstand var ofte helt stille. Lærerne nektet å undervise i nazisme. Rundt tusen av dem ble arrestert."],
   ruter=[
       hjem(7, "Ludvig! Søpla! Den går ikke ut av seg selv!", "Seks ting på hylla. Krittet er lite. Men det er tørt."),
       hopp(7, "en bøyd gardinstang"),
       R("Problemet", [B("bg7"), P("solveig", 52, 214, 100), L(306, 214, 100, "o", flip=True), K(248, 216, 38), V(196, 216, 50),
                       T("DUNK. DUNK. DUNK.", 182, 36, 17, 0, "#55515F")], [
           ("N", "En trappeoppgang. Alle vinduene er dekket med svart papir."),
           ("K", "Oslo. 14. oktober. Riktig dato!"),
           ("L", "JA!"),
           ("K", "1942. 84 år feil."),
           ("N", "Ei jente med rød lue og en binders i kragen ser på dem. Så banker det tre ganger i vannrøret."),
           ("Solveig", "Det er fru Berg. Tre slag betyr at soldatene er i gata.")]),
       R("", [B("bg7"), KASSE, P("radio", 156, 178, 40), P("solveig", 66, 214, 100), L(306, 214, 100, flip=True), K(244, 216, 38)], [
           ("N", "Solveig løfter lokket på vedkassa. Nedi ligger en radio."),
           ("Solveig", "Tyskerne tok alle radioene i landet, så ingen skulle høre nyheter fra London. Denne fikk de ikke."),
           ("L", "Hvorfor har du binders i kragen?"),
           ("Solveig", "Fordi det er forbudt. Den røde lua også."),
           ("K", "Jeg liker henne.")]),
       R("Det blir verre", [B("bg7"), KASSE, P("stovler", 112, 190, 44), P("solveig", 40, 214, 96), L(306, 214, 100, "o", flip=True), K(244, 216, 38),
                            T("TRAMP! TRAMP!", 150, 60, 22, -4, "#33303E")], [
           ("N", "Støvler i trappa. Tunge. Mange. De banker på en dør i etasjen under."),
           ("L", "Ikke se dem i øynene."),
           ("K", "Vi ser bare støvlene, Ludvig. Det holder lenge."),
           ("Solveig", "De tar én etasje om gangen. Vi har to minutter.")]),
       R("", [B("bg7"), KASSE, '<path d="M20 150 L110 150 M30 150 L30 212 M100 150 L100 212" stroke="#2A1F33" stroke-width="5" stroke-linecap="round"/>',
              P("radio", 70, 210, 40, rot=24), '<path d="M50 152 L50 168 M86 152 L86 164" stroke="#E9D9A8" stroke-width="7" stroke-linecap="round"/>',
              P("solveig", 230, 214, 98), L(306, 214, 100, "f", flip=True), K(170, 172, 34), T("DUNK!", 80, 120, 30)], [
           ("PLAN", "Ludvigs plan: Gjem radioen", ["Teip radioen under kjøkkenbordet.", "Ingen ser under bord.", "Seier."],
            "Soldater ser under bord. Det er omtrent alt de gjør."),
           ("N", "Solveig tar bindersen ut av kragen og fester ledningen med den. Teipen holder i fire sekunder. Så ligger radioen på gulvet."),
           ("K", "Rekord igjen.")]),
       R("Enda verre", [B("bg7"), '<path d="M96 60 L250 150 L250 212 L150 212 Z" fill="#F7D36A" opacity=".45"/>', X("#2A1F33", .28), P("stovler", 150, 146, 46),
                        P("pram", 300, 214, 84), P("solveig", 216, 214, 96), L(60, 214, 98, "o"), K(110, 216, 36)], [
           ("N", "Støvlene er på vei opp til denne etasjen. En lommelykt sveiper over veggen. Solveig ser på radioen. På døra. På den gamle barnevogna i gangen."),
           ("L", "Sjansen for at dette går bra?"),
           ("K", "Fire prosent."),
           ("L", "Så det er en sjanse!")]),
       R("", [B("bg7"), P("stovler", 44, 214, 66), P("pram", 196, 214, 100), P("solveig", 288, 214, 100), P("ermeG", 104, 128, 46, flip=True)], [
           ("N", "Solveig legger radioen i barnevogna, en dukke oppå og et teppe over. Så triller hun rett ut i trappa. Rett mot støvlene. En hånd i hanske strekker seg mot teppet."),
           ("Solveig", "Keuchhusten. Kikhoste. Vil du ha ham?")],
         a2=[B("bg7"), P("stovler", 30, 214, 66), P("pram", 196, 214, 100), P("solveig", 288, 214, 100), P("ermeG", 40, 86, 46, flip=True, rot=-24),
             T("HOST! HOST!", 200, 70, 34)]),
       R("Løst!", [B("bg7"), P("pram", 190, 214, 90), P("solveig", 270, 214, 100), L(90, 214, 100), K(36, 216, 38)], [
           ("N", "Hånden stopper fem centimeter over teppet. Så forsvinner den. Støvlene går videre opp. Solveig triller vogna ned til fru Berg, som allerede er ransaket."),
           ("L", "Du gikk RETT MOT dem."),
           ("Solveig", "De leter der folk gjemmer seg. Ikke der folk kommer gående."),
           ("K!", "Skriv den ned. Den er bedre enn alt Ludvig har sagt i år.")]),
       R("", [B("bg7"), KASSE, P("radio", 156, 178, 44), P("solveig", 66, 214, 100), L(300, 214, 100, flip=True), K(240, 216, 38), GLO(196, 84, 32), P("o7", 196, 108, 48)], [
           ("N", "Klokka halv åtte sitter de rundt radioen hos fru Berg. En stemme sier: «Dette er London.»"),
           ("Solveig", "Ta bindersen. Den betyr at vi holder sammen. Det er vårt nei."),
           ("N", "Skoene hennes er sydd av fiskeskinn og gjennomvåte. Ludvig tar av seg støvlene."),
           ("L", "Du får disse. De var pappas."),
           ("K", "Gjenstand 7 av 52. Den skal brennes til slutt."),
           ("L", "Ikke ennå.")]),
       hjemme("Søpla? Og hvor er støvlene dine?", "Nei. Og … jeg ga dem bort. Til noen som trengte dem.",
              "De var mine, de. … Det er greit. Noe skal gå videre."),
   ])

# ============================== EPISODE 8 ==============================
CUR["ep"] = 8
ep(n=8, tittel="Nøkkelen", naar="Berlin, april 1945", bom="81 år",
   oppdrag="Hjelp postbudet Werner å slippe unna dem som henter gutter til krigen.",
   ting="Werners husnøkkel", legg="Legg nøkkelen på hylla", steder={"bg8", "bg8k"},
   gags=["fordel å være 400 gram", "skrevet det på norsk", "Det er det låst betyr"],
   husk=["Mot slutten av krigen ble tyske gutter helt ned i tolvårsalderen sendt ut for å slåss.",
         "Folk i Berlin slo hull i kjellerveggene, så de kunne gå under jorda fra hus til hus.",
         "Krigen i Europa sluttet 8. mai 1945. Hitler døde i bunkeren sin en drøy uke før."],
   ruter=[
       hjem(8, "Ludvig! Skoene i gangen! Jeg snublet i fire par. Du har to føtter!", "Sju ting på hylla. Vi kunne brent bindersen.",
            extra_cap="Ludvig har nye støvler. Pappa fant dem på loftet. De er ett nummer for store."),
       hopp(8, "en sprukken blomsterpotte"),
       R("Problemet", [B("bg8"), P("sykler", 150, 200, 60), P("sykler", 196, 206, 60), L(256, 214, 96, "o"), K(214, 218, 34), V(40, 216, 54)], [
           ("N", "En gate der halvparten av husene mangler. Røyk. Det dundrer langt borte."),
           ("K", "Berlin, april 1945. 81 år feil. Krigen er nesten slutt. Nesten er det farlige ordet."),
           ("N", "Mot en mur står barnesykler. På hver av dem er det bundet fast et rør som er lengre enn sykkelen."),
           ("L", "Hvem eier dem?"),
           ("K", "Gutter på din alder. Noen har gitt dem våpen og sagt at de er soldater.")]),
       R("", [B("bg8"), P("werner", 324, 216, 84), L(206, 214, 98), K(150, 216, 38), P("sykler", 60, 204, 56)], [
           ("N", "En gutt med postveske og altfor stor lue dukker opp fra en kjellerdør."),
           ("Werner", "Kom ned! De går fra gate til gate og henter alle gutter som er høye nok til å holde et rør."),
           ("L", "Jeg er ikke høy nok!"),
           ("Werner", "Du er høyere enn meg. Og jeg er høy nok."),
           ("K", "For første gang er det en fordel å være 400 gram.")]),
       R("Det blir verre", [B("bg8"), P("stovler", 44, 216, 66), P("ermeG", 120, 122, 46, flip=True), L(236, 214, 98, "o"), K(186, 216, 36), P("werner", 324, 216, 84)], [
           ("N", "Støvler rundt hjørnet. Et grått erme peker rett på Ludvig."),
           ("Stemmen", "DU DER! Gutten med brillene! Kom hit!"),
           ("L", "Ikke se ham i øynene."),
           ("K", "Han har allerede sett deg i brillene.")]),
       R("", [B("bg8"), P("stovler", 44, 216, 66), P("ermeG", 110, 150, 46, flip=True), L(226, 214, 104),
              '<rect x="196" y="150" width="60" height="26" fill="#FFFDF8" stroke="#2A1F33" stroke-width="2.2" transform="rotate(-4 226 163)"/><text x="226" y="168" text-anchor="middle" font-family="Caveat,Comic Relief,cursive" font-weight="700" font-size="15" fill="#2A1F33" transform="rotate(-4 226 163)" textLength="50" lengthAdjust="spacingAndGlyphs">JEG ER 6 ÅR</text><path d="M200 148 l10 6 M252 146 l-10 6" stroke="#E9D9A8" stroke-width="6" stroke-linecap="round"/>',
              K(290, 216, 36), P("werner", 334, 216, 80)], [
           ("PLAN", "Ludvigs plan: Bli for liten", ["Teip et skilt på genseren: «JEG ER 6 ÅR».", "Gå rolig vekk.", "Seier."],
            "Du er 1,45 høy og har skrevet det på norsk."),
           ("N", "Ermet river av skiltet, ser på det og kaster det. Werner drar Ludvig ned i kjelleren i siste sekund.")]),
       R("Enda verre", [B("bg8k"), P("stovler", 40, 86, 46), P("werner", 226, 214, 94), L(150, 214, 100, "o"), K(92, 216, 38)], [
           ("N", "Folk har slått hull i veggene mellom kjellerne, så man kan gå under hele kvartalet. Støvlene kommer ned trappa bak dem. Innerst: en tung dør. Låst."),
           ("L", "Sjansen for at den går opp?"),
           ("K", "Null. Den er låst. Det er det låst betyr.")]),
       R("", [B("bg8k"), P("stovler", 40, 86, 46), P("werner", 232, 214, 96), L(150, 214, 100, "o"), K(92, 216, 38),
              '<path d="M236 136 C240 150 252 158 262 150" fill="none" stroke="#8E6B45" stroke-width="2"/>', P("o8", 268, 164, 26)], [
           ("N", "Werner drar fram en nøkkel han har i en snor rundt halsen."),
           ("Werner", "Det er kjellerdøra til huset mitt. Huset er borte. Men døra står.")],
         a2=[B("bg8k"), '<rect x="268" y="66" width="70" height="130" fill="#FFF6D6" stroke="#2A1F33" stroke-width="2.4"/><path d="M338 66 L360 54 L360 208 L338 196 Z" fill="#6E5340" stroke="#2A1F33" stroke-width="2.4"/>',
             P("stovler", 30, 100, 46), P("werner", 300, 212, 90), L(226, 214, 100, "o"), K(170, 216, 38), T("KLIKK!", 180, 70, 44)]),
       R("Løst!", [B("bg8"), X("#F7D36A", .12), P("werner", 250, 214, 96), L(150, 214, 100), K(96, 216, 38),
                   '<path d="M300 196 L296 170 L344 170 L340 196 Z" fill="#55515F" stroke="#2A1F33" stroke-width="2.4"/><path d="M308 164 c2 -8 -4 -10 0 -18 M322 164 c2 -8 -4 -10 0 -18 M334 164 c2 -8 -4 -10 0 -18" fill="none" stroke="#F7EEDC" stroke-width="2.4" stroke-linecap="round"/>'], [
           ("N", "De smetter gjennom, og Werner låser fra den andre siden. Støvlene stopper. Så går de. I bakgården står tanta til Werner med en kjele suppe."),
           ("K", "Om et par uker er krigen i Europa slutt."),
           ("Werner", "Hvordan vet du det?"),
           ("K", "Jeg har lest slutten."),
           ("K!", "Mannen som startet hele krigen, gjemmer seg også i en kjeller. Ikke langt herfra. Han er bare mye feigere.")]),
       R("", [B("bg8"), X("#F7D36A", .12), P("werner", 260, 214, 96), '<path d="M244 150 C254 158 268 158 278 150 L280 160 C268 168 254 168 242 160 Z" fill="#4A8F6B" stroke="#2A1F33" stroke-width="2"/>',
              L(110, 214, 100), K(170, 216, 40), GLO(186, 84, 32), P("o8", 186, 110, 50)], [
           ("N", "Werner skjelver. Knut ser på ham. Så river han det grønne skjerfet sitt i to."),
           ("K", "Her. Ikke si det til noen."),
           ("Werner", "Ta nøkkelen. Døra mi finnes ikke lenger. Men den låste dere ut."),
           ("K", "Gjenstand 8 av 52. Den skal brennes til slutt."),
           ("L", "Ikke ennå.")]),
       hjemme("Skoene? Og hvorfor lukter du røyk?", "Nei. Og INGENTING!",
              "Bestefar var gutt under krigen. Han snakket aldri om den. Bare om suppa etterpå."),
   ])
