import asyncio, json, re, subprocess, time, urllib.request
from playwright.async_api import async_playwright
B='http://localhost:8765'
def hent(p, **kw):
    req=urllib.request.Request(B+p, **kw)
    try:
        with urllib.request.urlopen(req) as r: return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
def post(p, d, h=None):
    return hent(p, data=json.dumps(d).encode(), headers={'Content-Type':'application/json', **(h or {})}, method='POST')
def sendt(): return json.loads(hent('/__test?sendt=1')[1])
async def main():
    srv=subprocess.Popen(['node','lokal.js'],stdout=subprocess.PIPE); srv.stdout.readline()
    r={}
    try:
      async with async_playwright() as p:
        b=await p.chromium.launch(); ctx=await b.new_context(viewport={'width':360,'height':780}); pg=await ctx.new_page()
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(B+'/'); await pg.wait_for_timeout(300)
        # 1. Uten påmelding: alt låst
        r['1_start_uten_paamelding']=await pg.inner_text('#start')
        r['1_alle_luker_laast']=await pg.evaluate("document.querySelectorAll('.luke.laast').length")
        await pg.evaluate("location.hash='#ep1'"); await pg.wait_for_timeout(200)
        r['1_ep1_aapen_uten_paamelding']=await pg.evaluate("!document.getElementById('ep1').hidden")
        r['1_boks_etter_ep1']=await pg.evaluate("!!document.querySelector('#ep1 .etter') && !document.querySelector('#ep1 .etter').hidden && document.querySelector('#ep1 .nesteep').hidden")
        await pg.evaluate("location.hash='#ep2'"); await pg.wait_for_timeout(200)
        r['1_ep2_sperret']=await pg.evaluate("document.getElementById('ep2').hidden && location.hash==='#blimed'")
        r['1_melding']=await pg.inner_text('#pameldt')
        # 2. Ugyldig adresse
        await pg.fill('#epost','ikke-epost'); await pg.click('#meldpaa'); r['2_ugyldig']=await pg.inner_text('#pameldt'); r['2_ingen_sendt']=len(sendt())==0
        # 3. Påmelding
        await pg.fill('#epost','Voksen@Eksempel.no'); await pg.click('#meldpaa'); await pg.wait_for_timeout(400)
        r['3_melding']=await pg.inner_text('#pameldt')
        m=sendt(); r['3_antall_eposter']=len(m); e1=m[0]
        r['3_til']=e1['to']; r['3_emne']=e1['subject']; r['3_fra']=e1['from']
        r['3_avmeldingshode']='List-Unsubscribe' in e1['headers']
        lenke=re.search(r'https://tidsklumpen\.no/\?t=[a-f0-9]{32}#ep[12]', e1['text']); r['3_lenke_i_epost']=lenke.group(0)[:38]+'...'
        r['3_tekst']=e1['text'][:330]
        tok=re.search(r't=([a-f0-9]{32})', e1['text']).group(1)
        r['3_fortsatt_laast_for_lenka']=await pg.evaluate("document.querySelectorAll('.luke.laast').length")
        # 4. Samme adresse igjen med en gang: ingen ny e-post
        post('/api/meld-paa',{'epost':'voksen@eksempel.no'}); r['4_ikke_dobbel_epost']=len(sendt())==1
        # 5. Fredag før lenka er åpnet: ingenting sendes
        hent('/__test?dager=3')
        r['5_fredag_uten_hemmelighet']=hent('/api/fredag')[0]
        r['5_ubekreftet_faar_ikke']=json.loads(hent('/api/fredag',headers={'Authorization':'Bearer hemmelig'})[1])
        # 6. Åpner lenka fra e-posten
        await pg.goto(lenke.group(0).replace('https://tidsklumpen.no',B)); await pg.wait_for_timeout(500)
        r['6_ep1_aapen']=await pg.evaluate("!document.getElementById('ep1').hidden")
        r['6_token_ute_av_adressen']=await pg.evaluate("location.search===''")
        r['6_neste_knapp']=await pg.inner_text('#ep1 .nesteep')
        await pg.evaluate("location.hash='#reiser'"); await pg.wait_for_timeout(200)
        r['6_laaste_luker']=await pg.evaluate("document.querySelectorAll('.luke.laast').length")
        r['6_status_ep2']=await pg.inner_text('.luke[data-n=\"2\"] .status')
        r['6_kort']=await pg.inner_text('#blimedtekst'); r['6_skjema_skjult']=await pg.evaluate("document.getElementById('skjema').hidden")
        await pg.evaluate("location.hash='#ep2'"); await pg.wait_for_timeout(200)
        r['6_ep2_sperret']=await pg.evaluate("document.getElementById('ep2').hidden")
        await pg.screenshot(path='shots/e1.png')
        # 7. Fredag: reise 2
        f=json.loads(hent('/api/fredag',headers={'Authorization':'Bearer hemmelig'})[1]); r['7_fredag']=f
        m=sendt(); r['7_emne']=m[-1]['subject']; r['7_lenke_ep2']='#ep2' in m[-1]['text']
        r['7_samme_dag_igjen']=json.loads(hent('/api/fredag',headers={'Authorization':'Bearer hemmelig'})[1])['sendt']
        await pg.goto(B+'/'); await pg.wait_for_timeout(500)
        r['7_laaste_luker']=await pg.evaluate("document.querySelectorAll('.luke.laast').length")
        await pg.evaluate("location.hash='#ep2'"); await pg.wait_for_timeout(200)
        r['7_ep2_aapen']=await pg.evaluate("!document.getElementById('ep2').hidden")
        # 8. Ti fredager til: stopper på 11
        for i in range(12):
            hent('/__test?dager=7'); hent('/api/fredag',headers={'Authorization':'Bearer hemmelig'})
        m=sendt(); r['8_eposter_totalt']=len(m); r['8_siste_emne']=m[-1]['subject']; r['8_siste_bunn']=('siste reisen' in m[-1]['text'])
        r['8_status']=json.loads(hent('/api/status?t='+tok)[1])
        # 9. Feil hos Resend ved påmelding: ingenting lagres
        hent('/__test?resendfeil=1'); r['9_resend_nede']=post('/api/meld-paa',{'epost':'ny@eksempel.no'})
        hent('/__test?resendfeil=0'); r['9_ikke_lagret']=not any('ny@eksempel.no' in json.dumps(x) for x in json.loads(hent('/__test?db=1')[1]))
        # 10. Robotfelt og ugyldige kall
        post('/api/meld-paa',{'epost':'robot@eksempel.no','nettside':'http://spam'}); r['10_robot_ignorert']=len(sendt())==len(m)
        r['10_get_paamelding']=hent('/api/meld-paa')[0]; r['10_ukjent_token']=hent('/api/status?t='+'0'*32)[0]; r['10_tulletoken']=hent('/api/status?t=abc')[0]
        # 11. Avmelding
        s,side=hent('/api/meld-av?t='+tok); r['11_get_sletter_ikke']=(s==200 and json.loads(hent('/api/status?t='+tok)[1])['opp']==11)
        s,side=hent('/api/meld-av?t='+tok, data=b'List-Unsubscribe=One-Click', method='POST'); r['11_post']=(s, 'meldt av' in side)
        r['11_borte']=hent('/api/status?t='+tok)[0]
        r['11_db_tom_for_adresse']=not any('voksen@eksempel.no' in json.dumps(x) for x in json.loads(hent('/__test?db=1')[1]))
        await pg.goto(B+'/'); await pg.wait_for_timeout(500)
        r['11_siden_etter_avmelding']=(await pg.evaluate("!document.getElementById('skjema').hidden"), await pg.evaluate("document.querySelectorAll('.luke.laast').length"))
        # 12. For mange forsøk
        koder=[post('/api/meld-paa',{'epost':f'a{i}@eksempel.no'})[0] for i in range(12)]; r['12_sperre']=koder
        r['feil_i_nettleser']=errs
        await b.close()
    finally:
        srv.kill()
    for k,v in r.items(): print(k,':',v)
asyncio.run(main())
