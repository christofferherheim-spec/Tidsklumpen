# -*- coding: utf-8 -*-
from dsl import *

EPS = []


def ep(**k):
    EPS.append(k)


# ============================== EPISODE 1 ==============================
CUR["ep"] = 1
Z1 = dict(z=1.6, ox=-216, oy=-110)
def teipstrek(d):
    return (f'<path d="{d}" fill="none" stroke="#E9D9A8" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>'
            f'<path d="{d}" fill="none" stroke="#2A1F33" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>')


ep(n=1, tittel="Matboksen", naar="66 millioner år siden", bom="66 millioner år",
   oppdrag="Redd Pip fra en T. rex. Du har en rull teip.",
   ting="Pips fjær", legg="Legg fjæra på hylla", steder={"bg1"},
   gags=["Det er vi som er rare", "Jeg så opp", "42 000 meter teip", "Armene når ikke", "matet dinosaurer"],
   husk=["Tyrannosaurus rex var tolv meter lang, men armene var bare én meter.",
         "En stein på ti kilometer traff jorda der Mexico ligger i dag. Da døde de store dinosaurene ut.",
         "Fuglene er dinosaurene som overlevde. Det sitter en på fuglebrettet ditt."],
   nerd=["T. rex levde nærmere oss i tid enn Stegosaurus. Det er 66 millioner år fra T. rex til deg, og 80 millioner år fra Stegosaurus til T. rex.",
         "Den lengste tanna vi har funnet fra en T. rex, er nesten 30 centimeter med rota.",
         "T. rex hadde omtrent 60 tenner. Mistet den én, vokste det ut en ny.",
         "Ingen landdyr har noen gang bitt hardere enn T. rex.",
         "Armene var korte, men sterke. Hver arm kunne løfte over 100 kilo. Hver hånd hadde bare to fingre.",
         "Hodeskallen til en T. rex var halvannen meter lang.",
         "Steinen fra verdensrommet kom i opptil 72 000 kilometer i timen.",
         "Krateret etter steinen er omtrent 180 kilometer bredt. Det ligger gjemt under bakken og havet i Mexico, og ble ikke funnet før i 1991.",
         "Over hele jorda ligger det et tynt lag med leire fra den dagen. Det er fullt av iridium, et metall som er sjeldent her, men vanlig i verdensrommet.",
         "Tre av fire arter på jorda døde ut. Da hadde dinosaurene levd her i over 160 millioner år."],
   ruter=[
       R("", [B("bgG"), V(110, 204, 90), L(206, 202, 104), K(266, 202, 42), P("matboks", 60, 60, 20), P("teip", 156, 206, 30)], [
           ("P", "Ludvig! Matboksen din ligger igjen på skolen. Igjen!"),
           ("L", "Skal bare fikse noe i garasjen!"),
           ("N", "Tidsklumpen er ferdig. Men før de leter etter Kanel, vil Knut ha et prøvehopp."),
           ("K", "Vi sikter på noe helt uviktig. Kantina, i går, klokka tolv."),
           ("L", "Matboksen! Kjempelett. Jeg tar med teip."),
           ("N", "Ludvig tar på Kanels bjelle før de drar. Det gjør han hver gang.")]),
       R("", [B("blits"), V(180, 186, 120, rot=-10), T("BLITS!", 180, 52, 44)], [
           ("N", "Drivstoff i dag: en rusten spiker. Ludvig stiller inn."),
           ("L", "Kantina, i går, klokka tolv!"),
           ("K", "Måling nummer 1. Notert.")]),
       R("Problemet", [B("bg1"), P("stjerne", 150, 58, 26), V(64, 204, 66), L(138, 200, 98, "o"), K(190, 200, 38),
                       P("pip", 104, 206, 40), T("DUNK!", 286, 70, 34), T("DUNK!", 318, 112, 24, 5)], [
           ("N", "Ingen kantine. Bare bregner, og varmt som i en badstue."),
           ("L", "Kantina har fått planter!"),
           ("K", "Vi bommet. Med 66 millioner år."),
           ("N", "Et lite dyr med fjær gjemmer seg bak Ludvig. Så rister bakken."),
           ("K", "Ikke se opp."),
           ("L", "Jeg så opp.")]),
       R("", [B("bg1", **Z1), P("trex", 272, 150, 176), P("pip", 28, 214, 50), L(84, 216, 124, "o"), K(160, 214, 46)], [
           ("N", "Der oppe henger et hode så stort som et kjøleskap, med tenner som bananer."),
           ("L", "DINOSAUR!"),
           ("K", "Ja. Her er alle dinosaurer. Det er vi som er rare."),
           ("L", "Og den jager en kylling!"),
           ("K", "Kyllingen er også en dinosaur. Mange av dem hadde fjær.")]),
       R("Det blir verre", [B("bg1"), P("stjerne", 150, 74, 46), P("pip", 78, 152, 40), V(84, 204, 84),
                            P("trex", 288, 150, 136), L(172, 204, 94, "f"), K(222, 206, 38)], [
           ("N", "Pip gjemmer seg i handlevogna. Nå vil T. rex ha handlevogna."),
           ("K", "Tyrannosaurus rex. Tolv meter lang. Armene er bare én meter."),
           ("L", "Så den kan ikke klø seg på nesa?"),
           ("K", "Nei. Men den kan spise en handlevogn."),
           ("K!", "Ser du stjerna? Den blir større og større. Det er en stein fra verdensrommet, ti kilometer bred. Ikke si det til Ludvig ennå.")]),
       R("", [B("bg1"), P("stjerne", 150, 74, 46), teipstrek("M60 96 C76 104 84 96 92 110"), teipstrek("M140 92 C150 108 164 104 176 120"),
              L(196, 206, 112, "f"), teipstrek("M168 132 L232 118 M162 150 L236 140 M172 168 L228 166 M176 120 L170 132"),
              P("teip", 252, 208, 26), K(288, 208, 44), T("RITSJ!", 250, 64, 34)], [
           ("PLAN", "Ludvigs plan: Stopp T. rex", ["Teip mellom to trær.", "T. rex løper inn i teipen.", "Seier."],
            "Den veier åtte tonn. Teipen er to centimeter bred."),
           ("N", "Ludvig har 42 000 meter teip. T. rex går rett gjennom. Ludvig sitter fast i sin egen teip."),
           ("K", "Sjansen for at det der virket, var to prosent."),
           ("L", "Så det VAR en sjanse!")]),
       R("Enda verre", [B("bg1"), P("stjerne", 110, 60, 50), P("pip", 112, 150, 38), V(150, 204, 90), P("trex", 256, 194, 146, rot=-20),
                        L(38, 206, 96, "o"), teipstrek("M22 150 L56 144 M20 166 L58 164"), K(82, 210, 36), T("PLING!", 246, 204, 22, 4, "#2F7F86")], [
           ("N", "T. rex stikker snuten ned i handlevogna. Der sitter Pip. Kanels bjelle ringer."),
           ("L", "Den spiser veien hjem!"),
           ("N", "Knut ser på snuten. Så på de små armene."),
           ("K", "Ludvig. Den når ikke opp til sin egen snute."),
           ("L", "Pip! Ta teipen!")]),
       R("", [B("bg1"), V(150, 204, 90), P("trex", 256, 194, 146, rot=-20), L(44, 206, 100, "o", rot=-8),
              teipstrek("M70 150 C110 120 150 96 196 104"), P("pip", 204, 104, 40), K(96, 210, 36), T("RUNDT!", 110, 52, 34)], [
           ("N", "Pip tar teipenden i nebbet og løper rundt snuten. Rundt og rundt og rundt."),
           ("L", "TEIP VIRKER PÅ ALT!"),
           ("N", "Ludvig holder rullen, så han blir med rundt."),
           ("K", "Jeg er 400 gram. Jeg heier.")],
         a2=[B("bg1"), V(150, 204, 90), P("trexteip", 256, 194, 146, rot=-20), L(60, 206, 100, "o", flip=True, rot=10),
             teipstrek("M88 150 C120 176 150 186 186 176"), P("pip", 176, 182, 40, flip=True), K(104, 210, 36, flip=True),
             T("OG RUNDT!", 120, 52, 32, 5)]),
       R("Løst!", [B("bg1", **Z1), P("trexteip", 262, 152, 156), '<circle cx="134" cy="58" r="33" fill="#FFF6D6" opacity=".85"/>', P("o1", 134, 84, 52),
                   L(62, 216, 124), P("pip", 66, 100, 38), K(160, 214, 46), T("MMFF!", 250, 196, 26, 4)], [
           ("N", "42 000 meter teip senere er snuten pakket inn. T. rex prøver å ta den av. Armene når ikke."),
           ("K", "Én meter. Jeg sa det."),
           ("N", "T. rex tramper fornærmet av gårde. På den tomme teiprullen sitter én av fjærene til Pip."),
           ("K", "Gjenstand 1 av 52. Maskinen må brenne 52 gamle ting før den kan sikte. Denne også."),
           ("L", "Ikke ennå.")]),
       R("", [B("bg1"), P("stjerne", 176, 150, 190), X("#FFF6D6", .22), V(60, 204, 66), L(138, 202, 98, "o"), K(196, 204, 40),
              P("pip", 262, 208, 42, flip=True)], [
           ("N", "Stjerna er dobbelt så stor nå."),
           ("K", "Steinen treffer der Mexico ligger i dag. Støvet stenger for sola i flere år. Plantene dør, og de store dinosaurene dør ut."),
           ("L", "Da må vi dra. NÅ!"),
           ("N", "Ludvig setter Pip ned ved hullet under stokken. Så tar han på Kanels bjelle og hopper opp i handlevogna."),
           ("Pip", "PIP!")]),
       R("", [B("bg1"), P("stjerne", 190, 236, 330), X("#FFF6D6", .55), P("pip", 262, 216, 30, flip=True),
              V(150, 150, 104, rot=-12), T("BLITS!", 236, 70, 40)], [
           ("N", "Tidsklumpen rister og letter. Bak dem blir hele himmelen hvit."),
           ("L", "Klarte Pip seg?"),
           ("K", "Jeg vet ikke. De fleste klarte seg ikke. Men noen av de minste gjorde det. De gjemte seg under bakken og spiste frø."),
           ("K", "Noen av dem hadde fjær. De ble til fuglene. Noen hadde pels. De ble til meg."),
           ("L", "Så jeg har matet dinosaurer med brødskorper?"),
           ("N", "«Hver vinter», sier Knut.")]),
       hjemme("Fant du matboksen? Og hva har du i håret?", "Nei. Og INGENTING!",
              "Kanel pleide å sove i den vogna, hun.", cap="Garasjen. Ludvig har teip i luggen og en fjær i lomma."),
   ])

EPS[0]["en"] = dict(
    tittel="The Lunchbox", bom="66 million years", oppdrag="Save Pip from a T. rex. You have one roll of tape.",
    ting="Pip's feather", legg="Put the feather on the shelf",
    husk=["Tyrannosaurus rex was twelve metres long, but its arms were only one metre.",
          "A rock ten kilometres wide hit the Earth where Mexico is today. That is when the big dinosaurs died out.",
          "Birds are the dinosaurs that survived. There is one sitting on your bird table."],
    nerd=["T. rex lived closer in time to us than to Stegosaurus. It is 66 million years from T. rex to you, and 80 million years from Stegosaurus to T. rex.",
          "The longest T. rex tooth ever found is almost 30 centimetres, root included.",
          "T. rex had about 60 teeth. If it lost one, a new one grew out.",
          "No land animal has ever bitten harder than T. rex.",
          "The arms were short but strong. Each arm could lift over 100 kilos. Each hand had only two fingers.",
          "The skull of a T. rex was one and a half metres long.",
          "The rock from space came in at up to 72,000 kilometres an hour.",
          "The crater it left is about 180 kilometres wide. It lies hidden under the ground and the sea in Mexico, and was not found until 1991.",
          "All over the Earth there is a thin layer of clay from that day. It is full of iridium, a metal that is rare here but common in space.",
          "Three out of four species on Earth died out. By then the dinosaurs had lived here for over 160 million years."],
    ruter=[
        ["Ludvig! Your lunchbox is still at school. Again!", "Just fixing something in the garage!",
         "The Time Lump is finished. But before they look for Kanel, Knut wants a test jump.",
         "We aim for something that doesn't matter. The canteen, yesterday, twelve o'clock.",
         "The lunchbox! Easy. I'll bring tape.", "Ludvig touches Kanel's bell before they leave. He does that every time."],
        ["Fuel today: one rusty nail. Ludvig sets the dial.", "The canteen, yesterday, twelve o'clock!", "Jump one. Logged."],
        ["No canteen. Just ferns, and hot as a greenhouse.", "The canteen got plants!", "We missed. By 66 million years.",
         "A small animal with feathers hides behind Ludvig. Then the ground shakes.", "Don't look up.", "I looked up."],
        ["Up there hangs a head the size of a fridge, with teeth like bananas.", "DINOSAUR!",
         "Yes. Everyone here is a dinosaur. We're the odd ones.", "And it's chasing a chicken!",
         "The chicken is a dinosaur too. Lots of them had feathers."],
        ["Pip hides in the shopping cart. Now the T. rex wants the shopping cart.",
         "Tyrannosaurus rex. Twelve metres long. The arms are only one metre.", "So it can't scratch its own nose?",
         "No. But it can eat a shopping cart.",
         "See that star? It keeps getting bigger. It's a rock from space, ten kilometres wide. Don't tell Ludvig yet."],
        [("Ludvig's plan: Stop the T. rex", ["Tape between two trees.", "T. rex runs into the tape.", "Victory."],
          "It weighs eight tonnes. The tape is two centimetres wide."),
         "Ludvig has 42,000 metres of tape. The T. rex walks straight through. Ludvig is stuck in his own tape.",
         "The chance of that working was two percent.", "So there WAS a chance!"],
        ["The T. rex pushes its snout down into the shopping cart. Pip is in there. Kanel's bell rings.", "It's eating our way home!",
         "Knut looks at the snout. Then at the tiny arms.", "Ludvig. It can't reach its own snout.", "Pip! Take the tape!"],
        ["Pip grabs the end of the tape in its beak and runs around the snout. Round and round and round.", "TAPE WORKS ON EVERYTHING!",
         "Ludvig is holding the roll, so he goes round too.", "I weigh 400 grams. I'm cheering."],
        ["42,000 metres of tape later, the snout is wrapped up. The T. rex tries to pull it off. Its arms can't reach.", "One metre. I told you.",
         "The T. rex stomps off, offended. On the empty tape roll sits one of Pip's feathers.",
         "Object 1 of 52. The machine has to burn 52 old things before it can aim. This one too.", "Not yet."],
        ["The star is twice as big now.",
         "The rock will hit where Mexico is today. Dust blocks the sun for years. The plants die, and the big dinosaurs die out.",
         "Then we have to go. NOW!",
         "Ludvig sets Pip down by the hole under the log. Then he touches Kanel's bell and jumps into the shopping cart.", "PEEP!"],
        ["The Time Lump shakes and lifts. Behind them the whole sky turns white.", "Did Pip make it?",
         "I don't know. Most of them didn't. But some of the smallest did. They hid under the ground and ate seeds.",
         "Some of them had feathers. They became the birds. Some had fur. They became me.",
         "So I've been feeding dinosaurs breadcrumbs?", "“Every winter,” says Knut."],
        ["The garage. Ludvig has tape in his hair and a feather in his pocket.", "Did you find the lunchbox? And what's that in your hair?",
         "No. And NOTHING!", "Kanel used to sleep in that cart, you know."],
    ])

# ============================== EPISODE 2 ==============================
CUR["ep"] = 2
ep(n=2, tittel="Én time i genser", naar="Istiden, for 16 000 år siden", bom="16 000 år",
   oppdrag="Hjelp Aya og hunden Tuk å holde huleløven ute av hula.",
   ting="Synål av bein", legg="Legg nåla på hylla", steder={"bg2", "bg2i"},
   gags=["forrett", "Det er rekord", "veldig stolt av den"],
   husk=["Under istiden lå det tre kilometer tykk is over Norge.",
         "Menneskene i istiden var like smarte som deg. De hadde bare ikke teip.",
         "Hunden var det første dyret vi ble venner med."],
   ruter=[
       hjem(2, "Ludvig! Rommet ditt! Det ser ut som en søppelfylling!", "Én ting på hylla. Fjæra brenner fint."),
       hopp(2, "en gammel sykkellykt"),
       R("Problemet", [B("bg2"), V(60, 206, 66, rot=8), L(132, 202, 98, "o"), K(182, 204, 38), T("BRRR!", 130, 70, 30, -6, "#3E5F87")], [
           ("N", "Snø. Bare snø, og en vind som går rett gjennom genseren."),
           ("L", "Vi har truffet JULA!"),
           ("K", "Istiden. 16 000 år feil. Du har genser. Du har omtrent én time."),
           ("N", "I snøen går det spor etter poter. Hver pote er større enn hodet til Ludvig. Sporene går mot en hule.")]),
       R("", [B("bg2i"), P("baal", 196, 200, 54), P("aya", 256, 202, 102), P("tuk", 320, 206, 52), L(128, 204, 100), K(66, 208, 38)], [
           ("N", "I hula sitter ei jente og syr. En hund knurrer mot åpningen."),
           ("Aya", "Hysj. Den har gått rundt hula i hele dag."),
           ("L", "Hvem da?"),
           ("Aya", "Den som lagde sporene."),
           ("K", "Huleløve. Større enn en vanlig løve. Selvfølgelig er den det.")]),
       R("Det blir verre", [B("bg2i"), P("oyne", 58, 132, 26), P("baal", 250, 200, 54), P("aya", 304, 202, 100),
                            L(170, 204, 100, "o"), K(214, 208, 38)], [
           ("N", "To gule øyne i huleåpningen."),
           ("L", "Ikke se den i øynene."),
           ("K", "Jeg ser den i øynene."),
           ("L", "Hva gjør den?"),
           ("K", "Den ser på meg som en forrett.")]),
       R("", [B("bg2i"), V(70, 196, 84), '<path d="M10 80 L120 150 M112 76 L14 160 M6 120 L122 118" stroke="#E9D9A8" stroke-width="7" stroke-linecap="round"/>',
              L(186, 204, 100), K(240, 208, 38), P("aya", 310, 202, 96), T("KNEKK!", 80, 50, 26)], [
           ("PLAN", "Ludvigs plan: Skrem løven", ["Teip handlevogna foran åpningen.", "Løven tør ikke gå forbi en handlevogn.", "Seier."],
            "Løver har aldri hørt om handlevogner."),
           ("N", "Teipen fryser og sprekker som knekkebrød. Vogna velter."),
           ("K", "Den holdt i fire sekunder."),
           ("L", "Det er rekord!")]),
       R("Enda verre", [B("bg2i"), V(150, 214, 70, rot=84), P("labb", 76, 200, 124, flip=True), X("#2A1F33", .4),
                        P("tuk", 300, 206, 54), L(230, 204, 96, "o"), T("KRASJ!", 220, 60, 34)], [
           ("N", "En diger labb skyver vogna til side. Bålet velter. Det blir nesten helt mørkt. Tuk bjeffer."),
           ("L", "Ok. Ny plan. Jeg har ingen ny plan."),
           ("K", "Endelig er vi enige.")]),
       R("", [B("bg2i"), X("#2A1F33", .3), P("oyne", 60, 130, 32), P("aya", 200, 202, 104), P("baal", 250, 150, 44),
              P("tuk", 306, 206, 54)], [
           ("N", "Aya river en brennende grein ut av glørne og slår to steiner mot hverandre så det smeller. Tuk uler."),
           ("Aya", "Lyd og ild! Samtidig! Den tåler ikke begge!")],
         a2=[B("bg2i"), P("aya", 190, 202, 104, flip=True), P("baal", 140, 150, 64), P("tuk", 300, 206, 54, flip=True),
             T("KLAKK! KLAKK!", 230, 60, 30), T("AUUUU!", 300, 130, 20, 6, "#8C7A64")]),
       R("Løst!", [B("bg2i"), P("baal", 196, 200, 54), P("aya", 256, 202, 102), P("tuk", 320, 206, 52), L(128, 204, 100, "f"), K(66, 208, 38)], [
           ("N", "Øynene blunker. Én gang. Så er de borte."),
           ("L", "Hvordan visste du det?"),
           ("Aya", "Alle vet det."),
           ("N", "Ludvig klaprer tenner. Aya ser på genseren hans, sukker, og syr en jakke av skinn på et kvarter."),
           ("K!", "Nåla hennes er av bein. Uten nål, ingen klær. Uten klær, ingen mennesker i kulda.")]),
       R("", [B("bg2"), P("aya", 262, 204, 100), P("tuk", 320, 208, 48), L(140, 204, 100), K(196, 206, 38),
              '<circle cx="200" cy="80" r="36" fill="#FFF6D6" opacity=".85"/>', P("o2", 200, 108, 56)], [
           ("Aya", "Ta nåla. Du trenger den mer enn meg. Du fryser når du står stille."),
           ("L", "Du får teipen! Det er litt igjen."),
           ("K", "Den gjør ingenting. Men han er veldig stolt av den."),
           ("N", "Først nå ser Ludvig sprekken i brilleglasset. Den kom da vogna veltet."),
           ("N", "«Gjenstand 2 av 52. Den skal brennes til slutt», sier Knut. «Ikke ennå», sier Ludvig.")]),
       hjemme("Har du ryddet rommet? Og er det PELS du har på deg?", "Nei. Og INGENTING!",
              "Du har fått en sprekk i brillene. Vi fikser det. En dag.", cap="Garasjen. Ludvig står i genser og skinnjakke."),
   ])

# ============================== EPISODE 3 ==============================
CUR["ep"] = 3
VANN = lambda y: f'<path d="M0 {y} C40 {y-6} 80 {y+6} 120 {y} C160 {y-6} 200 {y+6} 240 {y} C280 {y-6} 320 {y+6} 360 {y} L360 220 L0 220 Z" fill="#8FC4D4" opacity=".75" stroke="#2A1F33" stroke-width="2"/>'
ep(n=3, tittel="Sjøsyk i år 793", naar="Nordsjøen, år 793", bom="1233 år",
   oppdrag="Hjelp skipsgutten Ravn å tette lekkasjen før langskipet synker.",
   ting="Sølvmynt fra Bagdad", legg="Legg mynten på hylla", steder={"bg3"},
   gags=["Sånn er forfremmelser", "liten, trist ål", "tolvåring som øser"],
   husk=["Vikingskip var bygd for å bøye seg i bølgene. Derfor kom de så langt.",
         "Vikinger hadde ikke horn på hjelmen.",
         "«Viking» var noe man dro på. De fleste var bønder, og mange dro for å handle."],
   ruter=[
       hjem(3, "Ludvig! Drillen til naboen! Du lånte den i mars!", "To ting på hylla. Nåla er tørr som knekkebrød. Brenner fint."),
       hopp(3, "en bulkete hjulkapsel"),
       R("Problemet", [B("bg3"), V(92, 212, 80, rot=-6), L(206, 212, 102, "f"), K(258, 214, 40), P("sprut", 150, 216, 26), T("PLASK!", 110, 96, 32, -8, "#2C466B")], [
           ("N", "Vogna lander på dekket av et langt, smalt skip. Midt i Nordsjøen. Ludvig blir grønn i ansiktet på tre sekunder."),
           ("K", "År 793. 1233 år feil. Og du er sjøsyk."),
           ("L", "Jeg er ikke sjøs… blørp."),
           ("N", "Da han bøyer seg ned, ser han det. Mellom to planker pipler det vann INN.")]),
       R("", [B("bg3"), P("sprut", 160, 216, 34), P("ravn", 96, 212, 98), P("hjelm", 222, 160, 30, rot=-14), L(240, 212, 102, "o"), K(308, 214, 40)], [
           ("N", "En gutt på tolv øser med en bøtte. Han heter Ravn."),
           ("L", "Båten din lekker!"),
           ("Ravn", "Skipet. Og det vet jeg. Her. Øs."),
           ("N", "Han gir Ludvig en hjelm."),
           ("L", "Det er en HJELM!"),
           ("K", "Og nå er den en bøtte. Sånn er forfremmelser.")]),
       R("Det blir verre", [B("bg3"), P("ravn", 96, 212, 98), L(240, 212, 102), K(308, 214, 40), P("sprut", 160, 216, 60), VANN(204)], [
           ("N", "En bølge slår inn. Sprekken blir lengre. Vannet når anklene."),
           ("Ravn", "Vi skal til et kloster i England. De voksne skal hente sølv."),
           ("K", "Hente. Han mener rane."),
           ("L", "Hjelper vi RANERE?"),
           ("K", "Vi hjelper en tolvåring som øser.")]),
       R("", [B("bg3"), L(230, 212, 102), K(300, 214, 40), P("sprut", 150, 216, 64), VANN(202),
              '<path d="M40 200 C60 192 80 206 104 198" fill="none" stroke="#2A1F33" stroke-width="9" stroke-linecap="round"/><path d="M40 200 C60 192 80 206 104 198" fill="none" stroke="#E9D9A8" stroke-width="6" stroke-linecap="round"/>',
              P("teip", 190, 168, 22)], [
           ("PLAN", "Ludvigs plan: Tett hullet", ["Teip over sprekken.", "Mer teip.", "Skipet er tett.", "Jeg blir viking."],
            "Teip fester seg ikke på våte ting. Alt her er vått."),
           ("N", "Teipen flyter av gårde som en liten, trist ål."),
           ("K", "Sjansen for at du blir viking: én prosent."),
           ("L", "Så det ER en sjanse!")]),
       R("Enda verre", [B("bg3"), P("ravn", 86, 212, 98), L(240, 210, 102, "o"), P("sprut", 160, 214, 96), VANN(184),
                        '<circle cx="300" cy="150" r="10" fill="#C99B4E" stroke="#2A1F33" stroke-width="2.4"/><path d="M294 152 l12 0" stroke="#2A1F33" stroke-width="2"/><path d="M300 164 l0 14 M292 170 l-4 8 M308 170 l4 8" stroke="#2C466B" stroke-width="2" stroke-linecap="round"/>',
                        T("PLOPP!", 300, 120, 22, 6, "#2C466B")], [
           ("N", "Planken spretter opp. Vannet står til knærne. Kanels bjelle faller av styret og ned i bunnvannet."),
           ("L", "BJELLA!"),
           ("N", "Han får tak i den. Men den lille kula inni er borte. Bjella ringer ikke lenger.")]),
       R("", [B("bg3"), P("sprut", 176, 214, 110), P("ravn", 110, 212, 100), VANN(186), L(280, 210, 96, "o")], [
           ("N", "Ravn river en dott saueull ut av en sekk, dypper den i tjære og banker den ned i sprekken med en trekile."),
           ("Ravn", "Ull og tjære! Det er sånn hele skipet er bygd!")],
         a2=[B("bg3"), P("ravn", 150, 210, 100, flip=True), '<ellipse cx="192" cy="200" rx="16" ry="8" fill="#2A1F33"/><path d="M186 176 l12 0 l-3 22 l-6 0 Z" fill="#B98D5E" stroke="#2A1F33" stroke-width="2"/>',
             VANN(200), L(280, 210, 96), T("DUNK!", 200, 110, 44)]),
       R("Løst!", [f'<g transform="rotate(-5 180 110)">{B("bg3", 1.1, -18, -12)}</g>', P("ravn", 96, 210, 98, rot=-5), L(230, 212, 102, "o", rot=-5), K(296, 214, 40)], [
           ("N", "Vannet stopper. Skipet rir over neste bølge, og hele skroget vrir seg som en fisk."),
           ("L", "Det BØYER seg! Det går i stykker!"),
           ("K", "Det skal bøye seg. Plankene ligger oppå hverandre som takstein. Derfor tåler det havet."),
           ("K!", "Og ingen her har horn på hjelmen. Bare så det er sagt.")]),
       R("", [B("bg3"), P("ravn", 110, 212, 98), L(228, 212, 102), K(294, 214, 40),
              '<circle cx="170" cy="92" r="36" fill="#FFF6D6" opacity=".85"/>', P("o3", 170, 120, 56)], [
           ("N", "Ravn gir Ludvig en sølvmynt med rare tegn."),
           ("Ravn", "Du så lekkasjen. Den som ser, får lønn."),
           ("K", "Arabisk skrift. Den mynten har reist helt fra Bagdad. Gjenstand 3 av 52."),
           ("K", "Du vet at den skal brennes til slutt."),
           ("L", "Ikke ennå.")]),
       hjemme("Drillen? Og hvorfor drypper du?", "Nei. Og INGENTING!", "Vi finner en ny kule. Du og jeg. En dag.",
              cap2="Ludvig rister på bjella. Ingen lyd."),
   ])

# ============================== EPISODE 4 ==============================
CUR["ep"] = 4
HAUG = '<path d="M0 220 L0 200 C60 188 120 204 180 194 C240 186 300 202 360 192 L360 220 Z" fill="#8C8896" stroke="#2A1F33" stroke-width="2.4"/>'


def med_pute(sid, x, y, h, flip=False):
    return P(sid, x, y, h, flip) + P("pute", x, y - h * .86, h * .26)


ep(n=4, tittel="Brødet i ovnen", naar="Pompeii, år 79", bom="1947 år",
   oppdrag="Hjelp Secunda å få den sta bakerfaren ut av byen før takene raser.",
   ting="Brød fra Pompeii", legg="Legg brødet på hylla", steder={"bg4"},
   gags=["dårligste dagen på 2000 år", "kurv med hjul", "Det er et fjell"],
   husk=["Ingen i Pompeii visste at fjellet var en vulkan.",
         "De 81 brødene ble stående i ovnen. De ble funnet der nesten 1800 år senere.",
         "Asken la seg over byen som et lokk. Derfor vet vi hvordan en helt vanlig dag så ut."],
   ruter=[
       hjem(4, "Ludvig! Oppvaskmaskinen! Den tømmer seg ikke selv!", "Tre ting på hylla. Mynten ville gitt et fint lite smell."),
       hopp(4, "en rusten hengelås"),
       R("Problemet", [B("bg4"), V(84, 216, 70), L(160, 214, 100, "o"), K(210, 216, 40), P("pimp", 180, 220, 220)], [
           ("N", "En trang gate. Det lukter nybakt brød. Og det regner."),
           ("L", "Vi har truffet et BAKERI!"),
           ("N", "Det er ikke regn. Det er små, grå steiner. De spretter i gata som popkorn."),
           ("K", "År 79. Pompeii. 1947 år feil. Ludvig, se på fjellet."),
           ("N", "Fjellet bak byen har fått en sky som er høyere enn fjellet.")]),
       R("", [B("bg4", 1.5, -180, -96), P("far", 300, 212, 128), P("secunda", 190, 214, 104), P("pute", 150, 178, 28), P("pute", 228, 178, 28, flip=True),
              L(84, 216, 108), K(30, 216, 40)], [
           ("N", "I bakeriet står ei jente med to puter. Faren hennes står foran ovnen."),
           ("Secunda", "Far! Vi må GÅ!"),
           ("Far", "Jeg har 82 brød i ovnen. De er ferdige om en time."),
           ("L", "Hei! Er det en dårlig dag å komme på?"),
           ("K", "Det er den dårligste dagen på 2000 år.")]),
       R("Det blir verre", [B("bg4"), P("far", 306, 212, 112), P("secunda", 230, 214, 94), L(120, 214, 98), HAUG, K(60, 204, 40), P("pimp", 180, 220, 220)], [
           ("N", "Steinene ligger til anklene. Taket på nabohuset knaker."),
           ("Secunda", "Steinene er lette. Men det er mange av dem. Takene tåler det ikke."),
           ("Far", "Brødet tåler det ikke hvis jeg går."),
           ("K", "Han er like sta som deg, Ludvig. Det er ikke ros.")]),
       R("", [B("bg4", 1.5, -180, -96), '<path d="M250 40 L340 40 M262 30 L262 70 M330 30 L330 76" stroke="#E9D9A8" stroke-width="8" stroke-linecap="round"/><path d="M290 44 C292 60 286 70 290 86 M312 44 C316 58 308 66 314 80" fill="none" stroke="#E9D9A8" stroke-width="5" stroke-linecap="round"/>',
              P("far", 196, 212, 128), L(96, 216, 108), K(36, 216, 40), T("DRYPP", 300, 110, 20, 4, "#8E6B45")], [
           ("PLAN", "Ludvigs plan: Redd brødet OG bakeren", ["Teip et tak over ovnen.", "Bakeren blir glad.", "Bakeren blir med.", "Gratis boller."],
            "Ovnen er 300 grader. Teip er ikke det."),
           ("N", "Teipen smelter og drypper ned i deigen."),
           ("Far", "Hvem er denne gutten?"),
           ("Secunda", "Jeg vet ikke. Han kom i en kurv med hjul.")]),
       R("Enda verre", [B("bg4"), X("#55515F", .35), P("secunda", 250, 214, 94), L(150, 214, 98, "o"), HAUG, K(96, 204, 40),
                        P("pimp", 180, 220, 220), T("KRAKK!", 70, 90, 40)], [
           ("N", "Taket på nabohuset raser sammen. Gata fylles med stein. Byporten er stappfull av folk og kjerrer."),
           ("L", "Ikke se fjellet i øynene."),
           ("K", "Det er et fjell."),
           ("L", "Det ser på oss!")]),
       R("", [B("bg4"), X("#55515F", .3), P("far", 306, 212, 112), P("secunda", 236, 214, 94), P("pute", 268, 150, 30), L(110, 214, 98), HAUG, K(56, 204, 40), P("pimp", 180, 220, 220)], [
           ("N", "Secunda binder en pute på hodet til faren sin med snora fra forkleet hans. Så napper hun ett brød ut av ovnen."),
           ("Secunda", "Jeg vet om et hull i bymuren bak bakeriet. Jeg har krøpet ut der hundre ganger. KOM!")],
         a2=[B("bg4"), X("#55515F", .3), med_pute("far", 76, 212, 112, True), med_pute("secunda", 150, 214, 94, True),
             med_pute("luds1", 226, 214, 98, True), HAUG, K(292, 204, 40, flip=True), P("pimp", 180, 220, 220), T("LØP!", 250, 70, 46)]),
       R("Løst!", [B("bg4", .8, 60, 0), '<rect width="360" height="220" fill="#8C8896" opacity=".5"/><path d="M0 176 C100 160 240 168 360 150 L360 220 L0 220 Z" fill="#B5A58C" stroke="#2A1F33" stroke-width="2.4"/>',
                   med_pute("far", 96, 212, 108), med_pute("secunda", 170, 214, 92), med_pute("luds1", 250, 214, 96), K(310, 216, 40)], [
           ("N", "Ut gjennom hullet. Opp på veien, sammen med tusenvis av andre med puter på hodet. Bak dem blir byen grå."),
           ("Far", "82 brød."),
           ("Secunda", "81. Jeg tok ett."),
           ("K", "De fleste kom seg ut i dag. Akkurat sånn. Til fots."),
           ("K!", "De 81 brødene står der ennå. Du kan se dem på museum. Ikke spis dem.")]),
       R("", [B("bg4", .8, 60, 0), '<rect width="360" height="220" fill="#8C8896" opacity=".5"/><path d="M0 176 C100 160 240 168 360 150 L360 220 L0 220 Z" fill="#B5A58C" stroke="#2A1F33" stroke-width="2.4"/>',
              P("far", 300, 212, 108), P("secunda", 226, 214, 92), L(110, 214, 98), K(50, 216, 40),
              '<circle cx="168" cy="90" r="38" fill="#FFF6D6" opacity=".85"/>', P("o4", 168, 120, 60)], [
           ("Secunda", "Ta brødet. Far baker nye. Det er det eneste han kan."),
           ("Far", "Jeg hørte det."),
           ("K", "Gjenstand 4 av 52. Du vet at det skal brennes til slutt."),
           ("L", "Ikke ennå. Og ikke spis det heller.")]),
       hjemme("Oppvaskmaskinen? Og hvorfor har du pute på hodet?", "Nei. Og INGENTING!",
              "Det lukter nybakt her. Kanel kom alltid når det luktet mat.", art_extra=(P("pute", 206, 116, 26),)),
   ])
