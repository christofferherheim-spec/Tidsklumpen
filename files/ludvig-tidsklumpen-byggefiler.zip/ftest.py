import asyncio
from playwright.async_api import async_playwright
from PIL import Image
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        ctx=await b.new_context(viewport={'width':360,'height':780})
        pg=await ctx.new_page()
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/tk/index.html'); await pg.wait_for_timeout(200)
        r={}
        r['start_tekst']=await pg.inner_text('#start')
        r['overflow_hub']=await pg.evaluate("document.documentElement.scrollWidth>window.innerWidth")
        r['apne_plasser']=await pg.evaluate("document.querySelectorAll('.plass.apen').length")
        r['synlige_plasser']=await pg.evaluate("[...document.querySelectorAll('.plass')].filter(e=>e.offsetWidth>0).length")
        await pg.click('#sporknut'); r['knut']=await pg.inner_text('#knutsvar')
        await pg.click('#hopp'); await pg.wait_for_timeout(300); r['hopp']=await pg.inner_text('#stempel')
        await pg.click('#start'); await pg.wait_for_timeout(150)
        r['hash']=await pg.evaluate('location.hash')
        r['ep1_synlig']=await pg.evaluate("!document.getElementById('ep1').hidden && document.getElementById('hjem').hidden")
        r['overflow_ep']=await pg.evaluate("document.documentElement.scrollWidth>window.innerWidth")
        # flipp
        f=await pg.query_selector('#ep1 .flipp'); await f.scroll_into_view_if_needed()
        await f.click(); r['flipp_pa']=await pg.evaluate("document.querySelector('#ep1 .flipp').classList.contains('pa')")
        await f.click(); r['flipp_av']=not await pg.evaluate("document.querySelector('#ep1 .flipp').classList.contains('pa')")
        # quiz: tingen er låst til tre riktige
        r['legg_skjult_for_quiz']=await pg.evaluate("document.querySelector('#ep1 .belonning').hidden && document.querySelector('#ep1 .legg').offsetWidth===0")
        r['husk_skjult_for_quiz']=await pg.evaluate("document.querySelector('#ep1 .husk').offsetWidth===0")
        await pg.evaluate("document.querySelector('#ep1 .spm .alt button:not([data-r])').click()")
        r['feil_laaser']=await pg.evaluate("(()=>{const s=document.querySelector('#ep1 .spm');return s.classList.contains('vent') && [...s.querySelectorAll('.alt button')].every(b=>b.disabled)})()")
        r['feil_hint']=(await pg.inner_text('#ep1 .spm .knutsier'))[:70]
        await pg.evaluate("document.querySelector('#ep1 .spm .alt button[data-r]').click()")
        r['riktig_under_venting_ignoreres']=await pg.evaluate("!document.querySelector('#ep1 .spm').classList.contains('ok')")
        await pg.evaluate("document.querySelector('#ep1 .garute').click()"); await pg.wait_for_timeout(700)
        r['ga_til_rute']=await pg.evaluate("Math.abs(document.querySelectorAll('#ep1 .rute')[2].getBoundingClientRect().top)<80")
        await pg.wait_for_timeout(8300)
        r['etter_venting']=await pg.evaluate("(()=>{const s=document.querySelector('#ep1 .spm');return !s.classList.contains('vent') && s.querySelectorAll('.alt button:not(:disabled)').length===2})()")
        for i in range(3):
            await pg.evaluate(f"document.querySelectorAll('#ep1 .spm')[{i}].querySelector('.alt button[data-r]').click()")
            if i==1: r['to_av_tre_fortsatt_laast']=await pg.evaluate("document.querySelector('#ep1 .belonning').hidden")
        await pg.wait_for_timeout(600)
        r['tre_av_tre_aapner']=await pg.evaluate("!document.querySelector('#ep1 .belonning').hidden && document.querySelector('#ep1 .legg').offsetWidth>0")
        await pg.screenshot(path='shots/q2.png')
        # samle
        await pg.click('#ep1 .legg'); await pg.wait_for_timeout(100)
        r['quiz_borte_etter_samling']=await pg.evaluate("document.querySelector('#ep1 .quiz').hidden")
        r['lagt_vises']=await pg.evaluate("!document.querySelector('#ep1 .lagt').hidden && document.querySelector('#ep1 .legg').hidden")
        await pg.click('#ep1 .videre a.knapp'); await pg.wait_for_timeout(150); r['neste_hash']=await pg.evaluate('location.hash')
        r['ep2_laast']=await pg.evaluate("document.querySelector('#ep2 .legg').offsetWidth===0")
        await pg.evaluate("document.querySelector('#ep2 .spm .alt button:not([data-r])').click()"); await pg.evaluate("document.querySelector('#ep2 .quiz').scrollIntoView()"); await pg.wait_for_timeout(300); await pg.screenshot(path='shots/q1.png')
        await pg.wait_for_timeout(8200)
        await pg.evaluate("document.querySelectorAll('#ep2 .alt button[data-r]').forEach(b=>b.click())"); await pg.wait_for_timeout(100)
        await pg.click('#ep2 .legg')
        await pg.click('#ep2 .tilbake'); await pg.wait_for_timeout(150)
        r['antall']=await pg.inner_text('#antall'); r['start_etter']=await pg.inner_text('#start')
        r['har']=await pg.evaluate("[...document.querySelectorAll('.plass.har')].map(e=>e.dataset.n).join()")
        r['status3']=await pg.inner_text('.luke[data-n="3"] .status')
        await pg.reload(); await pg.wait_for_timeout(200)
        r['antall_etter_reload']=await pg.inner_text('#antall')
        await pg.evaluate("document.getElementById('hylla').scrollIntoView()"); await pg.screenshot(path='shots/f1.png')
        # alle episoder: sjekk at hver har 1 flipp og bilder med bredde
        r['quiz_per_ep']=await pg.evaluate("[...document.querySelectorAll('article.ep')].map(a=>a.querySelectorAll('.spm').length+'/'+a.querySelectorAll('.alt button[data-r]').length+'/'+a.querySelectorAll('.alt button').length).join(' ')")
        r['ep1_ulaast_etter_reload']=await pg.evaluate("!document.querySelector('#ep1 .belonning').hidden && document.querySelector('#ep3 .belonning').hidden")
        r['flipp_per_ep']=await pg.evaluate("[...document.querySelectorAll('article.ep')].map(a=>a.querySelectorAll('.flipp').length).join('')")
        r['use_uten_symbol']=await pg.evaluate("[...new Set([...document.querySelectorAll('use')].map(u=>u.getAttribute('href').slice(1)).filter(i=>!document.getElementById(i)))].join()")
        await pg.click('#tom'); await pg.click('#tom'); r['etter_tom']=await pg.inner_text('#antall')
        # mørk modus
        await pg.emulate_media(color_scheme='dark'); await pg.evaluate("location.hash='#hjem'"); await pg.wait_for_timeout(100)
        await pg.screenshot(path='shots/f2.png')
        await pg.evaluate("location.hash='#ep7'"); await pg.wait_for_timeout(100); await pg.screenshot(path='shots/f3.png')
        r['feil']=errs
        for k,v in r.items(): print(k,':',v)
        await b.close()
    ims=[Image.open(f'shots/f{i}.png') for i in (1,2,3)]
    s=Image.new('RGB',(360*3,780)); [s.paste(im,(k*360,0)) for k,im in enumerate(ims)]; s.save('shots/fsheet.png')
asyncio.run(main())
