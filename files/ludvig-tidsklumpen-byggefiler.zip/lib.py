# -*- coding: utf-8 -*-
"""Felles figurbibliotek for Ludvig og Tidsklumpen."""
INK = "#2A1F33"
SYM = {}  # id -> (w, h, body)


def sym(i, w, h, body):
    SYM[i] = (w, h, body.strip())


TORSO = "M40 80 C52 74 70 74 82 80 C88 98 88 110 84 122 C68 127 52 127 38 122 C34 108 34 96 40 80 Z"
HEAD = "M60 12 C82 12 94 28 93 46 C92 64 78 78 60 78 C42 78 28 64 27 46 C26 28 38 12 60 12 Z"

HAIR = {
    "pigg": lambda c, c2: f'<path d="M28 32 C26 14 42 4 56 6 C52 -1 66 -4 70 3 C76 -2 86 2 85 10 C95 12 98 22 93 32 C86 20 72 15 58 18 C45 21 33 25 28 32 Z" fill="{c}" stroke="{INK}" stroke-width="2.4" stroke-linejoin="round"/><path d="M56 6 C52 -1 66 -4 70 3 C64 3 59 4 56 6 Z" fill="{c2}"/>',
    "kort": lambda c, c2: f'<path d="M27 42 C24 22 40 9 60 9 C80 9 96 22 93 42 C84 29 72 24 60 24 C48 24 36 29 27 42 Z" fill="{c}" stroke="{INK}" stroke-width="2.4" stroke-linejoin="round"/>',
    "lue": lambda c, c2: f'<path d="M26 38 C24 14 44 2 62 3 C82 4 96 18 94 38 C76 31 44 31 26 38 Z" fill="{c}" stroke="{INK}" stroke-width="2.4" stroke-linejoin="round"/><path d="M62 3 C74 -8 88 -4 92 8" fill="none" stroke="{c}" stroke-width="8" stroke-linecap="round"/><circle cx="94" cy="10" r="6" fill="{c2}" stroke="{INK}" stroke-width="2"/>',
    "skygge": lambda c, c2: f'<path d="M28 34 C28 14 44 6 60 6 C76 6 92 14 92 34 Z" fill="{c}" stroke="{INK}" stroke-width="2.4" stroke-linejoin="round"/><path d="M24 34 C40 28 80 28 100 36 C84 38 44 38 24 34 Z" fill="{c2}" stroke="{INK}" stroke-width="2.2" stroke-linejoin="round"/>',
    "kroll": lambda c, c2: "".join(f'<circle cx="{x}" cy="{y}" r="9.5" fill="{c}" stroke="{INK}" stroke-width="2"/>' for x, y in [(31, 34), (38, 21), (50, 13), (63, 10), (76, 14), (86, 23), (91, 35)]) + f'<path d="M30 36 C36 20 84 18 91 36 C80 26 42 26 30 36 Z" fill="{c}"/>',
}
HAIR["lang"] = HAIR["kort"]
HAIR["fletter"] = HAIR["kort"]
HAIR["knute"] = lambda c, c2: f'<circle cx="60" cy="5" r="10" fill="{c}" stroke="{INK}" stroke-width="2.2"/>' + HAIR["kort"](c, c2)
HAIR["ingen"] = lambda c, c2: ""


def fig(i, skin="#F2C49A", skin_sh="#DCA379", hair="kort", hc="#6E5340", hc2="#8A6A52",
        top="#E8B549", top_sh="#C4913A", stripes=None, legs="#3E5F87", legs_dk="#2C466B",
        shoes="#33303E", glasses=False, crack=0, mouth="smil", arms="ned", kjole=False,
        freckles=False, skjegg=None, extra="", sokker=None, belt=None):
    o = []
    if hair == "lang":
        o.append(f'<path d="M24 38 C18 70 20 94 30 102 L90 102 C100 94 102 70 96 38 Z" fill="{hc}" stroke="{INK}" stroke-width="2.2"/>')
    # bein
    o.append(f'<path d="M52 118 C46 138 42 152 38 164" fill="none" stroke="{legs_dk}" stroke-width="13" stroke-linecap="round"/>'
             f'<path d="M68 118 C74 138 78 152 82 164" fill="none" stroke="{legs_dk}" stroke-width="13" stroke-linecap="round"/>'
             f'<path d="M52 118 C47 136 44 150 40 161" fill="none" stroke="{legs}" stroke-width="9" stroke-linecap="round"/>'
             f'<path d="M68 118 C73 136 76 150 80 161" fill="none" stroke="{legs}" stroke-width="9" stroke-linecap="round"/>')
    if sokker:
        o.append(f'<path d="M41 150 L37 162" stroke="{sokker[0]}" stroke-width="11" stroke-linecap="round"/><path d="M79 150 L83 162" stroke="{sokker[1]}" stroke-width="11" stroke-linecap="round"/>')
    if shoes:
        o.append(f'<path d="M26 166 C26 160 34 157 42 159 C50 161 52 168 48 171 C42 174 30 173 26 169 Z" fill="{shoes}" stroke="{INK}" stroke-width="2"/>'
                 f'<path d="M94 166 C94 160 86 157 78 159 C70 161 68 168 72 171 C78 174 90 173 94 169 Z" fill="{shoes}" stroke="{INK}" stroke-width="2"/>')
    if kjole:
        o.append(f'<path d="M38 116 C35 132 32 144 29 152 L91 152 C88 144 85 132 82 116 Z" fill="{top}" stroke="{INK}" stroke-width="2.4" stroke-linejoin="round"/>'
                 f'<path d="M70 118 L80 152 L91 152 C88 144 85 132 82 118 Z" fill="{top_sh}" opacity=".6"/>')
    # armer
    if arms == "opp":
        o.append(f'<path d="M42 86 C28 80 20 66 16 52" fill="none" stroke="{top}" stroke-width="12" stroke-linecap="round"/>'
                 f'<path d="M78 86 C92 80 100 66 104 52" fill="none" stroke="{top}" stroke-width="12" stroke-linecap="round"/>'
                 f'<circle cx="15" cy="46" r="7" fill="{skin}" stroke="{INK}" stroke-width="2"/><circle cx="105" cy="46" r="7" fill="{skin}" stroke="{INK}" stroke-width="2"/>')
    else:
        o.append(f'<path d="M42 84 C30 92 24 104 22 116" fill="none" stroke="{top}" stroke-width="12" stroke-linecap="round"/>'
                 f'<path d="M78 84 C90 92 96 104 98 116" fill="none" stroke="{top}" stroke-width="12" stroke-linecap="round"/>'
                 f'<circle cx="20" cy="120" r="7" fill="{skin}" stroke="{INK}" stroke-width="2"/><circle cx="100" cy="120" r="7" fill="{skin}" stroke="{INK}" stroke-width="2"/>')
    # kropp
    o.append(f'<clipPath id="c_{i}"><path d="{TORSO}"/></clipPath><path d="{TORSO}" fill="{top}"/><g clip-path="url(#c_{i})">')
    if stripes:
        o.append(f'<rect x="30" y="90" width="64" height="7" fill="{stripes}"/><rect x="30" y="106" width="64" height="7" fill="{stripes}"/>')
    o.append(f'<path d="M72 72 C82 90 84 112 78 128 L96 128 L96 70 Z" fill="{top_sh}" opacity=".5"/></g>'
             f'<path d="{TORSO}" fill="none" stroke="{INK}" stroke-width="2.4"/>')
    if belt:
        o.append(f'<path d="M37 112 C52 117 70 117 85 112" fill="none" stroke="{belt}" stroke-width="5"/>')
    # hode
    o.append(f'<path d="{HEAD}" fill="{skin}"/><path d="M78 14 C90 26 92 62 76 76 L96 76 L96 10 Z" fill="{skin_sh}" opacity=".45"/>')
    o.append(HAIR[hair](hc, hc2))
    o.append(f'<path d="{HEAD}" fill="none" stroke="{INK}" stroke-width="2.4"/>')
    if hair == "fletter":
        o.append(f'<path d="M27 50 C18 70 20 92 24 106" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/><path d="M27 50 C18 70 20 92 24 106" fill="none" stroke="{hc}" stroke-width="7" stroke-linecap="round" stroke-dasharray="9 3"/>'
                 f'<path d="M93 50 C102 70 100 92 96 106" fill="none" stroke="{INK}" stroke-width="11" stroke-linecap="round"/><path d="M93 50 C102 70 100 92 96 106" fill="none" stroke="{hc}" stroke-width="7" stroke-linecap="round" stroke-dasharray="9 3"/>')
    if glasses:
        o.append(f'<path d="M28 44 C46 37 76 36 92 42 L92 49 C76 43 46 44 29 51 Z" fill="#6E5340" stroke="{INK}" stroke-width="2"/>')
        for cx, cy, left in ((45, 47, True), (75, 46, False)):
            o.append(f'<circle cx="{cx}" cy="{cy}" r="15" fill="#C99B4E" stroke="{INK}" stroke-width="2"/>')
            if left and crack == 2:
                o.append(f'<circle cx="{cx}" cy="{cy}" r="12.5" fill="{skin}"/><circle cx="{cx+1}" cy="{cy+1}" r="4" fill="{INK}"/>')
            else:
                o.append(f'<circle cx="{cx}" cy="{cy}" r="12.5" fill="#CFE9EE"/><circle cx="{cx}" cy="{cy}" r="7" fill="#FFFDF8"/><circle cx="{cx+1}" cy="{cy+1}" r="4" fill="{INK}"/>'
                         f'<path d="M{cx-10} {cy-7} L{cx+9} {cy-14} L{cx+13} {cy-9} L{cx-6} {cy-1} Z" fill="#fff" opacity=".55"/>')
                if left and crack == 1:
                    o.append(f'<path d="M{cx-9} {cy-8} L{cx-2} {cy-1} L{cx-6} {cy+3} L{cx+3} {cy+10}" fill="none" stroke="{INK}" stroke-width="1.6"/>')
    else:
        o.append(f'<circle cx="47" cy="48" r="4.4" fill="{INK}"/><circle cx="73" cy="47" r="4.4" fill="{INK}"/><circle cx="48.5" cy="46.5" r="1.3" fill="#fff"/><circle cx="74.5" cy="45.5" r="1.3" fill="#fff"/>'
                 f'<path d="M40 39 C44 36 50 36 54 38" fill="none" stroke="{INK}" stroke-width="2" stroke-linecap="round"/><path d="M66 37 C70 35 76 35 80 38" fill="none" stroke="{INK}" stroke-width="2" stroke-linecap="round"/>')
    if skjegg:
        o.append(f'<path d="M34 58 C36 80 50 88 60 88 C70 88 84 80 86 58 C78 68 70 70 60 70 C50 70 42 68 34 58 Z" fill="{skjegg}" stroke="{INK}" stroke-width="2"/>')
    if mouth == "smil":
        o.append(f'<path d="M52 64 C58 71 68 70 72 63" fill="none" stroke="{INK}" stroke-width="2.6" stroke-linecap="round"/>')
    elif mouth == "o":
        o.append(f'<ellipse cx="62" cy="66" rx="6.5" ry="7.5" fill="{INK}"/><ellipse cx="62" cy="69" rx="3.5" ry="3" fill="#C0453D"/>')
    else:
        o.append(f'<path d="M53 66 L71 65" fill="none" stroke="{INK}" stroke-width="2.6" stroke-linecap="round"/>')
    if freckles:
        o.append('<g fill="#C4643A" opacity=".7"><circle cx="36" cy="58" r="1.6"/><circle cx="40" cy="63" r="1.6"/><circle cx="84" cy="57" r="1.6"/><circle cx="80" cy="62" r="1.6"/></g>')
    o.append(extra)
    sym(i, 120, 185, "".join(o))


# Ludvig: tre brilletilstander (0 hel, 1 sprekk fra ep2, 2 ett glass fra ep10) x to positurer
for cr in (0, 1, 2):
    for pose, arms, mouth in (("s", "ned", "smil"), ("o", "opp", "o"), ("f", "ned", "flat")):
        fig(f"lud{pose}{cr}", hair="pigg", hc="#D8602C", hc2="#F0894B", stripes="#F7EEDC", glasses=True,
            crack=cr, arms=arms, mouth=mouth, freckles=True, sokker=("#C0453D", "#4A8F6B"), shoes="#33303E")


def back(i, coat="#6E6A7A", coat_sh="#55515F", hair="#4A4046", hat=None, extra=""):
    """Voksen sett bakfra. Ekte personer vises aldri med ansikt."""
    o = [f'<path d="M22 196 C20 140 26 96 38 82 C50 74 70 74 82 82 C94 96 100 140 98 196 Z" fill="{coat}" stroke="{INK}" stroke-width="2.4" stroke-linejoin="round"/>',
         f'<path d="M72 80 C92 96 98 150 96 196 L98 196 C100 140 94 96 82 82 Z" fill="{coat_sh}"/>',
         f'<path d="M60 84 L60 196" stroke="{coat_sh}" stroke-width="2"/>',
         f'<circle cx="60" cy="50" r="27" fill="{hair}" stroke="{INK}" stroke-width="2.4"/>',
         f'<path d="M46 72 C54 80 66 80 74 72 L74 84 L46 84 Z" fill="#E3B48E" stroke="{INK}" stroke-width="2"/>',
         f'<ellipse cx="31" cy="52" rx="5" ry="8" fill="#E3B48E" stroke="{INK}" stroke-width="2"/><ellipse cx="89" cy="52" rx="5" ry="8" fill="#E3B48E" stroke="{INK}" stroke-width="2"/>']
    if hat:
        o.append(f'<path d="M36 32 C36 10 84 10 84 32 Z" fill="{hat}" stroke="{INK}" stroke-width="2.4"/><ellipse cx="60" cy="33" rx="42" ry="8" fill="{hat}" stroke="{INK}" stroke-width="2.4"/><path d="M36 28 C50 32 70 32 84 28" fill="none" stroke="{INK}" stroke-width="3"/>')
    o.append(extra)
    sym(i, 120, 200, "".join(o))


# ---------- Tidsklumpen: handlevogn + tørketrommel + teip + bjelle ----------
sym("vogn", 180, 124, f'''
<path d="M14 30 L152 30 L138 96 L34 96 Z" fill="#D8D3DC"/><path d="M110 30 L152 30 L138 96 L104 96 Z" fill="#BDB7C6"/>
<g stroke="#9C97A6" stroke-width="2"><line x1="42" y1="30" x2="40" y2="96"/><line x1="70" y1="30" x2="70" y2="96"/><line x1="98" y1="30" x2="100" y2="96"/><line x1="126" y1="30" x2="130" y2="96"/><line x1="19" y1="54" x2="147" y2="54"/><line x1="24" y1="76" x2="142" y2="76"/></g>
<circle cx="80" cy="48" r="30" fill="#EDEAF1" stroke="{INK}" stroke-width="2.6"/><circle cx="80" cy="48" r="20" fill="#5D7C93" stroke="{INK}" stroke-width="2.2"/><path d="M66 40 C72 32 86 30 94 38" fill="none" stroke="#CFE9EE" stroke-width="3" stroke-linecap="round"/><circle cx="104" cy="26" r="3" fill="#C0453D"/>
<g fill="#E9D9A8" stroke="{INK}" stroke-width="1.4"><path d="M22 60 L60 34 L64 40 L26 66 Z"/><path d="M98 70 L140 44 L143 50 L101 76 Z"/><path d="M44 84 L112 88 L112 94 L44 90 Z"/></g>
<path d="M14 30 L152 30 L138 96 L34 96 Z" fill="none" stroke="{INK}" stroke-width="3"/>
<path d="M152 30 L170 12" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>
<path d="M166 16 l0 8" stroke="{INK}" stroke-width="1.6"/><circle cx="166" cy="30" r="7" fill="#C99B4E" stroke="{INK}" stroke-width="2"/><path d="M161 31 l10 0" stroke="{INK}" stroke-width="1.6"/>
<path d="M34 96 L44 108 L130 108 L138 96" fill="none" stroke="{INK}" stroke-width="3"/>
<circle cx="52" cy="112" r="10" fill="#4A4657" stroke="{INK}" stroke-width="2.5"/><circle cx="52" cy="112" r="3.5" fill="#8E89A0"/>
<circle cx="124" cy="112" r="10" fill="#4A4657" stroke="{INK}" stroke-width="2.5"/><circle cx="124" cy="112" r="3.5" fill="#8E89A0"/>''')

sym("knut", 160, 120, f'''
<path d="M120 92 C150 98 156 74 152 58" fill="none" stroke="{INK}" stroke-width="7" stroke-linecap="round"/><path d="M120 92 C150 98 156 74 152 58" fill="none" stroke="#BCADA6" stroke-width="3.5" stroke-linecap="round"/>
<ellipse cx="94" cy="82" rx="40" ry="30" fill="#A3A0AE"/><ellipse cx="88" cy="92" rx="27" ry="18" fill="#CFCBD8"/>
<path d="M110 56 c14 16 16 46 4 60 l22 0 0 -62 Z" fill="#85818F" opacity=".5"/><ellipse cx="94" cy="82" rx="40" ry="30" fill="none" stroke="{INK}" stroke-width="2.4"/>
<ellipse cx="46" cy="34" rx="14" ry="13" fill="#A3A0AE" stroke="{INK}" stroke-width="2.4"/><ellipse cx="46" cy="35" rx="7.5" ry="7" fill="#EFA3B6"/>
<ellipse cx="76" cy="28" rx="14" ry="13" fill="#A3A0AE" stroke="{INK}" stroke-width="2.4"/><ellipse cx="76" cy="29" rx="7.5" ry="7" fill="#EFA3B6"/>
<path d="M84 17 l-8 9 l9 7" fill="#F7EDDA" stroke="{INK}" stroke-width="2" stroke-linejoin="round"/>
<circle cx="60" cy="62" r="29" fill="#A3A0AE"/><path d="M78 38 c14 18 14 48 0 62 l20 0 0 -64 Z" fill="#85818F" opacity=".45"/><circle cx="60" cy="62" r="29" fill="none" stroke="{INK}" stroke-width="2.4"/>
<path d="M34 56 C16 58 8 66 10 74 C13 82 26 83 36 78 Z" fill="#CFCBD8" stroke="{INK}" stroke-width="2.4" stroke-linejoin="round"/>
<ellipse cx="11" cy="71" rx="6" ry="5" fill="#EFA3B6" stroke="{INK}" stroke-width="2"/>
<g stroke="{INK}" stroke-width="1.4" opacity=".8"><path d="M14 79 L4 86"/><path d="M17 82 L11 91"/></g>
<circle cx="44" cy="60" r="11" fill="#EAF6FA" opacity=".65" stroke="#C99B4E" stroke-width="2"/><circle cx="72" cy="58" r="11" fill="#EAF6FA" opacity=".65" stroke="#C99B4E" stroke-width="2"/>
<path d="M55 59 c4 -2 7 -2 10 0" fill="none" stroke="#C99B4E" stroke-width="2"/>
<circle cx="44" cy="61" r="5" fill="{INK}"/><circle cx="72" cy="59" r="5" fill="{INK}"/>
<path d="M34 55 C40 49 52 48 58 52" fill="none" stroke="{INK}" stroke-width="2.4" stroke-linecap="round"/><path d="M62 53 C68 47 80 46 86 50" fill="none" stroke="{INK}" stroke-width="2.4" stroke-linecap="round"/>
<path d="M50 78 c8 -4 16 -3 22 2" fill="none" stroke="{INK}" stroke-width="2.2" stroke-linecap="round"/>
<path d="M74 96 C92 106 110 104 122 96 C120 110 106 118 96 118 C84 118 76 108 74 96 Z" fill="#4A8F6B" stroke="{INK}" stroke-width="2.4"/>''')

sym("kanel", 140, 80, f'''
<ellipse cx="70" cy="52" rx="52" ry="26" fill="#D98E48"/><path d="M20 50 C30 34 56 26 76 28 C104 31 120 42 122 54 C110 40 88 34 66 36 C46 38 28 42 20 50 Z" fill="#EAAE72" opacity=".8"/>
<g stroke="#B96F31" stroke-width="4" stroke-linecap="round" opacity=".85"><path d="M52 30 c-4 8 -6 14 -6 20"/><path d="M70 28 c-4 8 -6 14 -6 20"/><path d="M88 30 c-4 8 -6 14 -6 20"/></g>
<path d="M118 58 C132 56 138 44 130 36 C126 46 122 52 116 54 Z" fill="#D98E48" stroke="{INK}" stroke-width="2"/><ellipse cx="70" cy="52" rx="52" ry="26" fill="none" stroke="{INK}" stroke-width="2.4"/>
<circle cx="36" cy="42" r="20" fill="#D98E48" stroke="{INK}" stroke-width="2.4"/>
<path d="M22 28 l2 -14 l14 8 Z" fill="#D98E48" stroke="{INK}" stroke-width="2.2" stroke-linejoin="round"/><path d="M48 26 l8 -12 l6 12 Z" fill="#D98E48" stroke="{INK}" stroke-width="2.2" stroke-linejoin="round"/>
<path d="M25 27 l1 -8 l7 4 Z" fill="#EFA3B6"/><path d="M49 26 l5 -8 l4 8 Z" fill="#EFA3B6"/>
<path d="M26 40 c4 3 8 3 11 0" fill="none" stroke="{INK}" stroke-width="2.2" stroke-linecap="round"/><path d="M41 40 c4 3 8 3 11 0" fill="none" stroke="{INK}" stroke-width="2.2" stroke-linecap="round"/>
<path d="M34 48 l4 3 l4 -3" fill="none" stroke="{INK}" stroke-width="2" stroke-linecap="round"/>
<path d="M20 60 C32 68 48 68 58 62" fill="none" stroke="#4A8F6B" stroke-width="6"/><circle cx="40" cy="66" r="5" fill="#C99B4E" stroke="{INK}" stroke-width="2"/>''')

# ---------- Garasjen (hjemme) ----------
sym("bgG", 360, 220, f'''
<rect width="360" height="220" fill="#CDB892"/><g fill="#B39C74">{"".join(f'<circle cx="{x}" cy="{y}" r="1.6"/>' for x in range(14, 360, 22) for y in range(14, 160, 22))}</g>
<rect y="168" width="360" height="52" fill="#8C8896"/><path d="M0 168 L360 168" stroke="{INK}" stroke-width="2.4"/>
<rect x="18" y="62" width="196" height="9" fill="#8E6B45" stroke="{INK}" stroke-width="2.2"/><rect x="18" y="28" width="196" height="7" fill="#8E6B45" stroke="{INK}" stroke-width="2.2"/>
<g stroke="{INK}" stroke-width="1.8"><rect x="28" y="46" width="12" height="16" fill="#7FA88C"/><circle cx="58" cy="54" r="8" fill="#C99B4E"/><rect x="76" y="50" width="18" height="12" rx="2" fill="#C0806A"/><path d="M106 62 l6 -18 l6 18 Z" fill="#E8B549"/></g>
<rect x="236" y="34" width="30" height="34" fill="#FFFDF8" stroke="{INK}" stroke-width="2" transform="rotate(-5 250 50)"/><ellipse cx="250" cy="48" rx="9" ry="6" fill="#D98E48" transform="rotate(-5 250 50)"/><path d="M240 30 l22 0" stroke="#E9D9A8" stroke-width="6" transform="rotate(-5 250 50)"/>
<rect x="296" y="40" width="64" height="128" fill="#FBF2DC" stroke="{INK}" stroke-width="2.6"/><path d="M296 40 L318 54 L318 168 L296 168 Z" fill="#B98D5E" stroke="{INK}" stroke-width="2.4"/><circle cx="313" cy="110" r="3" fill="{INK}"/>''')

# ---------- Gjenstandene (ikoner 48x48) ----------
OBJ = {
    "o1": f'<path d="M5 31 L39 15 L44 26 L10 42 Z" fill="#E9D9A8" stroke="{INK}" stroke-width="2.2" stroke-linejoin="round"/><path d="M14 41 C11 27 22 10 39 5 C42 20 31 36 14 41 Z" fill="#3E9AA0" stroke="{INK}" stroke-width="2.2" stroke-linejoin="round"/><path d="M39 5 C42 12 40 18 37 23 C33 18 33 11 39 5 Z" fill="#E8A93A"/><path d="M15 40 C21 28 29 16 38 7" fill="none" stroke="#FFFDF8" stroke-width="2" stroke-linecap="round"/><path d="M21 31 l-5 -3 M26 24 l-5 -4 M31 17 l-4 -4 M23 33 l6 0 M28 26 l6 -1" stroke="{INK}" stroke-width="1.4" stroke-linecap="round"/>',
    "o2": f'<path d="M8 40 L36 10 C40 6 44 10 40 14 L12 42 Z" fill="#F1E2C0" stroke="{INK}" stroke-width="2.2" stroke-linejoin="round"/><circle cx="37" cy="12" r="2" fill="{INK}"/><path d="M38 11 C46 16 40 28 30 30 C22 32 20 40 26 44" fill="none" stroke="#8E6B45" stroke-width="1.8"/>',
    "o3": f'<circle cx="24" cy="24" r="17" fill="#D9D6DE" stroke="{INK}" stroke-width="2.4"/><circle cx="24" cy="24" r="12" fill="none" stroke="#8C8896" stroke-width="1.6"/><path d="M16 22 c3 -4 6 4 9 0 s5 3 7 0 M17 28 c3 -3 5 3 8 0 s4 2 6 0" fill="none" stroke="{INK}" stroke-width="1.6" stroke-linecap="round"/>',
    "o4": f'<circle cx="24" cy="26" r="18" fill="#B98D5E" stroke="{INK}" stroke-width="2.4"/><path d="M24 8 L24 44 M6 26 L42 26 M11 13 L37 39 M37 13 L11 39" stroke="#8E6B45" stroke-width="2.2"/><circle cx="24" cy="26" r="4" fill="#8E6B45"/><path d="M12 18 C16 12 26 9 32 11" fill="none" stroke="#DDB77E" stroke-width="2.4" stroke-linecap="round"/>',
    "o5": f'<path d="M10 42 L6 38 L30 12 L36 18 Z" fill="#C8773F" stroke="{INK}" stroke-width="2.2" stroke-linejoin="round"/><path d="M30 12 L40 6 L42 8 L36 18 Z" fill="#E0A070" stroke="{INK}" stroke-width="2.2" stroke-linejoin="round"/><path d="M14 36 L28 20" stroke="#E7B089" stroke-width="2" stroke-linecap="round"/>',
    "o6": f'<path d="M8 34 L34 10 L42 18 L16 42 Z" fill="#FFFDF8" stroke="{INK}" stroke-width="2.2" stroke-linejoin="round"/><path d="M34 10 L42 18" stroke="{INK}" stroke-width="2.2"/><path d="M8 34 L16 42 L10 44 L6 40 Z" fill="#D9D6DE" stroke="{INK}" stroke-width="2"/>',
    "o7": f'<path d="M14 40 L14 14 C14 4 30 4 30 14 L30 36 C30 42 20 42 20 36 L20 18 C20 14 25 14 25 18 L25 34" fill="none" stroke="{INK}" stroke-width="6" stroke-linecap="round"/><path d="M14 40 L14 14 C14 4 30 4 30 14 L30 36 C30 42 20 42 20 36 L20 18 C20 14 25 14 25 18 L25 34" fill="none" stroke="#D9D6DE" stroke-width="2.6" stroke-linecap="round"/>',
    "o8": f'<circle cx="14" cy="16" r="9" fill="#C99B4E" stroke="{INK}" stroke-width="2.4"/><circle cx="14" cy="16" r="3.5" fill="#F6EBD4" stroke="{INK}" stroke-width="1.6"/><path d="M20 22 L42 42 M34 35 L30 39 M39 39 L35 43" stroke="{INK}" stroke-width="6" stroke-linecap="round"/><path d="M20 22 L42 42 M34 35 L30 39 M39 39 L35 43" stroke="#C99B4E" stroke-width="2.6" stroke-linecap="round"/>',
    "o9": f'<path d="M4 12 C12 40 36 40 44 12" fill="#E9D9A8" stroke="{INK}" stroke-width="2.4" stroke-linejoin="round"/><path d="M10 16 C16 34 32 34 38 16 M16 14 C20 28 28 28 32 14 M7 22 L41 22 M12 30 L36 30" fill="none" stroke="#B98D5E" stroke-width="1.5"/><circle cx="4" cy="12" r="3" fill="#8E6B45" stroke="{INK}" stroke-width="1.4"/><circle cx="44" cy="12" r="3" fill="#8E6B45" stroke="{INK}" stroke-width="1.4"/>',
    "o10": f'<rect x="9" y="6" width="30" height="38" rx="3" fill="#4F6B4E" stroke="{INK}" stroke-width="2.4"/><rect x="14" y="12" width="20" height="8" fill="#E9D9A8" stroke="{INK}" stroke-width="1.4"/><circle cx="24" cy="31" r="7" fill="none" stroke="#C99B4E" stroke-width="2"/><path d="M9 10 L5 12 L5 42 L9 40" fill="#3B523A" stroke="{INK}" stroke-width="1.8"/>',
    "o11": f'<path d="M6 16 L14 12 L20 15 L28 10 L36 14 L42 12 L42 36 L34 39 L27 35 L19 39 L12 35 L6 37 Z" fill="#FFFDF8" stroke="{INK}" stroke-width="2.2" stroke-linejoin="round"/><text x="24" y="24" text-anchor="middle" font-family="Caveat,Comic Relief,cursive" font-size="11" font-weight="700" fill="#2C466B">1202</text><text x="24" y="34" text-anchor="middle" font-family="Caveat,Comic Relief,cursive" font-size="10" font-weight="700" fill="#C0453D">= GO</text>',
}
for k, v in OBJ.items():
    sym(k, 48, 48, v)
