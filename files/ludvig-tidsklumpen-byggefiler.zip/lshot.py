import asyncio, os
from playwright.async_api import async_playwright
from PIL import Image
U='file://'+os.path.abspath('index.html')
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':390,'height':844},color_scheme='dark')
        errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(U); await pg.wait_for_timeout(1000)
        await pg.screenshot(path='shots/l1.png')
        nb_synlig=await pg.evaluate("[...document.querySelectorAll('.en')].filter(e=>e.getClientRects().length).length")
        await pg.click('#sprak'); await pg.wait_for_timeout(300)
        en_synlig=await pg.evaluate("[...document.querySelectorAll('.nb')].filter(e=>e.getClientRects().length).length")
        await pg.screenshot(path='shots/l2.png')
        await pg.click('#hopp'); await pg.wait_for_timeout(900); await pg.screenshot(path='shots/l3.png')
        await pg.evaluate("document.querySelector('#greia').scrollIntoView()"); await pg.wait_for_timeout(200); await pg.screenshot(path='shots/l4.png')
        await pg.goto(U+'#ep1'); await pg.wait_for_timeout(700)
        await pg.evaluate("document.querySelector('#e1r6').scrollIntoView()"); await pg.wait_for_timeout(200); await pg.screenshot(path='shots/l5.png')
        await pg.evaluate("document.querySelector('#ep1 .quiz').scrollIntoView()"); await pg.wait_for_timeout(200)
        # svar feil på første, riktig på resten
        await pg.click('#ep1 .spm:nth-of-type(1) .alt button:not([data-r])'); await pg.wait_for_timeout(300)
        await pg.screenshot(path='shots/l6.png')
        ov=await pg.evaluate("document.documentElement.scrollWidth>document.documentElement.clientWidth")
        sp=await pg.evaluate("[document.documentElement.lang, localStorage.getItem('tidsklumpen-sprak-v1'), document.querySelector('#epost').placeholder]")
        print('engelsk synlig i norsk:',nb_synlig,'norsk synlig i engelsk:',en_synlig,'sideveis:',ov,'feil:',errs, sp)
        await b.close()
    ims=[Image.open(f'shots/l{i}.png') for i in range(1,7)]
    s=Image.new('RGB',(390*3,844*2))
    for k,im in enumerate(ims): s.paste(im,((k%3)*390,(k//3)*844))
    s.save('shots/lsheet.png')
asyncio.run(main())
