import asyncio, json, subprocess, urllib.request
from playwright.async_api import async_playwright
from PIL import Image
B='http://localhost:8765'
async def main():
    srv=subprocess.Popen(['node','lokal.js'],stdout=subprocess.PIPE); srv.stdout.readline()
    try:
      async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':780})
        await pg.goto(B+'/#blimed'); await pg.wait_for_timeout(700)
        await pg.evaluate("window.scrollBy(0,-70)"); await pg.screenshot(path='shots/e1.png')
        await pg.fill('#epost','voksen@eksempel.no'); await pg.click('#meldpaa'); await pg.wait_for_timeout(400)
        await pg.evaluate("document.querySelector('.luker').scrollIntoView(); window.scrollBy(0,-330)"); await pg.wait_for_timeout(200); await pg.screenshot(path='shots/e2.png')
        m=json.loads(urllib.request.urlopen(B+'/__test?sendt=1').read())
        pg2=await b.new_page(viewport={'width':360,'height':780}); await pg2.set_content(m[0]['html']); await pg2.wait_for_timeout(200); await pg2.screenshot(path='shots/e3.png')
        await b.close()
    finally: srv.kill()
    ims=[Image.open(f'shots/e{i}.png') for i in (1,2,3)]
    s=Image.new('RGB',(1080,780)); [s.paste(im,(k*360,0)) for k,im in enumerate(ims)]; s.save('shots/esheet.png')
asyncio.run(main())
