import json, subprocess, urllib.request, asyncio
from playwright.async_api import async_playwright
B='http://localhost:8765'
def hent(p, **kw):
    try:
        with urllib.request.urlopen(urllib.request.Request(B+p, **kw)) as r: return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
def post(d): return hent('/api/meld-paa', data=json.dumps({'epost':d}).encode(), headers={'Content-Type':'application/json'}, method='POST')
async def main():
    srv=subprocess.Popen(['node','lokal.js'],stdout=subprocess.PIPE); srv.stdout.readline()
    try:
        r={}
        r['tom']='Ingen påmeldte' in hent('/api/oversikt?n=testnokkel-123456')[1]
        post('a@eksempel.no'); post('b@eksempel.no')
        tok=json.loads(hent('/__test?sendt=1')[1])[0]['text'].split('t=')[1][:32]
        hent('/api/status?t='+tok)
        s,t=hent('/api/oversikt?n=testnokkel-123456')
        r['ok']=(s, t.count('class="kort"'), 'Bekreftet' in t, 'Ikke åpnet' in t, '<b>2</b>påmeldt' in t, '<b>1</b>bekreftet' in t)
        r['feil_nokkel']=hent('/api/oversikt?n=feil')[0]; r['ingen_nokkel']=hent('/api/oversikt')[0]
        async with async_playwright() as p:
            b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':360,'height':640})
            await pg.goto(B+'/api/oversikt?n=testnokkel-123456'); await pg.screenshot(path='shots/oversikt.png'); await b.close()
        print(r)
    finally: srv.kill()
asyncio.run(main())
