# -*- coding: utf-8 -*-
"""Knuts tre spørsmål per episode: (spørsmål, [riktig, feil, tullete feil], rute der svaret står, ord som må finnes i den ruta)."""
QUIZ = {
    1: [("Hva var stjerna på himmelen egentlig?", ["En stein fra verdensrommet", "En helt vanlig stjerne", "Lyset på kantina"], 5, "stein fra verdensrommet"),
        ("Hvorfor fikk ikke T. rex av seg teipen?", ["Armene var for korte", "Den syntes teipen var fin", "Den hadde votter på"], 9, "Armene når ikke"),
        ("Hva ble det av de små dinosaurene med fjær?", ["De ble til fuglene", "De ble til krokodiller", "De flyttet til Mexico"], 11, "fuglene")],
    2: [("Hva fikk huleløven til å gå sin vei?", ["Lyd og ild samtidig", "Bare et stort bål", "En handlevogn med teip"], 8, "Lyd og ild"),
        ("Hva var synåla til Aya laget av?", ["Bein", "Jern", "Plast fra butikken"], 9, "bein"),
        ("Hvorfor var nåla så viktig i istiden?", ["Uten nål ble det ingen varme klær", "Den var fin å se på", "Den kunne åpne hermetikk"], 9, "ingen klær")],
    3: [("Hva tettet Ravn lekkasjen med?", ["Ull og tjære", "Sand og stein", "Teip, og så litt mer teip"], 8, "Ull og tjære"),
        ("Hvorfor tålte vikingskipet de store bølgene?", ["Skroget var bygd for å bøye seg", "Det var laget av jern", "Det hadde motor i kjelleren"], 9, "bøye seg"),
        ("Hadde vikingene horn på hjelmen?", ["Nei", "Ja, to stykker", "Bare på lørdager"], 9, "horn")],
    4: [("Hva var det som falt fra himmelen over Pompeii?", ["Små, lette steiner", "Vanlig regn", "Nybakte boller"], 3, "steiner"),
        ("Hva bandt folk på hodet da de rømte?", ["Puter", "Gryter", "Brød"], 8, "pute"),
        ("Hvor mange brød ble stående i ovnen?", ["81", "8", "Ingen. Ludvig spiste dem"], 9, "81")],
    5: [("Hva gjorde Nefer for at sleden skulle gli?", ["Helte vann på sanden", "Smurte sleden med olje", "Teipet hjul på steinen"], 8, "Våt sand"),
        ("Hvorfor er våt sand bedre enn tørr?", ["Våt sand holder seg flat foran sleden", "Våt sand veier ingenting", "Steinen blir flau og flytter seg selv"], 9, "flat"),
        ("Hva fikk de som bygde pyramidene i lønn?", ["Brød og øl", "Ingenting. De var slaver", "Gratis boller"], 10, "brød og øl")],
    6: [("Hvorfor var det piggtråd rundt hele Los Alamos?", ["Byen var hemmelig", "Det var en dyrehage", "Det var en speiderleir"], 3, "hemmeligste"),
        ("Hva regnet forskerne på?", ["Verdens farligste bombe", "En ny type tidsmaskin", "Hvor mye teip Ludvig trenger"], 4, "bombe"),
        ("Hvordan ble spionen avslørt?", ["Han kunne ikke forklare hva tallene betydde", "Han hadde feil hatt", "Han snublet i teipen til Ludvig"], 8, "betyr")],
    7: [("Hvorfor tok tyskerne radioene fra folk?", ["Så ingen skulle høre nyheter fra London", "De ville høre på musikk selv", "Radioene bråkte for mye"], 4, "London"),
        ("Hvor gjemte Solveig radioen da soldatene kom?", ["I barnevogna", "Under kjøkkenbordet", "I handlevogna til Ludvig"], 8, "barnevogna"),
        ("Hva betydde bindersen i kragen?", ["Vi holder sammen", "Jeg jobber på kontor", "Jeg har mistet en knapp"], 10, "holder sammen")],
    8: [("Hva var bundet fast på barnesyklene?", ["Våpen", "Fiskestenger", "Paraplyer"], 3, "våpen"),
        ("Hvordan kunne folk gå fra hus til hus under jorda?", ["Gjennom hull i kjellerveggene", "Med T-bane", "Gjennom en tunnel rottene hadde gravd"], 7, "hull"),
        ("Hva åpnet nøkkelen til Werner?", ["Kjellerdøra til huset hans", "Postkassa", "Sykkellåsen"], 8, "kjellerdøra")],
    9: [("Hva heter det når havet stiger og synker to ganger om dagen?", ["Tidevann", "Flodbølge", "Badekar"], 3, "tidevann"),
        ("Hva brukte Yari til å slepe vogna i land?", ["Hengekøya", "Et fiskegarn", "Tretti meter teip"], 8, "hengekøya"),
        ("Hvor trodde mannen med kappa at han var?", ["I India", "I Norge", "På månen"], 10, "India")],
    10: [("Hvorfor satte ikke Themba seg på benken?", ["Den var bare for hvite", "Den var nymalt", "Knut satt der allerede"], 4, "hvite"),
         ("Hvor lenge hadde Nelson Mandela sittet i fengsel?", ["27 år", "To år", "Siden i går"], 5, "27 år"),
         ("Hva het loven som delte alt etter hudfarge?", ["Apartheid", "Amandla", "Tidevann"], 11, "apartheid")],
    11: [("Hvor skulle de to mennene lande 20. juli 1969?", ["På månen", "På Mars", "I garasjen til Ludvig"], 3, "månen"),
         ("Hvor gammel var Jack, som kunne datamaskinen best?", ["24 år", "64 år", "11 år, akkurat som Ludvig"], 4, "24 år"),
         ("Hva betydde alarmen 1202?", ["Datamaskinen hadde for mye å gjøre, men klarte seg", "Tanken var tom", "Det var en rotte om bord"], 8, "for mye å gjøre")],
}

# Engelsk utgave: samme rekkefølge, samme rute. (spørsmål, [riktig, feil, tullete feil], ord som må finnes i den engelske ruta)
QUIZ_EN = {
    1: [("What was the star in the sky really?", ["A rock from space", "A perfectly normal star", "The light in the canteen"], "rock from space"),
        ("Why couldn't the T. rex get the tape off?", ["Its arms were too short", "It thought the tape looked nice", "It was wearing mittens"], "arms can't reach"),
        ("What became of the small dinosaurs with feathers?", ["They became the birds", "They became crocodiles", "They moved to Mexico"], "the birds")],
}
