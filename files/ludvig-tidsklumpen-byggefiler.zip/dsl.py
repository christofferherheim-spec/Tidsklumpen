# -*- coding: utf-8 -*-
import html
from lib import SYM, INK, sym
import art  # noqa: registrerer symboler
from art import S, S2

sym("bg2i", 360, 220, f'''
<rect width="360" height="220" fill="#4A4250"/><path d="M130 0 C150 40 200 30 230 50 C270 30 320 44 360 20 L360 0 Z" fill="#3B3340"/>
<path d="M-4 190 L-4 70 C10 38 82 34 106 70 C122 100 120 150 124 190 Z" fill="#C5D3DB" {S}/><path d="M-4 150 C40 142 90 146 121 158 L124 190 L-4 190 Z" fill="#F4F6F6"/><path d="M20 120 L44 92 L66 118 Z" fill="#E4ECEF" {S2}/>
<g fill="none" stroke="#C0806A" stroke-width="3" stroke-linecap="round"><path d="M282 70 c10 -10 26 -10 34 0 l0 14 M286 84 l0 12 M312 84 l0 12 M316 70 l10 -8"/><path d="M244 96 l0 -14 M238 84 l6 -4 l6 4 M250 100 c4 0 4 6 0 6"/></g>
<path d="M0 190 L360 190 L360 220 L0 220 Z" fill="#6E6272" {S}/><path d="M150 204 c20 -4 40 -4 60 0 M250 210 c20 -4 40 -4 60 0" fill="none" stroke="#55495A" stroke-width="2"/>''')
sym("bg8k", 360, 220, f'''
<rect width="360" height="220" fill="#4F4755"/><g stroke="#3F3846" stroke-width="2">{"".join(f'<path d="M0 {y} L360 {y}"/>' for y in range(24, 190, 24))}{"".join(f'<path d="M{x + (12 if (y // 24) % 2 else 0)} {y} l0 24"/>' for y in range(0, 168, 24) for x in range(20, 360, 44))}</g>
<path d="M-4 -4 L96 -4 L60 84 L-4 116 Z" fill="#8C8896" {S}/><path d="M0 30 L80 30 M0 58 L68 58 M0 86 L58 86" stroke="{INK}" stroke-width="2.4"/>
<path d="M112 196 C104 150 120 116 150 112 C176 116 184 150 178 196 Z" fill="#2A2330" {S}/>
<rect x="268" y="66" width="70" height="130" fill="#6E5340" {S}/><rect x="278" y="78" width="50" height="46" fill="#5E4636" {S2}/><rect x="278" y="134" width="50" height="50" fill="#5E4636" {S2}/><circle cx="284" cy="130" r="5" fill="#C99B4E" {S2}/><rect x="282.5" y="130" width="3" height="8" fill="{INK}"/>
<path d="M0 196 L360 196 L360 220 L0 220 Z" fill="#6E6272" {S}/>''')

CUR = {"ep": 1}
esc = html.escape


def B(i, z=1, ox=0, oy=0):
    return f'<use href="#{i}" x="{ox}" y="{oy}" width="{360*z:g}" height="{220*z:g}"/>'


def P(i, x, y, h, flip=False, rot=0, op=1):
    """Figur/rekvisitt med bunn-senter i (x, y) og høyde h."""
    w0, h0, _ = SYM[i]
    w = h * w0 / h0
    t = []
    if rot:
        t.append(f"rotate({rot} {x} {y - h/2:g})")
    if flip:
        t.append(f"translate({2*x} 0) scale(-1 1)")
    tr = f' transform="{" ".join(t)}"' if t else ""
    o = f' opacity="{op}"' if op != 1 else ""
    return f'<use href="#{i}" x="{x - w/2:.1f}" y="{y - h:.1f}" width="{w:.1f}" height="{h:g}"{tr}{o}/>'


def L(x, y=198, h=104, pose="s", flip=False, rot=0):
    e = CUR["ep"]
    cr = 0 if e <= 2 else (1 if e <= 10 else 2)
    return P(f"lud{pose}{cr}", x, y, h, flip, rot)


def K(x, y=198, h=42, flip=False, rot=0):
    return P("knut", x, y, h, flip, rot)


def V(x, y=200, h=80, flip=False, rot=0):
    return P("vogn", x, y, h, flip, rot)


LYD_EN = {"BLITS!": "FLASH!", "DUNK!": "THUD!", "RITSJ!": "RIIIP!", "PLING!": "DING!", "RUNDT!": "ROUND!", "OG RUNDT!": "AND ROUND!",
          "KNEKK!": "CRACK!", "KRASJ!": "CRASH!", "KLAKK!": "CLACK!", "KLAKK! KLAKK!": "CLACK! CLACK!", "AUUUU!": "AWOOO!", "PLASK!": "SPLASH!", "PLOPP!": "PLOP!", "DRYPP": "DRIP",
          "KRAKK!": "CRACK!", "LØP!": "RUN!", "SMEKK!": "SNAP!", "SVISJ!": "SWOOSH!", "RULL!": "ROLL!", "ÆÆH …": "ERM …", "TATT!": "CAUGHT!",
          "DUNK. DUNK. DUNK.": "KNOCK. KNOCK. KNOCK.", "TRAMP! TRAMP!": "STOMP! STOMP!", "HOST! HOST!": "COUGH! COUGH!", "KLIKK!": "CLICK!",
          "SMELL!": "SNAP!", "HAL I VEI!": "HEAVE!", "HAN KOMMER!": "HE'S COMING!", "OPP!": "UP!", "PIIIP!": "BEEEP!", "JAAA!": "YESSS!",
          "JEG ER 6 ÅR": "I AM 6"}


def T(s, x, y, size=30, rot=-6, fill="#C0453D", en=None):
    en = en or LYD_EN.get(s)

    def en_tekst(tekst, klasse):
        k = f' class="{klasse}"' if klasse else ""
        return (f'<text{k} x="{x}" y="{y}" text-anchor="middle" transform="rotate({rot} {x} {y})" font-family="Baloo 2,Comic Relief,sans-serif" '
                f'font-weight="800" font-size="{size}" fill="{fill}" stroke="#FFFDF8" stroke-width="{max(4, size/5):g}" paint-order="stroke" stroke-linejoin="round">{esc(tekst)}</text>')
    return en_tekst(s, "nb") + en_tekst(en, "en") if en else en_tekst(s, "")


def X(color, op):
    return f'<rect width="360" height="220" fill="{color}" opacity="{op}"/>'


def R(tag, a, t, a2=None):
    return dict(tag=tag, a=a, t=t, a2=a2)


def hjem(n, aerend, knut, extra_cap=None, art_extra=()):
    t = [("P", aerend), ("L", "Skal bare fikse noe i garasjen!")]
    if extra_cap:
        t.insert(0, ("N", extra_cap))
    t += [("N", "Ludvig tar på Kanels bjelle før de drar. Det gjør han hver gang."), ("K", knut), ("L", "Hylla.")]
    return R("", [B("bgG"), V(110, 204, 90), L(206, 202, 104), K(266, 202, 42), *art_extra], t)


def hopp(n, drivstoff, cap2=None):
    t = [("N", f"Drivstoff i dag: {drivstoff}. Ludvig stiller inn."), ("L", "Tirsdag fjortende oktober, 16.40."),
         ("K", f"Måling nummer {n}. Notert.")]
    if cap2:
        t.append(("N", cap2))
    return R("", [B("blits"), V(180, 186, 120, rot=-10), T("BLITS!", 180, 52, 44)], t)


def hjemme(sp, svar, stille, cap=None, cap2=None, art_extra=()):
    t = []
    if cap:
        t.append(("N", cap))
    t += [("P", sp), ("L", svar)]
    if cap2:
        t.append(("N", cap2))
    t.append(("P~", stille))
    return R("", [B("bgG"), V(110, 204, 90), L(206, 202, 104), K(266, 202, 42), *art_extra], t)
